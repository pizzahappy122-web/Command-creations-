License

This resource pack is licensed under All Rights Reserved (ARR).

Redistribution is not allowed.
Modified versions may not be redistributed.