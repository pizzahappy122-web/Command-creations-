execute as @e[type=!minecraft:player,type=!minecraft:item,type=!minecraft:tnt] at @s run summon minecraft:tnt ~ ~ ~ {Fuse:80}
