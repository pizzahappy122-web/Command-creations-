# 1. This line kills the function immediately if you aren't in the Overworld
execute unless dimension minecraft:overworld run return 0

# 2. Your original code (only runs if you ARE in the Overworld)
execute positioned ~ ~-16 ~ run kill @n[type=fishing_bobber,tag=!spawned,distance=..128]
summon arrow ~-2 ~70 ~-2 {damage:70,Motion:[0.0,-10.0,0.0]}
summon arrow ~-2 ~70 ~-1 {damage:70,Motion:[0.0,-10.0,0.0]}
summon arrow ~-2 ~70 ~0 {damage:70,Motion:[0.0,-10.0,0.0]}
summon arrow ~-2 ~70 ~1 {damage:70,Motion:[0.0,-10.0,0.0]}
summon arrow ~-2 ~70 ~2 {damage:70,Motion:[0.0,-10.0,0.0]}
summon arrow ~-1 ~70 ~-2 {damage:70,Motion:[0.0,-10.0,0.0]}
summon arrow ~-1 ~70 ~-1 {damage:70,Motion:[0.0,-10.0,0.0]}
summon arrow ~-1 ~70 ~0 {damage:70,Motion:[0.0,-10.0,0.0]}
summon arrow ~-1 ~70 ~1 {damage:70,Motion:[0.0,-10.0,0.0]}
summon arrow ~-1 ~70 ~2 {damage:70,Motion:[0.0,-10.0,0.0]}
summon arrow ~0 ~70 ~-2 {damage:70,Motion:[0.0,-10.0,0.0]}
summon arrow ~0 ~70 ~-1 {damage:70,Motion:[0.0,-10.0,0.0]}
summon arrow ~0 ~70 ~0 {damage:70,Motion:[0.0,-10.0,0.0]}
summon arrow ~0 ~70 ~1 {damage:70,Motion:[0.0,-10.0,0.0]}
summon arrow ~0 ~70 ~2 {damage:70,Motion:[0.0,-10.0,0.0]}
summon arrow ~1 ~70 ~-2 {damage:70,Motion:[0.0,-10.0,0.0]}
summon arrow ~1 ~70 ~-1 {damage:70,Motion:[0.0,-10.0,0.0]}
summon arrow ~1 ~70 ~0 {damage:70,Motion:[0.0,-10.0,0.0]}
summon arrow ~1 ~70 ~1 {damage:70,Motion:[0.0,-10.0,0.0]}
summon arrow ~1 ~70 ~2 {damage:70,Motion:[0.0,-10.0,0.0]}
summon arrow ~2 ~70 ~-2 {damage:70,Motion:[0.0,-10.0,0.0]}
summon arrow ~2 ~70 ~-1 {damage:70,Motion:[0.0,-10.0,0.0]}
summon arrow ~2 ~70 ~0 {damage:70,Motion:[0.0,-10.0,0.0]}
summon arrow ~2 ~70 ~1 {damage:70,Motion:[0.0,-10.0,0.0]}
summon arrow ~2 ~70 ~2 {damage:70,Motion:[0.0,-10.0,0.0]}



summon arrow ~-2 ~70.5 ~-2 {damage:80,Motion:[0.0,-10.0,0.0]}
summon arrow ~-2 ~70.5 ~-1 {damage:80,Motion:[0.0,-10.0,0.0]}
summon arrow ~-2 ~70.5 ~0 {damage:80,Motion:[0.0,-10.0,0.0]}
summon arrow ~-2 ~70.5 ~1 {damage:80,Motion:[0.0,-10.0,0.0]}
summon arrow ~-2 ~70.5 ~2 {damage:80,Motion:[0.0,-10.0,0.0]}
summon arrow ~-1 ~70.5 ~-2 {damage:80,Motion:[0.0,-10.0,0.0]}
summon arrow ~-1 ~70.5 ~-1 {damage:80,Motion:[0.0,-10.0,0.0]}
summon arrow ~-1 ~70.5 ~0 {damage:80,Motion:[0.0,-10.0,0.0]}
summon arrow ~-1 ~70.5 ~1 {damage:80,Motion:[0.0,-10.0,0.0]}
summon arrow ~-1 ~70.5 ~2 {damage:80,Motion:[0.0,-10.0,0.0]}
summon arrow ~0 ~70.5 ~-2 {damage:80,Motion:[0.0,-10.0,0.0]}
summon arrow ~0 ~70.5 ~-1 {damage:80,Motion:[0.0,-10.0,0.0]}
summon arrow ~0 ~70.5 ~0 {damage:80,Motion:[0.0,-10.0,0.0]}
summon arrow ~0 ~70.5 ~1 {damage:80,Motion:[0.0,-10.0,0.0]}
summon arrow ~0 ~70.5 ~2 {damage:80,Motion:[0.0,-10.0,0.0]}
summon arrow ~1 ~70.5 ~-2 {damage:80,Motion:[0.0,-10.0,0.0]}
summon arrow ~1 ~70.5 ~-1 {damage:80,Motion:[0.0,-10.0,0.0]}
summon arrow ~1 ~70.5 ~0 {damage:80,Motion:[0.0,-10.0,0.0]}
summon arrow ~1 ~70.5 ~1 {damage:80,Motion:[0.0,-10.0,0.0]}
summon arrow ~1 ~70.5 ~2 {damage:80,Motion:[0.0,-10.0,0.0]}
summon arrow ~2 ~70.5 ~-2 {damage:80,Motion:[0.0,-10.0,0.0]}
summon arrow ~2 ~70.5 ~-1 {damage:80,Motion:[0.0,-10.0,0.0]}
summon arrow ~2 ~70.5 ~0 {damage:80,Motion:[0.0,-10.0,0.0]}
summon arrow ~2 ~70.5 ~1 {damage:80,Motion:[0.0,-10.0,0.0]}
summon arrow ~2 ~70.5 ~2 {damage:80,Motion:[0.0,-10.0,0.0]}