tag @s add sTendril.chickenTarget
tag @e[tag=sTendril.tip] add sTendril.frozen
schedule function kinematic-chain:zzz_internal/unfreeze 30t replace
schedule function kinematic-chain:zzz_internal/play_acquire_sound 20t replace