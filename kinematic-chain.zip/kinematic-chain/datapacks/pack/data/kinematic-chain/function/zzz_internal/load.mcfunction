kill @e[tag=sTendril]
summon minecraft:marker 222.0 51 -14.0 {Tags:["sTendril","sTendril.seg1", "sTendril.thickest"], Rotation:[0f,-90f]}
summon minecraft:marker 222.0 51.5 -14.0 {Tags:["sTendril","sTendril.seg2", "sTendril.thickest"], Rotation:[0f,-90f]}
summon minecraft:marker 222.0 52 -14.0 {Tags:["sTendril","sTendril.seg3", "sTendril.thick"], Rotation:[0f,-90f]}
summon minecraft:marker 222.0 52.5 -14.0 {Tags:["sTendril","sTendril.seg4", "sTendril.thick"], Rotation:[180f,-75.67605512172942f]}
summon minecraft:marker 222.0 52.98445621085532 -14.123701979627262 {Tags:["sTendril","sTendril.seg5", "sTendril.thick"], Rotation:[180f,-61.35211024345884f]}
summon minecraft:marker 222.0 53.42324749180051 -14.363414748929364 {Tags:["sTendril","sTendril.seg6", "sTendril.mid"], Rotation:[180f,-47.02816536518827f]}
summon minecraft:marker 222.0 53.78909192623742 -14.70423412894103 {Tags:["sTendril","sTendril.seg7", "sTendril.mid"], Rotation:[180f,-32.70422048691768f]}
summon minecraft:marker 222.0 54.05924307917149 -15.124969621344977 {Tags:["sTendril","sTendril.seg8", "sTendril.mid"], Rotation:[180f,-47.02816536518827f]}
summon minecraft:marker 222.0 54.425087513608396 -15.465789001356644 {Tags:["sTendril","sTendril.seg9", "sTendril.mid"], Rotation:[180f,-61.35211024345884f]}
summon minecraft:marker 222.0 54.863878794553585 -15.705501770658746 {Tags:["sTendril","sTendril.seg10", "sTendril.mid"], Rotation:[180f,-75.67605512172942f]}
summon minecraft:marker 222.0 55.348335005408906 -15.829203750286007 {Tags:["sTendril","sTendril.seg11", "sTendril.mid"], Rotation:[0f,-90f]}
summon minecraft:marker 222.0 55.848335005408906 -15.829203750286007 {Tags:["sTendril","sTendril.seg12", "sTendril.thin"], Rotation:[0f,-75.67605512172942f]}
summon minecraft:marker 222.0 56.332791216264226 -15.705501770658746 {Tags:["sTendril","sTendril.seg13", "sTendril.thin"], Rotation:[0f,-61.35211024345884f]}
summon minecraft:marker 222.0 56.771582497209415 -15.465789001356644 {Tags:["sTendril","sTendril.seg14", "sTendril.thin"], Rotation:[0f,-47.02816536518826f]}
summon minecraft:marker 222.0 57.137426931646324 -15.124969621344977 {Tags:["sTendril","sTendril.seg15", "sTendril.thin"], Rotation:[0f,-32.70422048691768f]}
summon minecraft:marker 222.0 57.40757808458039 -14.70423412894103 {Tags:["sTendril","sTendril.seg16", "sTendril.thin"], Rotation:[0f,-18.380275608647096f]}
summon minecraft:marker 222.0 57.565239265778025 -14.229741819263237 {Tags:["sTendril","sTendril.tip"]}