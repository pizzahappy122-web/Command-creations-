kill @e[tag=sTendril.mouthTarget]
execute if entity @e[tag=sTendril.chickenHeld] run summon minecraft:marker 220.5 51.9 -12.5 {Tags:["sTendril.mouthTarget"]}
execute as @e[tag=sTendril.mouthTarget] at @s if entity @e[tag=sTendril.tip,distance=1..] run tp @s ~ ~0.75 ~
execute as @e[tag=sTendril.mouthTarget] at @s if entity @e[tag=sTendril.tip,distance=2..] run tp @s ~ ~0.75 ~
execute as @e[tag=sTendril.mouthTarget] at @s if entity @e[tag=sTendril.tip,distance=3..] run tp @s ~ ~0.75 ~
execute as @e[tag=sTendril.mouthTarget] at @s if entity @e[tag=sTendril.tip,distance=4..] run tp @s ~ ~0.75 ~
execute as @e[tag=sTendril.tip] at @s[tag=!sTendril.frozen] run function kinematic-chain:zzz_internal/follow_mouth_target
execute as @e[tag=sTendril.mouthTarget] at @s anchored eyes if entity @e[tag=sTendril.tip,distance=..0.18] run function kinematic-chain:zzz_internal/reached_mouth_target
execute as @e[tag=sTendril.tip] at @s run tp @e[tag=sTendril.chickenHeld] ~ ~-.6 ~