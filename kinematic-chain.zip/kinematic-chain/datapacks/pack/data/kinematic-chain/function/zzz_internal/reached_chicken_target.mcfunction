tp @s ~ ~ ~
function kinematic-chain:zzz_internal/untitled