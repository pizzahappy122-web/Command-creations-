execute at @e[tag=sTendril.tip] run playsound minecraft:block.sculk_sensor.clicking_stop block @a ~ ~ ~ 1 0.1
schedule function kinematic-chain:zzz_internal/schedule_idle_sound 4s replace