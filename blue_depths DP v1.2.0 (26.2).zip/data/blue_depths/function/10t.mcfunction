###### Spawn mobs ######
# Mob bucket spawn
execute as @e[type=minecraft:cod,tag=bd_fishReplace] at @s run function blue_depths:mobs/spawn_bucket
# Generic Blue Depths mobs spawned by player
execute as @e[type=minecraft:tropical_fish,tag=bdMobSpawn] run function blue_depths:misc/spawn_mob

## Reschedule
schedule function blue_depths:10t 10t