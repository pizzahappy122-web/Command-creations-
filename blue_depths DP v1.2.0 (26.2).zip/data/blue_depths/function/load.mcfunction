######## Message to play upon load/reload ##########
tellraw @a [{"color":"#1E90FF","text":"-- Blue Depths v1.2.0 successfully loaded! --"},{"color":"dark_green","text":"\n• Welcome to Roaring Rivers Part 2: \"Shocking Snap\"!"},{"color":"red","text":"\n• Use your guide book to uncover and summon a beast lost to time"},{"color":"white","text":"\n• Check out the "},{"bold":true,"click_event":{"action":"open_url","url":"https://sharkwingstudio.github.io/blue-depths-site/"},"color":"blue","hover_event":{"action":"show_text","value":[{"text":"Go to Wiki"}]},"text":"Blue Depths Wiki","underlined":true},{"text":"\n"}]

## Test the book
#execute as @a run function blue_depths:misc/make_book


############## Scoreboards ####################
# Follow range flag (0 = following turned off, 1 = following turned on)
scoreboard objectives add followRangeFlag dummy
#Counter for growth
scoreboard objectives add marineGrowth dummy
# Scoreboard for spawning
scoreboard objectives add bdSpawner dummy
# Bucket scoreboard for fish use
scoreboard objectives add bdBucketUse minecraft.used:minecraft.water_bucket
# Boss flag
scoreboard objectives add bd_bossFlag dummy
# Attack timer
scoreboard objectives add bd_atkCool dummy
# Raycast counter
scoreboard objectives add bd_raycast dummy
# Boss incrementer for scaling multiple players
scoreboard objectives add bd_scaleBoss dummy
# Staff use cooldown scoreboard
scoreboard objectives add bd_staffCooldown dummy
# Ink cloud cooldown
scoreboard objectives add bd_inkCloudCooldown dummy
# Scoreboards for cooldown conversion
scoreboard objectives add bd_scoreDisplay dummy
scoreboard objectives add bd_constant dummy
# Book use scoreboard
scoreboard objectives add bd_bookSpawn dummy
## Animation Stuff
# Animation scoreboard
scoreboard objectives add bd_animate dummy
# Motion scoreboards
scoreboard objectives add bd_mobMotionX dummy
scoreboard objectives add bd_mobMotionZ dummy
scoreboard objectives add bd_isMoving dummy
## Counts scoreboard
# Original counts scoreboard
scoreboard objectives add bd_containerInputCount dummy
scoreboard objectives add bd_containerFuelCount dummy
# Store multiplication fuel value temporarily
scoreboard objectives add bd_containerFuelMulti dummy
# Modified counts scoreboard
scoreboard objectives add bd_containerNewInputCount dummy
scoreboard objectives add bd_containerNewFuelCount dummy
scoreboard objectives add bd_containerOutputCount dummy
# Flag for displaying if number is odd
scoreboard objectives add bd_fuelRemainder dummy

# Set constants for mathematical use:
scoreboard players set #20 bd_constant 20
scoreboard players set #bd_8 bd_constant 8
scoreboard players set #bd_2 bd_constant 2


############## Schedule tick functions ######################
# 40t function
schedule function blue_depths:40t 40t
# 30t function
schedule function blue_depths:30t 30t
# 20t function
schedule function blue_depths:20t 20t
# 10t function
schedule function blue_depths:10t 10t
# 5t function
schedule function blue_depths:5t 5t