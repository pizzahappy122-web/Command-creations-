## The Nameless Depth Boss Loop
execute if score theNamelessDepth bd_bossFlag matches 1 run function blue_depths:boss/the_nameless_depth/the_nameless_loop