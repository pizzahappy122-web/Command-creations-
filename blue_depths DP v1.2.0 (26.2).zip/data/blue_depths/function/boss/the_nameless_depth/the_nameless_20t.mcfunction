#### Attacks effects
# Visual effects of the bubble mine
execute as @e[type=marker,tag=bd_bubbleMine] at @s run particle minecraft:soul_fire_flame ~ ~1.5 ~ .3 .3 .3 0 60
execute as @e[type=marker,tag=bd_bubbleMinePunish] at @s run particle minecraft:soul_fire_flame ~ ~1.5 ~ .3 .3 .3 0 60

# Status effects for the ink cloud
execute as @e[type=marker,tag=bd_inkCloud] at @s run function blue_depths:boss/the_nameless_depth/super_attacks/ink_cloud/ink_cloud_effect

####### Super Attacks #######
### Supers for normal conditions
## Increment attack counter
scoreboard players add @e[type=slime,tag=bd_the_nameless_depth] bd_atkCool 1

## Trigger super attacks
# Bubble mine at t=5
execute as @e[type=slime,tag=bd_the_nameless_depth,scores={bd_atkCool=5}] at @s if entity @a[distance=..70] run function blue_depths:boss/the_nameless_depth/super_attacks/bubble_mine_start
# Claw grab at t = 12
execute as @e[type=slime,tag=bd_the_nameless_depth,scores={bd_atkCool=12}] at @s if entity @a[distance=..70] run function blue_depths:boss/the_nameless_depth/super_attacks/tentacle_grab/tentacle_grab_start
# Bubble wave at t = 20
execute as @e[type=slime,tag=bd_the_nameless_depth,scores={bd_atkCool=20}] at @s if entity @a[distance=..70] run function blue_depths:boss/the_nameless_depth/super_attacks/bubble_wave/bubble_wave_start
# Claw grab again at t = 30
execute as @e[type=slime,tag=bd_the_nameless_depth,scores={bd_atkCool=30}] at @s if entity @a[distance=..70] run function blue_depths:boss/the_nameless_depth/super_attacks/tentacle_grab/tentacle_grab_start
# Ink Cloud at t = 38
execute as @e[type=slime,tag=bd_the_nameless_depth,scores={bd_atkCool=38}] at @s if entity @a[distance=..70] run function blue_depths:boss/the_nameless_depth/super_attacks/ink_cloud/ink_cloud_start

## Reset counter to start cycle again
execute as @e[type=slime,tag=bd_the_nameless_depth,scores={bd_atkCool=40}] at @s run scoreboard players set @s bd_atkCool 0

### Supers for punishing cheesers
# Tick tock for players cheesing (increment counter)
execute as @a[gamemode=!creative,gamemode=!spectator] at @s if entity @e[type=slime,tag=bd_the_nameless_depth,distance=..70] unless block ~ ~1.6 ~ minecraft:water run scoreboard players add @s bd_surfaceTimer 1
# Decrement surface timer if player is back in the water
execute as @a[scores={bd_surfaceTimer=1..6},tag=!bd_punishedByNameless,gamemode=!creative,gamemode=!spectator] at @s if entity @e[type=slime,tag=bd_the_nameless_depth,distance=..70] if block ~ ~1.6 ~ minecraft:water run scoreboard players remove @s bd_surfaceTimer 1
# Give warning to player reaching their punishment
execute as @a[scores={bd_surfaceTimer=4},gamemode=!creative,gamemode=!spectator] at @s if entity @e[type=slime,tag=bd_the_nameless_depth,distance=..70] unless block ~ ~1.6 ~ minecraft:water run function blue_depths:boss/the_nameless_depth/super_attacks/surface_punish/warning
# Punish the player after not heeding the warning
execute as @a[scores={bd_surfaceTimer=7},gamemode=!creative,gamemode=!spectator,tag=!bd_punishedByNameless] at @s if entity @e[type=slime,tag=bd_the_nameless_depth,distance=..70] run function blue_depths:boss/the_nameless_depth/super_attacks/surface_punish/punishment_start
# Continue to increment surface timer since player is already punished
execute as @a[scores={bd_surfaceTimer=7..},tag=bd_punishedByNameless,gamemode=!creative,gamemode=!spectator] at @s run scoreboard players add @s bd_surfaceTimer 1
# Reset surface timer after punishment cycle has been completed to have player ready to be punished again if needed
execute as @a[scores={bd_surfaceTimer=15..},tag=bd_punishedByNameless,gamemode=!creative,gamemode=!spectator] at @s run function blue_depths:boss/the_nameless_depth/super_attacks/surface_punish/reset_punishment

say hi

# End boss loops and clean up
execute as @e[type=armor_stand,tag=bd_the_nameless_depth] at @s unless entity @e[type=slime,tag=bd_the_nameless_depth,distance=0..1.7] run function blue_depths:boss/the_nameless_depth/the_nameless_end

# Recursive call for the function
execute if score theNamelessDepth bd_bossFlag matches 1 run schedule function blue_depths:boss/the_nameless_depth/the_nameless_20t 20t