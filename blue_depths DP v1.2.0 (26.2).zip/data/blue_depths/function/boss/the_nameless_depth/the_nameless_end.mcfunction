##### Reset and kill the boss

# Remove boss bar
bossbar remove nameless_depth

# Kill any left over effects
kill @e[type=armor_stand, tag=bd_nd_wave]
kill @e[type=marker, tag=bd_inkCloud]
kill @e[type=drowned,tag=bd_namelessClaw]
kill @e[type=marker,tag=bd_bubbleMine]

# Kill claw variants
kill @e[type=drowned,tag=bd_namelessClaw]
kill @e[type=drowned,tag=bd_namelessClawPunisher]

# Remove leftover tags
tag @a[tag=bd_namelessClawTarget] remove bd_namelessClawTarget
tag @a[tag=bd_punishedByNameless] remove bd_punishedByNameless

# Reset scoreboard to not have loops run anymore
scoreboard players reset bossLoop bd_bossFlag
scoreboard players reset theNamelessDepth bd_bossFlag
scoreboard players reset #nameless_depthStart bd_scaleBoss

# Remove old scoreboards
scoreboard objectives remove bd_surfaceTimer
scoreboard objectives remove bd_deathDetect

## effects
particle minecraft:sculk_soul ~ ~1.5 ~ 1.2 1.2 1.2 0 300
particle minecraft:squid_ink ~ ~1.5 ~ 1.2 1.2 1.2 0 300
playsound entity.wither.death master @a[distance=..70]

# Kill the boss passengers
kill @e[type=drowned,tag=bd_the_nameless_depth,sort=nearest,limit=1]
kill @s