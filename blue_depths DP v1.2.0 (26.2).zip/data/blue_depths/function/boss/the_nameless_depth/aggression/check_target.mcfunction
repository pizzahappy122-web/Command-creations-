#### For the nameless_depth
## If it is nighttime and there are no players in water within 70 blocks of the aggressive mob set follow range to 0
execute if predicate blue_depths:night_check if score @s followRangeFlag matches 1 unless entity @a[distance=..70,predicate=blue_depths:is_in_water] run function blue_depths:boss/the_nameless_depth/aggression/turn_off_follow

# If mob is not targeting a player in water (or has no target), neutralize it
execute if predicate blue_depths:night_check if predicate blue_depths:target_in_water run function blue_depths:behavior/aggression/update_target

# If nighttime and a player enters water within 40 blocks of mob w/ zero follow range, reset back to 70
execute if predicate blue_depths:night_check if score @s followRangeFlag matches 0 if entity @a[distance=..70,predicate=blue_depths:is_in_water] run function blue_depths:boss/the_nameless_depth/aggression/turn_on_follow

# If daytime, reset follow range back to 70 for all mob's range that is 0
execute if score @s followRangeFlag matches 0 unless predicate blue_depths:night_check run function blue_depths:boss/the_nameless_depth/aggression/turn_on_follow