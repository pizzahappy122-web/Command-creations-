# Turn on follow range
attribute @s minecraft:follow_range base set 70

# Flag as not following to avoid repeated change
scoreboard players set @s followRangeFlag 1