# Initial setup
scoreboard players set #nameless_depthStart bd_scaleBoss 0

#### Scale boss depending on the amount of players there are
execute as @a[distance=..70] run scoreboard players add #nameless_depthStart bd_scaleBoss 1

# Boss start for 1 player
execute as @s at @s if score #nameless_depthStart bd_scaleBoss matches 1 run function blue_depths:boss/the_nameless_depth/boss_start/1p_start
# Boss start for duo
execute as @s at @s if score #nameless_depthStart bd_scaleBoss matches 2 run function blue_depths:boss/the_nameless_depth/boss_start/2p_start
# Boss start for trio
execute as @s at @s if score #nameless_depthStart bd_scaleBoss matches 3 run function blue_depths:boss/the_nameless_depth/boss_start/3p_start
# Boss start for 4 and up
execute as @s at @s if score #nameless_depthStart bd_scaleBoss matches 4.. run function blue_depths:boss/the_nameless_depth/boss_start/3p_start

# Return players back to survival
gamemode survival @a[gamemode=adventure]

# effects and death
playsound entity.generic.explode master @a[distance=..30] ~ ~ ~
particle minecraft:explosion ~ ~1.5 ~ 2.5 2.5 2.5 0 100
data modify entity @s Invulnerable set value 0b
tp @s ~ ~-300 ~