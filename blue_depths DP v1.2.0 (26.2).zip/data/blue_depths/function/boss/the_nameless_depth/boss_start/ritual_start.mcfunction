## Remove the dropper
setblock ~ ~ ~ water

## Fill area with water to prevent trapping the boss
fill ~-7 ~ ~-7 ~7 ~7 ~7 minecraft:water

## Temporarily set players gamemode to adventure
gamemode adventure @a[distance=..70,gamemode=!creative,gamemode=!spectator]

## Summon the harbinger
summon glow_squid ~ ~1.5 ~ {Invulnerable:1b,Glowing:1b,DeathLootTable:"blue_depths:entities/nothing",NoAI:1b,Tags:["bd_namelessStart"]}

scoreboard players add @e[type=glow_squid,tag=bd_namelessStart,sort=nearest,limit=1] bd_atkCool 0

# Effects
playsound entity.warden.death master @a[distance=..70] ~ ~ ~
particle minecraft:squid_ink ~ ~1.5 ~ 1 1 1 0 100
effect give @a[gamemode=adventure,distance=..70] blindness 2 0 false

schedule function blue_depths:boss/the_nameless_depth/boss_start/ritual_loop 40t append

kill @s