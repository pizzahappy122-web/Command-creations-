# Increment counter
scoreboard players add @e[type=glow_squid,tag=bd_namelessStart,limit=1] bd_atkCool 1

# Effects
execute as @e[type=glow_squid,tag=bd_namelessStart,scores={bd_atkCool=..6}] at @s run effect give @a[gamemode=adventure,distance=..70] blindness 2 0 false
execute as @e[type=glow_squid,tag=bd_namelessStart,scores={bd_atkCool=..6}] at @s run effect give @a[gamemode=adventure,distance=..70] slowness 2 10 false
execute as @e[type=glow_squid,tag=bd_namelessStart,scores={bd_atkCool=..6}] at @s run playsound minecraft:entity.warden.heartbeat master @a[gamemode=adventure,distance=..70] ~ ~ ~
execute as @e[type=glow_squid,tag=bd_namelessStart,scores={bd_atkCool=..6}] at @s run particle minecraft:soul ~ ~1.5 ~ 1 1 1 0 100

# Start the boss battle
execute as @e[type=glow_squid,tag=bd_namelessStart,scores={bd_atkCool=8}] at @s run function blue_depths:boss/the_nameless_depth/boss_start/ritual_end

# Recursion
execute as @e[type=glow_squid,tag=bd_namelessStart,scores={bd_atkCool=..8}] run schedule function blue_depths:boss/the_nameless_depth/boss_start/ritual_loop 60t append
