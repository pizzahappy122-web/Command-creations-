###### Summon the boss ########
summon drowned ~ ~ ~ {Silent:1b,Invulnerable:1b,DeathLootTable:"blue_depths:entities/nameless/1p",CanBreakDoors:0b,Tags:["bd_aggro_mob","bd_scanned","bd_the_nameless_depth","bd_atk_fish"],Passengers:[{id:"minecraft:slime",Silent:1b,DeathLootTable:"blue_depths:entities/nothing",NoAI:1b,Health:300f,Size:0,Tags:["bd_aggro_mob","bd_scanned","bd_the_nameless_depth"],Passengers:[{id:"minecraft:armor_stand",Silent:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["bd_aggro_mob","bd_scanned","bd_the_nameless_depth"],equipment:{mainhand:{id:"minecraft:flint",count:1,components:{item_model:"bluedepths:blue_depths/mobs/the_nameless_depth"}}}}],CustomName:{"bold":true,"color":"dark_red","text":"The Nameless Depth"},active_effects:[{id:"minecraft:water_breathing",amplifier:0,duration:-1,show_particles:0b},{id:"minecraft:invisibility",amplifier:0,duration:-1,show_particles:0b}],attributes:[{id:"minecraft:max_health",base:300},{id:"minecraft:scale",base:3.3}]}],CustomName:{"bold":true,"color":"dark_red","text":"The Nameless Depth"},active_effects:[{id:"minecraft:invisibility",amplifier:0,duration:-1,show_particles:0b}],attributes:[{id:"minecraft:attack_damage",base:12},{id:"minecraft:follow_range",base:70},{id:"minecraft:movement_speed",base:1.8}]}

## Enable the boss loop
scoreboard players set bossLoop bd_bossFlag 1
scoreboard players set theNamelessDepth bd_bossFlag 1

## Add The Nameless Depth to the attack scoreboard
scoreboard players set @e[type=slime,tag=bd_the_nameless_depth,sort=nearest,limit=1] bd_atkCool 0

## Add The Nameless Depth to the follow range flag scoreboard
scoreboard players set @e[type=drowned,tag=bd_the_nameless_depth,sort=nearest,limit=1] followRangeFlag 1

## Enable death detection
scoreboard objectives add bd_deathDetect deathCount
## Out of water counter for boss anti-cheese
scoreboard objectives add bd_surfaceTimer dummy
## Add players to surface timer scoreboard
scoreboard players set @a bd_surfaceTimer 0


## Add Boss Health bar
bossbar add nameless_depth {"bold":true,"color":"dark_red","text":"The Nameless Depth"}
bossbar set nameless_depth color purple
bossbar set nameless_depth max 300

# Start 20t boss loop
schedule function blue_depths:boss/the_nameless_depth/20t/1p20t 20t