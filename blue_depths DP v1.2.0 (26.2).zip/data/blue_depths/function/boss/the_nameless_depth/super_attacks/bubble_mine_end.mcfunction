## Make boss temporarily Invulnerable
effect give @e[type=slime,tag=bd_the_nameless_depth,sort=nearest,limit=1] resistance 1 10
effect give @e[type=drowned,tag=bd_namelessClaw,sort=nearest,limit=1] resistance 1 10

## Trigger explosion
execute as @e[type=marker,tag=bd_bubbleMine] at @s run summon creeper ~ ~ ~ {Fuse:0}

## Apply slowness
execute as @e[type=marker,tag=bd_bubbleMine] at @s run effect give @a[distance=..5,gamemode=!creative,gamemode=!spectator] slowness 5 1

## Update boss target
execute as @e[type=drowned,tag=bd_the_nameless_depth,limit=1] at @s run function blue_depths:behavior/aggression/update_target


## Kill the marker
kill @e[type=marker,tag=bd_bubbleMine]