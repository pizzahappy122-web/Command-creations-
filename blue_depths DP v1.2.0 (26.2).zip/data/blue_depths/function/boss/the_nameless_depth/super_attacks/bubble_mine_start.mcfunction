# Remove old mines
kill @e[type=marker,tag=bd_bubbleMine]

## Summon mine
execute at @a[gamemode=!creative,gamemode=!spectator,distance=..70] run summon marker ~ ~ ~ {Tags:["bd_bubbleMine"]}

## Play sound effect
playsound minecraft:entity.elder_guardian.curse master @a[distance=..70] ~ ~ ~ 4 1

## Trigger countdown
schedule function blue_depths:boss/the_nameless_depth/super_attacks/bubble_mine_end 80t append