## Debuffs for the player
effect give @a[distance=..6,gamemode=!creative,gamemode=!spectator] blindness 6 0 false
effect give @a[distance=..6,gamemode=!creative,gamemode=!spectator] wither 6 1 false
effect give @a[distance=..6,gamemode=!creative,gamemode=!spectator] weakness 6 0 false
