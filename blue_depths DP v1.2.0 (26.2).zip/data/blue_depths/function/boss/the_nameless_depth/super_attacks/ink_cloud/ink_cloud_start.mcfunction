## Summon cloud
execute as @e[type= slime,tag=bd_the_nameless_depth] at @s run summon marker ^ ^ ^3 {Tags:["bd_inkCloud"]}

## Play sound effect
playsound minecraft:entity.squid.death master @a[distance=..10] ~ ~ ~ 100 0.6

## schedule death of the cloud
schedule function blue_depths:boss/the_nameless_depth/super_attacks/ink_cloud/ink_cloud_kill 160t append