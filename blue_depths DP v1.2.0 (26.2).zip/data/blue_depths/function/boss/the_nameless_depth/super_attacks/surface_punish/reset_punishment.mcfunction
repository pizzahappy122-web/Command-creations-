# Reset the punished player's score
scoreboard players set @s bd_surfaceTimer 0

# Remove punishment tag
tag @s[tag=bd_punishedByNameless] remove bd_punishedByNameless
tag @s[tag=bd_namelessClawTargetPunisher] remove bd_namelessClawTargetPunisher

# Kill ONLY the punishment claw that belongs to this player
execute as @e[type=drowned,tag=bd_namelessClawPunisher] if score @s bd_clawTargetID = @p bd_playerId run kill @s
