# Give targeted player a second dose of damage and apply effects
#damage @p[tag=bd_namelessClawTargetPunisher,tag=bd_punishedByNameless] 5
#effect give @p[tag=bd_namelessClawTargetPunisher,tag=bd_punishedByNameless] weakness 8 2
#effect give @p[tag=bd_namelessClawTargetPunisher,tag=bd_punishedByNameless] slowness 8 1

# Reset the punished player's score
#scoreboard players set @a[tag=bd_namelessClawTargetPunisher,tag=bd_punishedByNameless] bd_surfaceTimer 0

# Remove any leftover tags from players
#tag @a[tag=bd_namelessClawTargetPunisher] remove bd_namelessClawTargetPunisher
#tag @a[tag=bd_punishedByNameless] remove bd_punishedByNameless


# Kill claw
#kill @s

### Apply damage and effects to the OWNER only
execute as @a if score @s bd_playerId = @e[tag=bd_namelessClawPunisher,limit=1] bd_clawTargetID run damage @s 5
execute as @a if score @s bd_playerId = @e[tag=bd_namelessClawPunisher,limit=1] bd_clawTargetID run effect give @s weakness 8 2
execute as @a if score @s bd_playerId = @e[tag=bd_namelessClawPunisher,limit=1] bd_clawTargetID run effect give @s slowness 8 1

### Reset ONLY the owner's surface timer
execute as @a if score @s bd_playerId = @e[tag=bd_namelessClawPunisher,limit=1] bd_clawTargetID run scoreboard players set @s bd_surfaceTimer 0

### Remove punishment tags ONLY from the owner
execute as @a if score @s bd_playerId = @e[tag=bd_namelessClawPunisher,limit=1] bd_clawTargetID run tag @s remove bd_namelessClawTargetPunisher
execute as @a if score @s bd_playerId = @e[tag=bd_namelessClawPunisher,limit=1] bd_clawTargetID run tag @s remove bd_punishedByNameless

### Kill THIS claw
kill @s
