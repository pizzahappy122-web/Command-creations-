## Make boss and claw temporarily Invulnerable
effect give @e[type=slime,tag=bd_the_nameless_depth,sort=nearest,limit=1] resistance 1 10
effect give @e[type=drowned,tag=bd_namelessClawPunisher,sort=nearest,limit=1] resistance 1 10

## Trigger explosion
execute as @e[type=marker,tag=bd_bubbleMinePunish] at @s run summon creeper ~ ~ ~ {Fuse:0}

## Apply slowness
execute as @e[type=marker,tag=bd_bubbleMinePunish] at @s run effect give @a[distance=..5,gamemode=!creative,gamemode=!spectator] slowness 5 1

## Kill the marker
kill @e[type=marker,tag=bd_bubbleMinePunish]