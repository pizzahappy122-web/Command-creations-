### Summon the claw
summon drowned ~ ~ ~ {Silent:1b,DeathLootTable:"blue_depths:entities/nothing",PersistenceRequired:1b,NoAI:1b,Health:7f,IsBaby:1b,Tags:["bd_namelessClawPunisher"],equipment:{head:{id:"minecraft:flint",count:1,components:{"minecraft:item_model":"bluedepths:blue_depths/mobs/nameless_beak_open"}}},drop_chances:{head:0.000},active_effects:[{id:"minecraft:invisibility",amplifier:0,duration:-1,show_particles:0b}],attributes:[{id:"minecraft:max_health",base:7}]}

# Tag player to follow
tag @a[distance=..70,tag=bd_punishedByNameless,tag=!bd_namelessClawTargetPunisher,sort=nearest,limit=1] add bd_namelessClawTargetPunisher

# Kill old regular claw if punished player is targeted by it and remove the tag
execute if entity @a[tag=bd_punishedByNameless,tag=bd_namelessClawTarget] run kill @e[type=drowned,tag=bd_namelessClaw,sort=nearest,limit=1]
execute as @a[tag=bd_punishedByNameless,tag=bd_namelessClawTarget] at @s run tag @s remove bd_namelessClawTarget

# Kill punishment claw if there is no valid target
execute unless entity @a[tag=bd_namelessClawTargetPunisher] run kill @e[type=drowned,tag=bd_namelessClawPunisher,sort=nearest,limit=1]

## Have claw target the correct punished player
scoreboard players operation @e[type=drowned,tag=bd_namelessClawPunisher,sort=nearest,limit=1] bd_clawTargetID = @p[tag=bd_punishedByNameless,tag=!bd_namelessClawTargetPunisher,sort=nearest,limit=1] bd_playerId

## Play sound effect
playsound minecraft:entity.guardian.attack master @a[distance=..70] ~ ~ ~ 100 1
playsound minecraft:entity.evoker.prepare_attack master @a[distance=..70] ~ ~ ~ 100 1

## Position the claw
#execute as @e[tag=bd_namelessClawPunisher,sort=nearest,limit=1] at @s run tp @s ~ ~ ~ facing entity @p[tag=bd_namelessClawTargetPunisher,tag=bd_punishedByNameless] eyes
execute as @a if score @s bd_playerId = @e[tag=bd_namelessClawPunisher,limit=1] bd_clawTargetID at @s run tp @e[tag=bd_namelessClawPunisher,limit=1] ~ ~ ~ facing entity @s eyes
