# Reset the punished player's score
#scoreboard players set @a[tag=bd_namelessClawTargetPunisher,tag=bd_punishedByNameless] bd_surfaceTimer 0

## Remove the tag from the targetted player
#tag @a[tag=bd_namelessClawTargetPunisher] remove bd_namelessClawTargetPunisher
#tag @a[tag=bd_punishedByNameless] remove bd_punishedByNameless


## Kill the claw
#kill @s

### Reset ONLY the owner's surface timer
execute as @a if score @s bd_playerId = @e[tag=bd_namelessClawPunisher,limit=1] bd_clawTargetID run scoreboard players set @s bd_surfaceTimer 0

### Remove punishment tags ONLY from the owner
execute as @a if score @s bd_playerId = @e[tag=bd_namelessClawPunisher,limit=1] bd_clawTargetID run tag @s remove bd_namelessClawTargetPunisher
execute as @a if score @s bd_playerId = @e[tag=bd_namelessClawPunisher,limit=1] bd_clawTargetID run tag @s remove bd_punishedByNameless

### Kill THIS claw
kill @s
