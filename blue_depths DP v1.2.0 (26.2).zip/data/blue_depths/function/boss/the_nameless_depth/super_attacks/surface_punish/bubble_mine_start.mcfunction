## Summon mine
execute at @s run summon marker ~ ~ ~ {Tags:["bd_bubbleMinePunish"]}

## Play sound effect
playsound minecraft:entity.elder_guardian.curse master @s ~ ~ ~ 4 1

## Trigger countdown
schedule function blue_depths:boss/the_nameless_depth/super_attacks/surface_punish/bubble_mine_end 60t append