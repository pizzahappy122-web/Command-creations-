# Play sound
playsound minecraft:entity.warden.angry master @s ~ ~ ~
playsound minecraft:entity.warden.angry master @s ~ ~ ~

# Particle effects
particle large_smoke ~ ~1.5 ~ .3 .3 .3 0 60

# Give player warning message
tellraw @s {"bold":true,"color":"red","text":"The Ocean calls for your return..."}
