## Add tag so punishing supers will target the right player
tag @s add bd_punishedByNameless


### Trigger the super attacks directed toward the punished player
# Bubble mine
execute as @s at @s run function blue_depths:boss/the_nameless_depth/super_attacks/surface_punish/bubble_mine_start

### Nerfed ink spray at player's location
## Physical effects
damage @s 2
effect give @s blindness 4 0 true
effect give @s weakness 4 0 false
## Spray particle effects
# Visual effects of the ink cloud
particle minecraft:squid_ink ~ ~1.5 ~ 1 1 1 0 100
# Sound effect
playsound minecraft:entity.squid.death master @s ~ ~ ~ 100 0.6

