## Base case: check for collision with player 
#execute as @s[tag=!bd_namelessClawGrabbedPunisher] at @s if entity @p[tag=bd_namelessClawTargetPunisher,tag=bd_punishedByNameless,distance=..1] run function blue_depths:boss/the_nameless_depth/super_attacks/surface_punish/tentacle_grab/tentacle_grab_hit
execute as @a if score @s bd_playerId = @e[tag=bd_namelessClawPunisher,limit=1] bd_clawTargetID at @s if entity @e[tag=bd_namelessClawPunisher,distance=..1] run function blue_depths:boss/the_nameless_depth/super_attacks/surface_punish/tentacle_grab/tentacle_grab_hit

## Base case: check for collision with slime (squid hitbox) if in return mode 
execute as @s[tag=bd_namelessClawGrabbedPunisher] at @s if entity @e[tag=bd_the_nameless_depth,type=slime,limit=1,sort=nearest,distance=..1] run function blue_depths:boss/the_nameless_depth/super_attacks/surface_punish/tentacle_grab/tentacle_grab_return
## Base case: The player dies
# Kill the claw if the player is dead
#execute as @s at @s if entity @a[tag=bd_namelessClawTargetPunisher,tag=bd_punishedByNameless,scores={bd_deathDetect=1..}] run function blue_depths:boss/the_nameless_depth/super_attacks/surface_punish/tentacle_grab/tentacle_grab_np
execute as @a[scores={bd_deathDetect=1..}] if score @s bd_playerId = @e[tag=bd_namelessClawPunisher,limit=1] bd_clawTargetID run function blue_depths:boss/the_nameless_depth/super_attacks/surface_punish/tentacle_grab/tentacle_grab_np


## Reposition the claw when following the player 
#tp @s[tag=!bd_namelessClawGrabbedPunisher] ~ ~ ~ facing entity @p[tag=bd_namelessClawTargetPunisher,tag=bd_punishedByNameless] feet 
execute as @a[tag=!bd_namelessClawGrabbedPunisher] if score @s bd_playerId = @e[tag=bd_namelessClawPunisher,limit=1] bd_clawTargetID at @s run tp @e[tag=bd_namelessClawPunisher,limit=1] ~ ~ ~ facing entity @s feet


## Reposition the claw when returning to the squid 
tp @s[tag=bd_namelessClawGrabbedPunisher] ~ ~ ~ facing entity @e[tag=bd_the_nameless_depth,type=slime,sort=nearest,limit=1] feet
#execute if entity @s[tag=bd_namelessClawGrabbedPunisher] run tp @p[tag=bd_namelessClawTargetPunisher,tag=bd_punishedByNameless] @s
# Drag owner player with the claw
execute as @a if score @s bd_playerId = @e[tag=bd_namelessClawPunisher,limit=1] bd_clawTargetID run tp @s @e[tag=bd_namelessClawPunisher,limit=1]

## Move claw forward 
tp @s ^ ^ ^0.25


# Particle 
particle minecraft:bubble_column_up ^0 ^0.5 ^-0.5 0 0 0 0 1 force
particle minecraft:dust{color:[1,0,0],scale:3} ^0 ^0.5 ^-0.5 0 0 0 0 1 force
