# Give targeted player a second dose of damage and apply effects
damage @p[tag=bd_namelessClawTarget] 5
effect give @p[tag=bd_namelessClawTarget] weakness 8 2
effect give @p[tag=bd_namelessClawTarget] slowness 8 1

# Remove any leftover tags from players
tag @a[tag=bd_namelessClawTarget] remove bd_namelessClawTarget

## Update boss target
execute as @e[type=drowned,tag=bd_the_nameless_depth,limit=1] at @s run function blue_depths:behavior/aggression/update_target


## Remove the claw
kill @s