# Tag itself to signify to return to squid
tag @s add bd_namelessClawGrabbed

# Give the initial damage to the targeted player
damage @p[tag=bd_namelessClawTarget] 5

# Change the beak to closed
item replace entity @s armor.head with minecraft:coal_block[minecraft:item_model="bluedepths:blue_depths/mobs/nameless_beak_closed"] 1
data modify entity @s drop_chances.head set value 0f

## Kill claw if it kills the player
#schedule function blue_depths:boss/the_nameless_depth/super_attacks/tentacle_grab/tentacle_grab_np 1t append