## Base case: check for collision with player 
execute as @s[tag=!bd_namelessClawGrabbed] at @s if entity @p[tag=bd_namelessClawTarget,distance=..1] run function blue_depths:boss/the_nameless_depth/super_attacks/tentacle_grab/tentacle_grab_hit
## Base case: check for collision with slime (squid hitbox) if in return mode 
execute as @s[tag=bd_namelessClawGrabbed] at @s if entity @e[tag=bd_the_nameless_depth,type=slime,limit=1,sort=nearest,distance=..1] run function blue_depths:boss/the_nameless_depth/super_attacks/tentacle_grab/tentacle_grab_return
## Base case: The player dies
# Kill the claw if the player is dead
execute as @s at @s if entity @a[tag=bd_namelessClawTarget,scores={bd_deathDetect=1..}] run function blue_depths:boss/the_nameless_depth/super_attacks/tentacle_grab/tentacle_grab_np


### General case: Keep moving toward it's target it is supposed to target ## Reposition the claw when following the player 
tp @s[tag=!bd_namelessClawGrabbed] ~ ~ ~ facing entity @p[tag=bd_namelessClawTarget] feet 

## Reposition the claw when returning to the squid 
tp @s[tag=bd_namelessClawGrabbed] ~ ~ ~ facing entity @e[tag=bd_the_nameless_depth,type=slime,sort=nearest,limit=1] feet
execute if entity @s[tag=bd_namelessClawGrabbed] run tp @p[tag=bd_namelessClawTarget] @s

## Move claw forward 
tp @s ^ ^ ^0.25


# Particle 
particle minecraft:bubble_column_up ^0 ^0.5 ^-0.5 0 0 0 0 1 force
particle minecraft:dust{color:[1,0,0],scale:3} ^0 ^0.5 ^-0.5 0 0 0 0 1 force
