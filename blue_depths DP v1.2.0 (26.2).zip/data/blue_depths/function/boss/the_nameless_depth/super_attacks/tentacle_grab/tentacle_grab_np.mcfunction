## Remove the tag from the targetted player
tag @a[tag=bd_namelessClawTarget] remove bd_namelessClawTarget

## Kill the claw
kill @s