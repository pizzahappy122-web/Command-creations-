# Kill old claw if it is still hanging around
kill @e[type=drowned,tag=bd_namelessClaw]
# Remove any leftover tags from players
tag @a[tag=bd_namelessClawTarget] remove bd_namelessClawTarget

### Summon the claw
summon drowned ~ ~ ~ {Silent:1b,DeathLootTable:"blue_depths:entities/nothing",PersistenceRequired:1b,NoAI:1b,Health:7f,IsBaby:1b,Tags:["bd_namelessClaw"],equipment:{head:{id:"minecraft:flint",count:1,components:{"minecraft:item_model":"bluedepths:blue_depths/mobs/nameless_beak_open"}}},drop_chances:{head:0.000},active_effects:[{id:"minecraft:invisibility",amplifier:0,duration:-1,show_particles:0b}],attributes:[{id:"minecraft:max_health",base:7}]}

# Tag player to follow
tag @r[distance=..70,gamemode=!creative,gamemode=!spectator,tag=!bd_punishedByNameless] add bd_namelessClawTarget

# Kill the claw if there is no valid target
execute unless entity @a[tag=bd_namelessClawTarget] run kill @e[type=drowned,tag=bd_namelessClaw,sort=nearest,limit=1]

## Play sound effect
playsound minecraft:entity.guardian.attack master @a[distance=..70] ~ ~ ~ 100 1
playsound minecraft:entity.evoker.prepare_attack master @a[distance=..70] ~ ~ ~ 100 1

## Position the claw
execute as @e[tag=bd_namelessClaw,sort=nearest,limit=1] at @s run tp @s ~ ~ ~ facing entity @p[tag=bd_namelessClawTarget] eyes