## Update boss target
execute as @e[type=drowned,tag=bd_the_nameless_depth,limit=1] at @s run function blue_depths:behavior/aggression/update_target
