################# summon armor stands for the wave #################
##### Spawn center #####
# Spawn center
summon armor_stand ~ ~ ~ {Silent:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["bd_nd_wave","bd_ndCenter"],attributes:[{id:"minecraft:scale",base:2.2}]}
# Fix rotation
data modify entity @e[type=armor_stand,tag=bd_ndCenter,limit=1,sort=nearest] Rotation[0] set from entity @p[gamemode=!creative,gamemode=!spectator] Rotation[0]


#### Spawn the rest of the wave
execute as @e[tag=bd_ndCenter] at @s run summon armor_stand ^2 ^ ^ {Silent:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["bd_nd_wave","bd_ndLeft"],attributes:[{id:"minecraft:scale",base:2.2}]}
data modify entity @e[type=armor_stand,tag=bd_ndLeft,limit=1,sort=nearest] Rotation[0] set from entity @p[gamemode=!creative,gamemode=!spectator] Rotation[0]

execute as @e[tag=bd_ndLeft] at @s run summon armor_stand ^2 ^ ^ {Silent:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["bd_nd_wave","bd_ndLeftLeft"],attributes:[{id:"minecraft:scale",base:2.2}]}
data modify entity @e[type=armor_stand,tag=bd_ndLeftLeft,limit=1,sort=nearest] Rotation[0] set from entity @p[gamemode=!creative,gamemode=!spectator] Rotation[0]

execute as @e[tag=bd_ndLeftLeft] at @s run summon armor_stand ^2 ^ ^ {Silent:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["bd_nd_wave","bd_ndLeftLeftLeft"],attributes:[{id:"minecraft:scale",base:2.2}]}
data modify entity @e[type=armor_stand,tag=bd_ndleftLeftLeft,limit=1,sort=nearest] Rotation[0] set from entity @p[gamemode=!creative,gamemode=!spectator] Rotation[0]

execute as @e[tag=bd_ndCenter] at @s run summon armor_stand ^-2 ^ ^ {Silent:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["bd_nd_wave","bd_ndRight"],attributes:[{id:"minecraft:scale",base:2.2}]}
data modify entity @e[type=armor_stand,tag=bd_ndRight,limit=1,sort=nearest] Rotation[0] set from entity @p[gamemode=!creative,gamemode=!spectator] Rotation[0]

execute as @e[tag=bd_ndRight] at @s run summon armor_stand ^-2 ^ ^ {Silent:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["bd_nd_wave","bd_ndRightRight"],attributes:[{id:"minecraft:scale",base:2.2}]}
data modify entity @e[type=armor_stand,tag=bd_ndRightRight,limit=1,sort=nearest] Rotation[0] set from entity @p[gamemode=!creative,gamemode=!spectator] Rotation[0]

execute as @e[tag=bd_ndRightRight] at @s run summon armor_stand ^-2 ^ ^ {Silent:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["bd_nd_wave","bd_ndRightRightRight"],attributes:[{id:"minecraft:scale",base:2.2}]}
data modify entity @e[type=armor_stand,tag=bd_ndRightRightRight,limit=1,sort=nearest] Rotation[0] set from entity @p[gamemode=!creative,gamemode=!spectator] Rotation[0]

### Play sound effects
playsound minecraft:block.conduit.activate master @a[distance=..50] ~ ~ ~ 100 1
playsound minecraft:block.bubble_column.upwards_ambient master @a[distance=..50] ~ ~ ~ 100 1
playsound minecraft:entity.ender_dragon.flap master @a[distance=..50] ~ ~ ~ 100 1

#### Intialize the steps for the ray cast
scoreboard players set @e[type=armor_stand,tag=bd_nd_wave] bd_raycast 256

## schedule boss retarget after bubble wave dies
schedule function blue_depths:boss/the_nameless_depth/super_attacks/bubble_wave/bubble_wave_update 256t append