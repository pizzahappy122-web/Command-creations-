### Recursive function for moving the bubble wave

### Base case: reach the end of it's lifetime
execute as @s[scores={bd_raycast=..1}] at @s run kill @s



### General case: Keep moving and damage any players near

# Check for collisions with players
execute if entity @a[distance=..2.5] run function blue_depths:boss/the_nameless_depth/super_attacks/bubble_wave/bubble_wave_hit

# Move forward according to step size
tp @s ^ ^ ^-0.25

# Particle
particle minecraft:bubble ~ ~1.5 ~ .6 1.5 .6 0 10

# Decrease the number of steps remaining
scoreboard players remove @s bd_raycast 1