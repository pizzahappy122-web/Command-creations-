## Apply effects
execute as @a[distance=..2.5,tag=!bd_waveHit,gamemode=!creative,gamemode=!spectator] run damage @s 25 mob_projectile
execute as @a[distance=..2.5,tag=!bd_waveHit,gamemode=!creative,gamemode=!spectator] run effect give @s slowness 8 2

# Add tag to mark player to not get hit anymore
tag @a[distance=..1.5,tag=!bd_waveHit,gamemode=!creative,gamemode=!spectator] add bd_waveHit

# Schedule to remove mark
schedule function blue_depths:boss/the_nameless_depth/super_attacks/bubble_wave/bubble_wave_cleanup 5t append