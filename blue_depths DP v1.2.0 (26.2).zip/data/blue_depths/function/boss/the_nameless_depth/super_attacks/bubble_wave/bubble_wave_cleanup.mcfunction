# Remove tag so player can get hit with wave again
tag @a[tag=bd_waveHit] remove bd_waveHit