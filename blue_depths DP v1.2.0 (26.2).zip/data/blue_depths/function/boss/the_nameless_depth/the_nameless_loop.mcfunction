
# Fix rotations
execute as @e[type=minecraft:drowned,tag=bd_the_nameless_depth] at @s store result entity @e[type=minecraft:slime,tag=bd_the_nameless_depth,limit=1,sort=nearest] Rotation[0] float 1 run data get entity @s Rotation[0]
execute as @e[type=minecraft:slime,tag=bd_the_nameless_depth] at @s store result entity @e[type=minecraft:armor_stand,tag=bd_the_nameless_depth,limit=1,sort=nearest] Rotation[0] float 1 run data get entity @s Rotation[0]

### Raycast
# Bubble wave raycast
execute as @e[type=armor_stand,tag=bd_nd_wave,scores={bd_raycast=1..}] at @s run function blue_depths:boss/the_nameless_depth/super_attacks/bubble_wave/bubble_wave_move
# Claw raycast (default)
execute as @e[type=drowned,tag=bd_namelessClaw] at @s run function blue_depths:boss/the_nameless_depth/super_attacks/tentacle_grab/tentacle_grab_move

# Display the Boss Health Bar
execute if entity @e[tag=bd_the_nameless_depth,type=slime,limit=1] run bossbar set nameless_depth players @a
execute store result bossbar nameless_depth value run data get entity @e[tag=bd_the_nameless_depth,type=slime,limit=1] Health

# Visual effects of the ink cloud
execute as @e[type=marker,tag=bd_inkCloud] at @s run particle minecraft:squid_ink ~ ~1.5 ~ 1 1 1 0 100

# Sound when hurt
execute as @e[type=slime,tag=bd_the_nameless_depth,nbt={HurtTime:10s}] at @s run playsound entity.squid.hurt master @a[distance=..50] ~ ~ ~ 1 0.5


# Reset death count
scoreboard players set @a bd_deathDetect 0