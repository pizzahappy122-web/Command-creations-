##### Check armor stands #####
execute as @e[type=minecraft:armor_stand,tag=bd_mob,tag=bd_bucketable,tag=!bd_killModel] at @s unless entity @e[type=#blue_depths:bucketable_bases,distance=..1,tag=bd_mob] run function blue_depths:cleanup/check_model


##############Test
#execute as @e[type=salmon,tag=test] at @s if entity @a[distance=..4.5] run say hi
#execute as @e[type=minecraft:marker,tag=test] at @s if entity @a[distance=..4] run say hello

####### Detect bucket usage for picking up mobs #########
execute as @a[scores={bdBucketUse=1..}] at @s if entity @e[type=minecraft:drowned,tag=bd_bucketUser,distance=..3] run function blue_depths:mobs/bucket_user_master

########## BOSS LOOP ##########
execute if score bossLoop bd_bossFlag matches 1 run function blue_depths:boss/boss_loop

####### Fix mob rotations #######
execute as @e[type=minecraft:salmon,tag=bd_mob] at @s store result entity @n[type=minecraft:armor_stand,tag=bd_mob,distance=..2.2] Rotation[0] float 1 run data get entity @s Rotation[0]
execute as @e[type=minecraft:cod,tag=bd_mob] at @s store result entity @n[type=minecraft:armor_stand,tag=bd_mob,distance=..2.2] Rotation[0] float 1 run data get entity @s Rotation[0]
execute as @e[type=minecraft:drowned,tag=bd_mob,tag=!bd_bottomDweller] at @s store result entity @n[type=minecraft:armor_stand,tag=bd_mob,distance=..2.2] Rotation[0] float 1 run data get entity @s Rotation[0]
execute as @e[type=minecraft:dolphin,tag=bd_mob] at @s store result entity @n[type=minecraft:armor_stand,tag=bd_mob,distance=..2.2] Rotation[0] float 1 run data get entity @s Rotation[0]
execute as @e[type=minecraft:turtle,tag=bd_mob] at @s store result entity @n[type=minecraft:armor_stand,tag=bd_mob,distance=..2.2] Rotation[0] float 1 run data get entity @s Rotation[0]


####### Block functions #######
# place function
execute as @e[type=minecraft:glow_item_frame,tag=bd_block,tag=!bd_placedBlock] at @s run function blue_depths:blocks/master_place
# remove function
execute as @e[type=minecraft:glow_item_frame,tag=bd_block,tag=bd_placedBlock] at @s unless block ~ ~ ~ #blue_depths:block_bases run function blue_depths:blocks/master_remove

######## Aggro Mob activation #########
execute as @e[type=#blue_depths:neutral_bases,tag=bd_neutralMob,nbt={HurtTime:10s}] at @s run function blue_depths:behavior/aggression/turn_aggro


############### Staff Items ################
# Decrement staff cooldown timer for all players who have used a staff
execute as @a[scores={bd_staffCooldown=1..}] at @s run scoreboard players remove @s bd_staffCooldown 1
# Move Nameless Bullet
execute as @e[type=armor_stand,tag=bd_namelessBullet] at @s run function blue_depths:nameless_staff/ray/spell_move


############### Raycast movements ################
execute as @e[type=#blue_depths:raycast_entities,tag=bd_projectile] at @s run function blue_depths:misc/rc_move_master

###### Reset any usages #######
## Reset bucket usage
execute as @a run scoreboard players set @s bdBucketUse 0
