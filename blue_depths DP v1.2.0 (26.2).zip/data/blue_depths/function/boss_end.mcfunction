##### Reset and kill the boss

# Remove boss bar
bossbar remove nameless_depth

# Kill the boss
kill @e[type=slime,tag=bd_the_nameless_depth,sort=nearest,limit=1]

# Reset scoreboard to not have loop run anymore
scoreboard players reset bossLoop bd_bossFlag
scoreboard players reset theNamelessDepth bd_bossFlag

# Reset scoreboard for players
scoreboard objectives remove bd_deathDetect
scoreboard objectives remove bd_surfaceTimer