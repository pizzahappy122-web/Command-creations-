### Block loops
execute as @e[type=minecraft:glow_item_frame,tag=bd_blocksEvent] at @s run function blue_depths:blocks/master_check

## Reschedule
schedule function blue_depths:30t 30t