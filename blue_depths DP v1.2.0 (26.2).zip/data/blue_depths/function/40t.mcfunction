################### Legacy handling
########## 1.1 handling
###### Tag catfish that don't have the correct tags after roaring rivers part 1
execute as @e[type=drowned,tag=!bd_bottomDweller,tag=bd_catfish] at @s run function blue_depths:temp_functions/tag_legacy_catfish
###### Replace old great white shark pups with updated versions (from drowned base to salmon base)
execute as @e[type=drowned,tag=bd_greatWhitePup] at @s run function blue_depths:mobs/gw_shark/pup/gw_pup_spawn

###### Mob loops ######
## Cod base for mob baby loops and other such things
execute as @e[tag=bd_stunted,type=cod] run function blue_depths:mobs/cod_base_slow_loop

## Charge/timed mobs increments
execute as @e[tag=bd_cooldown] at @s if entity @a[distance=..50] if score @s bd_atkCool matches 0.. run function blue_depths:behavior/aggression/timed_events/mob_navigator


###### Block loops #######
# Detect contents of the catalyst for the boss trigger
execute as @e[type=minecraft:glow_item_frame,tag=bd_namelessBlock] at @s if entity @a[distance=..8,limit=1] run function blue_depths:blocks/nameless_block/detect_contents

### Give player book
execute as @a unless score @s bd_bookSpawn matches 4 run function blue_depths:misc/make_book
## Unlock recipes upon reload or first load
execute as @a[tag=!bd_unlockRecipes] run function blue_depths:misc/unlock_recipes



## Reschedule
schedule function blue_depths:40t 40t