#### Crocodiles ####

# Adult Crocodile
execute if entity @s[tag=bd_crocodile,tag=!bd_crocLunge] run function blue_depths:mobs/crocodile/transform

# Hatchling Crocodile
execute if entity @s[tag=bd_crocHatchling] run function blue_depths:mobs/crocodile/croc_juvenile/juvenile_transform