#### Reset who the target is #####
## Turn AI on and off to make mob forget who it was attacking
# Turn AI Off
data modify entity @s NoAI set value 1b
# Turn AI back on
data modify entity @s NoAI set value 0b