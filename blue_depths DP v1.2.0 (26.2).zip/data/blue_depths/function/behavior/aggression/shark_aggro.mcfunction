### Great White shark
# Passive Great White Shark
execute if entity @s[tag=bd_gw_shark] run function blue_depths:mobs/gw_shark/gw_shark_aggro
# Curious Great White Shark
execute if entity @s[tag=bd_cur_gw_shark] run function blue_depths:mobs/gw_shark/gw_shark_aggro

### Bull Shark
execute if entity @s[tag=bd_bullShark] run function blue_depths:mobs/bull_shark/bull_shark_aggro