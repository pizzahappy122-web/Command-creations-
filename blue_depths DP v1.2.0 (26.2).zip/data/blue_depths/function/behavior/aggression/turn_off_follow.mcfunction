## Turn AI on and off to make mob forget who it was attacking
# Turn AI Off
data modify entity @s NoAI set value 1b
# Turn AI back on
data modify entity @s NoAI set value 0b

# Turn off follow range
attribute @s minecraft:follow_range base set 0

# Flag as not following to avoid repeated change
scoreboard players set @s followRangeFlag 0