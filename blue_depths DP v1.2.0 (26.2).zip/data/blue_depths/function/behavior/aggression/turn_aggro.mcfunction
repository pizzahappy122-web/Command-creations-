### Sharks
execute at @s if entity @s[tag=bd_shark] run function blue_depths:behavior/aggression/shark_aggro

### Electric Eel
execute at @s if entity @s[tag=bd_electricEel] run function blue_depths:mobs/electric_eel/zap

### Crocodile Pet
execute at @s if entity @s[tag=bd_crocodile,tag=bd_pet] run function blue_depths:mobs/crocodile/croc_pet/croc_aggro