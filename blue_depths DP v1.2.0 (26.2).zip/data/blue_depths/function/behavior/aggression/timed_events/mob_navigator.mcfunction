
## Archerfish timer
execute as @s if entity @s[type=cod,tag=bd_archerfish] run function blue_depths:mobs/archerfish/attack_timer

## Bull Shark timer
execute as @s if entity @s[type=salmon,tag=bd_bullShark,tag=!bd_aggroBullShark] run function blue_depths:mobs/bull_shark/aggro_timer

### Crocodile
# Crocodile (Wild) Timer
execute as @s if entity @s[type=drowned,tag=bd_crocodile,tag=!bd_crocLunge,tag=!bd_pet] at @s run function blue_depths:mobs/crocodile/atk_timer
# Crocodile (Pet) Timer
execute as @s if entity @s[type=minecraft:drowned,tag=bd_crocodile,tag=bd_pet,tag=!bd_crocLunge] at @s run function blue_depths:mobs/crocodile/croc_pet/atk_timer
