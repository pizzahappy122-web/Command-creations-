# Turn on follow range
attribute @s minecraft:follow_range base set 40

# Flag as not following to avoid repeated change
scoreboard players set @s followRangeFlag 1