kill @n[tag=bd_mob]
kill @n[tag=bd_nameless_depth]