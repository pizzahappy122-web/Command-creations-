kill @e[tag=bd_mob]
kill @e[tag=bd_nameless_depth]