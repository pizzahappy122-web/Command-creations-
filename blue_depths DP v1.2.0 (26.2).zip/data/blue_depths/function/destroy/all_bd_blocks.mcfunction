# Destroy blocks and return items
# Grill
execute as @e[type=glow_item_frame,tag=bd_block,tag=bd_seagrill] at @s run function blue_depths:misc/blocks_cleanup/grill
# Catalyst
execute as @e[type=glow_item_frame,tag=bd_namelessBlock] at @s run function blue_depths:misc/blocks_cleanup/catalyst
# Crafter
execute as @e[type=glow_item_frame,tag=bd_seacrafter] at @s run function blue_depths:misc/blocks_cleanup/crafter
# Electrode
execute as @e[type=glow_item_frame,tag=bd_electrode] at @s run function blue_depths:misc/blocks_cleanup/electrode
