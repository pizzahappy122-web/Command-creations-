# Summon display
summon armor_stand ~ ~1.3 ~ {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["bd_display","bd_box_jelly"],equipment:{mainhand:{id:"minecraft:flint",count:1,components:{"minecraft:item_model":"bluedepths:blue_depths/mobs/box_jellies/ghost_box_jellyfish"}}}}

# Fix rotation
data modify entity @n[type=armor_stand,tag=bd_display,tag=bd_box_jelly] Rotation[0] set from entity @p Rotation[0]
