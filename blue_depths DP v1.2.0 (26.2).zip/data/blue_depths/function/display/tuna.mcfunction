# Summon display
summon armor_stand ~ ~1 ~ {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["bd_display","bd_tuna"],equipment:{mainhand:{id:"minecraft:flint",count:1,components:{"minecraft:item_model":"bluedepths:blue_depths/mobs/tuna"}}}}

# Fix rotation
data modify entity @n[type=armor_stand,tag=bd_display,tag=bd_tuna] Rotation[0] set from entity @p Rotation[0]
