summon drowned ~ ~1 ~ {NoGravity:1b,Silent:1b,Invulnerable:1b,NoAI:1b,IsBaby:1b,Tags:["bd_display","bd_catfish"],equipment:{head:{id:"minecraft:flint",count:1,components:{"minecraft:item_model":"bluedepths:blue_depths/mobs/catfish"}}},active_effects:[{id:"minecraft:invisibility",amplifier:0,duration:-1,show_particles:0b}]}

# Fix rotation
data modify entity @n[type=drowned,tag=bd_display,tag=bd_catfish] Rotation[0] set from entity @p Rotation[0]
