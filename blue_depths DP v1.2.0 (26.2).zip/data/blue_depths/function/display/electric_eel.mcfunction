summon drowned ~ ~1 ~ {NoGravity:1b,Silent:1b,Invulnerable:1b,NoAI:1b,IsBaby:1b,Tags:["bd_display","bd_electricEel"],equipment:{head:{id:"minecraft:flint",count:1,components:{"minecraft:item_model":"bluedepths:mobs/electric_eel"}}},active_effects:[{id:"minecraft:invisibility",amplifier:0,duration:-1,show_particles:0b}]}

# Fix rotation
data modify entity @n[type=drowned,tag=bd_display,tag=bd_electricEel] Rotation[0] set from entity @p Rotation[0]
