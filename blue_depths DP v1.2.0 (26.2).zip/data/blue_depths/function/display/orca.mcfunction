# Summon display
summon armor_stand ~ ~1 ~ {NoGravity:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["bd_display","bd_orca"],equipment:{mainhand:{id:"minecraft:flint",count:1,components:{"minecraft:item_model":"bluedepths:blue_depths/mobs/orca"}}}}

# Fix rotation
data modify entity @n[type=armor_stand,tag=bd_display,tag=bd_orca] Rotation[0] set from entity @p Rotation[0]
