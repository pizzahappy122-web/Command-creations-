tag @s add bd_bottomDweller
tag @s add bd_passiveDrownedBase