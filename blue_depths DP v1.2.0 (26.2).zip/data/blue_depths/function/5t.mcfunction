##### Check armor stands #####
execute as @e[type=minecraft:armor_stand,tag=bd_mob,tag=bd_bucketableBase,tag=!bd_bucketable,tag=!bd_killModel] at @s unless entity @e[type=#blue_depths:bucketable_bases,distance=..1.3,tag=bd_mob] run function blue_depths:cleanup/big_check_model

### Mobs
# Return drowned based water only mobs back to the water
execute as @e[type=drowned,tag=bd_atk_fish,predicate=!blue_depths:is_in_water] at @s if predicate blue_depths:night_check run tp @s ^ ^-1 ^-1
# Animate semi-aquatic mobs
execute as @e[type=#blue_depths:semi_aquatic,tag=bd_semiAquatic] at @s if entity @a[distance=..40] run function blue_depths:behavior/transform_semiaquatic

## Reschedule
schedule function blue_depths:5t 5t