# Bull Shark Pup
execute at @s if entity @s[tag=bd_bullSharkPup] run function blue_depths:mobs/bull_shark/pup/bull_pup_loop

# Crocodile Egg
execute at @s if entity @s[tag=bd_crocEgg] run function blue_depths:mobs/crocodile/croc_egg/croc_egg_loop
