### Catfish
# Default Catfish
execute if entity @e[type=minecraft:drowned,tag=bd_catfish,tag=!bd_popEyes] run function blue_depths:mobs/catfish/bucket_fill
# Pop Eyes Easter Egg Vatfish
execute if entity @e[type=minecraft:drowned,tag=bd_catfish,tag=bd_popEyes] run function blue_depths:mobs/catfish/pop_eyes/bucket_fill

### Electric Eel
execute if entity @e[type=minecraft:drowned,tag=bd_electricEel] run function blue_depths:mobs/electric_eel/give_electric_eel_bucket