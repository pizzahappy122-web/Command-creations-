# Great White Shark Pup
execute as @s[tag=bd_greatWhitePup] at @s run function blue_depths:mobs/gw_shark/pup/gw_pup_loop
