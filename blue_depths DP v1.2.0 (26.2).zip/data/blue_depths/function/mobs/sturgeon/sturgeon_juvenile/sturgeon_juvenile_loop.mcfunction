#Counter
scoreboard players add @s marineGrowth 1

# Feed and speed up growth
execute if entity @e[type=item,nbt={Item:{id:"minecraft:cod",count:1}},distance=..3] run function blue_depths:mobs/sturgeon/sturgeon_juvenile/food/cod

# Feed and speed up growth
execute if entity @e[type=item,nbt={Item:{id:"minecraft:spider_eye",count:1}},distance=..3] run function blue_depths:mobs/sturgeon/sturgeon_juvenile/food/spider_eye

# Feed and stunt growth
execute if entity @e[type=item,nbt={Item:{id:"minecraft:beetroot",count:1}},distance=..3] run function blue_depths:mobs/sturgeon/sturgeon_juvenile/sturgeon_juvenile_stunt

#Trigger growth once age is reached
execute as @s[scores={marineGrowth=2400..}] at @s run function blue_depths:mobs/sturgeon/sturgeon_juvenile/sturgeon_juvenile_grow