#Speed up growth by some seconds
scoreboard players add @s marineGrowth 120

#Eating sound effect
playsound minecraft:entity.generic.eat master @a[distance=..5]

#Kill item
execute as @e[type=item,nbt={Item:{id:"minecraft:spider_eye",count:1}},sort=nearest,limit=1] at @s run kill @s