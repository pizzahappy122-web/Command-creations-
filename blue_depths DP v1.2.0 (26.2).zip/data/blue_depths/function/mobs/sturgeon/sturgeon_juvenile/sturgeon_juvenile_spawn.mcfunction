# Spawn Juvenile
summon cod ~ ~ ~ {Silent:1b,DeathLootTable:"blue_depths:entities/nothing",PersistenceRequired:1b,NoAI:0b,Health:8f,Tags:["bd_juv_sturgeon","bd_mob","bd_scanned","bd_mobGrowth","bd_bucketableBase"],Passengers:[{id:"minecraft:armor_stand",Silent:1b,Invulnerable:1b,Small:1b,Marker:1b,Invisible:1b,Tags:["bd_juv_sturgeon","bd_mob","bd_scanned","bd_bucketableBase","bd_mobGrowth"],attributes:[{id:"minecraft:scale",base:0.8}],equipment:{offhand:{id:"minecraft:flint",count:1,components:{"minecraft:item_model":"bluedepths:blue_depths/mobs/sturgeon"}}}}],active_effects:[{id:"minecraft:resistance",amplifier:2,duration:-1,show_particles:0b},{id:"minecraft:invisibility",amplifier:0,duration:-1,show_particles:0b}],attributes:[{id:"minecraft:max_health",base:8}]}
# 20 % chance to spawn a twin juvenile
execute unless entity @s[type=minecraft:armor_stand] if predicate blue_depths:20_percent_chance run summon cod ~ ~ ~ {Silent:1b,DeathLootTable:"blue_depths:entities/nothing",PersistenceRequired:1b,NoAI:0b,Health:8f,Tags:["bd_juv_sturgeon","bd_mob","bd_scanned","bd_mobGrowth","bd_bucketableBase"],Passengers:[{id:"minecraft:armor_stand",Silent:1b,Invulnerable:1b,Small:1b,Marker:1b,Invisible:1b,Tags:["bd_juv_sturgeon","bd_mob","bd_scanned","bd_bucketableBase","bd_mobGrowth"],attributes:[{id:"minecraft:scale",base:0.8}],equipment:{offhand:{id:"minecraft:flint",count:1,components:{"minecraft:item_model":"bluedepths:blue_depths/mobs/sturgeon"}}}}],active_effects:[{id:"minecraft:resistance",amplifier:2,duration:-1,show_particles:0b},{id:"minecraft:invisibility",amplifier:0,duration:-1,show_particles:0b}],attributes:[{id:"minecraft:max_health",base:8}]}

#Add to juvenile growth scoreboard
scoreboard players add @n[tag=bd_juv_sturgeon,tag=!bd_juv_sturgeon2,type=cod] marineGrowth 0

# Add second juvenile to growth scoreboard
scoreboard players add @n[tag=bd_juv_sturgeon,tag=bd_juv_sturgeon2,type=cod] marineGrowth 0

### If self is an armor stand
# Remove the bucket of salmon and replace with water bucket
execute if entity @s[type=minecraft:armor_stand] run function blue_depths:cleanup/bucket_sawp/big_cod_swap


#Kill larva
tp @s ~ ~-500 ~
kill @s