#Increase counter
scoreboard players add @s marineGrowth 1

#Kill if not in water
execute unless block ~ ~ ~ water run kill @s

# Feed and stunt growth
execute if entity @e[type=item,nbt={Item:{id:"minecraft:coal",count:1}},distance=..3] run function blue_depths:mobs/sturgeon/sturgeon_eggs/sturgeon_egg_stunt

#Trigger growth once age is reached
execute as @s[scores={marineGrowth=100..}] at @s run function blue_depths:mobs/sturgeon/sturgeon_juvenile/sturgeon_juvenile_spawn