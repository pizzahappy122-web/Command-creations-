#Spawn the eggs
summon cod ~ ~ ~ {DeathLootTable:"blue_depths:entities/nothing",PersistenceRequired:1b,NoAI:1b,Health:1f,Tags:["bd_mob","bd_scanned","bd_sturgeon_eggs","bd_mobGrowth","bd_bucketableBase"],Passengers:[{id:"minecraft:armor_stand",Silent:1b,Invulnerable:1b,Small:1b,Marker:1b,Invisible:1b,Tags:["bd_mob","bd_sturgeon_eggs","bd_bucketableBase","bd_mobGrowth"],equipment:{mainhand:{id:"minecraft:flint",count:1,components:{"minecraft:item_model":"bluedepths:blue_depths/mobs/sturgeon_eggs"}}}}],active_effects:[{id:"minecraft:invisibility",amplifier:0,duration:-1,show_particles:0b}],attributes:[{id:"minecraft:max_health",base:1}]}

# Add to sturgeon eggs to growth scoreboard
scoreboard players add @e[tag=bd_sturgeon_eggs,type=cod,sort=nearest,limit=1] marineGrowth 0

#Playsound
execute unless entity @s[type=armor_stand] run playsound minecraft:entity.tropical_fish.flop master @a[distance=..6]

### If self is an armor stand
# Remove the bucket of salmon and replace with water bucket
execute if entity @s[type=minecraft:armor_stand] run function blue_depths:cleanup/bucket_sawp/big_cod_swap


#Kill placeholder fish
tp @s ~ ~-500 ~
kill @s