# Juvenile Tuna loop
execute as @s[tag=bd_tuna_young] at @s run function blue_depths:mobs/tuna/tuna_juvenile/tuna_juvenile_loop

# Sturgeon egg loop
execute as @s[tag=bd_sturgeon_eggs] at @s run function blue_depths:mobs/sturgeon/sturgeon_eggs/sturgeon_egg_loop

# Juvenile Sturgeon loop
execute as @s[tag=bd_juv_sturgeon] at @s run function blue_depths:mobs/sturgeon/sturgeon_juvenile/sturgeon_juvenile_loop

# Juvenile Box Jellyfish loop
execute as @s[tag=bd_boxJelly] at @s run function blue_depths:mobs/box_jelly/juvenile_loop