## Provide knockback effect to player
execute as @a[distance=..1.2,gamemode=!spectator,gamemode=!creative] run damage @s 0.5 minecraft:cactus

## Damage all other entities
execute as @e[distance=..1.2,type=!#blue_depths:staff_ignore,tag=!bd_archerfish] unless entity @s[type=minecraft:player] run damage @s 10 minecraft:cactus

#### Visual and sound effects
particle minecraft:falling_water ~ ~ ~ 0.3 0.4 0.3 1 60 force
playsound block.wet_sponge.break master @a[distance=..6] ~ ~ ~

## Kill the ray
kill @s