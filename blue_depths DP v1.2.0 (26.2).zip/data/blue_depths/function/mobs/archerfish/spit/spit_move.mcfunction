# Move forward according to step size
tp @s ^ ^ ^0.25

## particle trail
particle minecraft:falling_water ^0 ^0 ^0 0.1 0.15 0.1 0 20 force

### Case: If colliding with a mob or player
execute as @s at @s if entity @e[type=!#blue_depths:staff_ignore,distance=..1.2,tag=!bd_archerfish] run function blue_depths:mobs/archerfish/spit/spit_hit

### Base case: If spit reaches end of lifetime, trigger hit
execute as @s[scores={bd_raycast=..0}] at @s run kill @s

### Base case: If spit collides with glass, simply kill the spit and end it's processes
execute if block ^ ^ ^0.5 #blue_depths:glass at @s run kill @s

### Base case: If spit collides with a solid block, trigger it's hit, then kill
execute unless block ~ ~ ~ #blue_depths:ray_permeable run function blue_depths:mobs/archerfish/spit/spit_hit

## Decrease number of steps left
scoreboard players remove @s bd_raycast 1

