### Summon ray
summon marker ~ ~ ~ {Tags:["bd_archerfishSpit","bd_projectile"]}

#Position raycast facing the bug
execute anchored eyes rotated as @s facing entity @n[type=#blue_depths:archerfish_target,distance=..10] feet run tp @n[tag=bd_archerfishSpit,type=marker] ^ ^ ^ ~ ~

## Give slowness effect temporarily so fish doesn't get hit with it's own spit
#effect give @s minecraft:slowness 2 10 true

# Initialize steps of the ray
scoreboard players set @n[type=marker,tag=bd_archerfishSpit] bd_raycast 50

### Sound effect
playsound entity.fox.spit master @a[distance=..6] ~ ~ ~
## particle effects
particle minecraft:falling_water ^0 ^0 ^0 0.13 0.1 0.12 0 20 force