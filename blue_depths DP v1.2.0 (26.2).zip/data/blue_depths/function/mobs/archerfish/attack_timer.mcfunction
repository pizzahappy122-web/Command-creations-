### Increment counter
scoreboard players add @s bd_atkCool 1

####### If 6 seconds has passed, trigger spit attack (runs in 40t so each increment happens every 2 seconds) #######
# Target nearest insect
execute as @s at @s if score @s bd_atkCool matches 3 if entity @e[type=#blue_depths:archerfish_target,distance=..10] run function blue_depths:mobs/archerfish/spit/spit_cast_mob
# Target nearest player (if no insects)
execute as @s at @s if score @s bd_atkCool matches 3 if entity @a[distance=..10,predicate=!blue_depths:is_in_water,gamemode=!spectator,gamemode=!creative] unless entity @e[type=#blue_depths:archerfish_target,distance=..10] run function blue_depths:mobs/archerfish/spit/spit_cast_player

### Reset attack timer
execute if score @s bd_atkCool matches 3 run scoreboard players set @s bd_atkCool 0