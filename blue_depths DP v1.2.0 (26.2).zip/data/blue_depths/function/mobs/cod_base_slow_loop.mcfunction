# Sturgeon egg loop
execute as @s[tag=bd_sturgeon_eggs_stunt] at @s unless block ~ ~ ~ water run kill @s

# Box jelly polyp loop
execute as @s[tag=box_jelly_stunted] at @s unless block ~ ~ ~ water run kill @s
