#Remove bucket
clear @s minecraft:bucket 1

# Give spawn egg as "bucket"
give @s cod_spawn_egg[custom_name={"italic":false,"text":"Bucket of Pop Eyes"},item_model="bluedepths:items/pop_eyes_bucket",entity_data={id:"minecraft:cod",Tags:["bd_popEyesBucket","bd_fishReplace"],active_effects:[{id:"minecraft:resistance",amplifier:10,duration:40,show_particles:0b},{id:"minecraft:invisibility",amplifier:0,duration:-1,show_particles:0b}]}] 1

#Sound effect for bucket fill
playsound minecraft:item.bucket.fill_fish master @s

# Remove extra water that's placed when bucket is used
execute as @e[type=minecraft:drowned,tag=bd_catfish,sort=nearest,limit=1] at @s run fill ~-1 ~-1 ~-1 ~1 ~1 ~1 air replace minecraft:water[level=0]

#Kill catfish
tp @e[type=minecraft:drowned,tag=bd_catfish,sort=nearest,limit=1] ~ ~-500 ~