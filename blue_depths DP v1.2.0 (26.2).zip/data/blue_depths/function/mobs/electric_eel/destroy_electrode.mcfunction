### Destroy block
setblock ~ ~ ~ air destroy

### Effects
playsound entity.generic.explode master @a[distance=..10] ~ ~ ~ 0.3
particle minecraft:block{block_state:"minecraft:redstone_block"} ~ ~0.2 ~ 0.3 0.3 0.3 0.1 30