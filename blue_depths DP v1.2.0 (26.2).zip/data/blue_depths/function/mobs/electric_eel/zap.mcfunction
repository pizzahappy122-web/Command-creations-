### Damage mobs
execute as @e[distance=..8,type=!#blue_depths:staff_ignore,tag=!bd_electricEel,type=!player] at @s run damage @s 6 minecraft:out_of_world
### Damage players
execute as @a[distance=..5,gamemode=!creative,gamemode=!spectator] at @s run damage @s 4 minecraft:out_of_world

### Destroy nearby electrodes
execute as @e[type=glow_item_frame,tag=bd_electrode,distance=..5] at @s run function blue_depths:mobs/electric_eel/destroy_electrode

### Effects
#Particle Effects
particle dust_color_transition{from_color:[0.529,0.808,0.980],to_color:[0.000,0.000,0.804],scale:2} ~ ~1 ~ 2.5 2.5 2.5 0.1 40 normal
# Sound effect
playsound bluedepths:zap master @a[distance=..5] ~ ~ ~ 0.4 1.2