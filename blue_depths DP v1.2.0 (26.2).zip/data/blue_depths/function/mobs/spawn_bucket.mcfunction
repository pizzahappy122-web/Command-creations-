######### Spawn the appropriate mob when bucket is empty

### Catfish
# Normal Variant
execute as @s if entity @s[tag=bd_catfishBucket] at @s run function blue_depths:mobs/catfish/bucket_empty
# Pop Eyes Easter Egg Variant
execute as @s if entity @s[tag=bd_popEyesBucket] at @s run function blue_depths:mobs/catfish/pop_eyes/bucket_empty

### Largemouth Bass
execute as @s if entity @s[tag=bd_lmBassBucket] at @s run function blue_depths:mobs/lm_bass/bucket_empty_lmbass

### Archerfish
execute as @s if entity @s[tag=bd_archerfishBucket] at @s run function blue_depths:mobs/archerfish/bucket/bucket_empty_archerfish

### Electric Eel
execute as @s if entity @s[tag=bd_electricEelBucket] at @s run function blue_depths:mobs/electric_eel/electric_eel_bucket_empty

### Bluegill
# Normal
execute as @s if entity @s[tag=bd_bluegillBucket] at @s run function blue_depths:mobs/bluegill/bluegill_bucket_empty
# Evil Incarnate
execute as @s if entity @s[tag=bd_bluegillEvilBucket] at @s run function blue_depths:mobs/bluegill/evil_incarnate_empty