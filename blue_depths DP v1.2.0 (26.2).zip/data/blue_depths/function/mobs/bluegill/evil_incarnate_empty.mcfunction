# Spawn Evil Incarnate Bluegill
summon drowned ~ ~ ~ {Silent:1b,CustomNameVisible:0b,DeathLootTable:"blue_depths:entities/river/bluegill",PersistenceRequired:1b,CanPickUpLoot:0b,Health:50f,IsBaby:1b,CanBreakDoors:0b,Tags:["bd_bluegigiEvil","bd_scanned","bd_mob","bd_nonBucketableBase","bd_atk_fish"],CustomName:"Blue Gigi (Evil Incarnate)",equipment:{head:{id:"minecraft:flint",count:1,components:{"minecraft:item_model":"bluedepths:mobs/bluegill"}}},active_effects:[{id:"minecraft:invisibility",amplifier:0,duration:-1,show_particles:0b}],attributes:[{id:"minecraft:attack_damage",base:12},{id:"minecraft:max_health",base:50},{id:"minecraft:movement_speed",base:1.4}]}

# Add Evil Blue Gigi to followRangeFlag scoreboard and set it to true (1)
scoreboard players set @n[type=drowned,tag=bd_bluegigiEvil] followRangeFlag 1

#Give player bucket
give @p minecraft:bucket 1

# Evil Message
tellraw @a[distance=..30] {"bold":true,"color":"green","text":"Oopsie Daisy!"}

#Set water
setblock ~ ~ ~ water replace

#Particle effects
particle minecraft:soul ~ ~1.5 ~ 1 1 1 0 100

#Play sound effect
playsound minecraft:item.bucket.empty_fish master @a[distance=..6]
playsound minecraft:entity.ender_dragon.growl master @a[distance=..6]
playsound music_disc.pigstep master @a[distance=..30] ~ ~ ~

#Kill mob
tp @s ~ ~-500 ~
kill @s