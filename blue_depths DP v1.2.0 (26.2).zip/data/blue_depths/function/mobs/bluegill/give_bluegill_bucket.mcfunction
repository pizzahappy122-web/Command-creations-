# Scan player if bucket and determine which hand holds the bucket, and tag the player to remove bucket
execute as @a[distance=..4] if items entity @s weapon.mainhand minecraft:cod_bucket run tag @s add bd_rightHandSwapC
execute as @a[distance=..4,tag=!bd_rightHandSwapC] if items entity @s weapon.offhand minecraft:cod_bucket run tag @s add bd_leftHandSwapC

### Perform swap
# If player has bucket in right hand, swap
execute as @a[tag=bd_rightHandSwapC,distance=..4] run item replace entity @s weapon.mainhand with minecraft:cod_spawn_egg[custom_name={"italic":false,"text":"Bucket of Bluegill"},item_model="bluedepths:items/bluegill_bucket",entity_data={id:"minecraft:cod",Tags:["bd_bluegillBucket","bd_fishReplace"],active_effects:[{id:"minecraft:resistance",amplifier:10,duration:40,show_particles:0b},{id:"minecraft:invisibility",amplifier:0,duration:-1,show_particles:0b}]}] 1
# If player has bucket in left hand, swap
execute as @a[tag=bd_leftHandSwapC,distance=..4] run item replace entity @s weapon.offhand with minecraft:cod_spawn_egg[custom_name={"italic":false,"text":"Bucket of Bluegill"},item_model="bluedepths:items/bluegill_bucket",entity_data={id:"minecraft:cod",Tags:["bd_bluegillBucket","bd_fishReplace"],active_effects:[{id:"minecraft:resistance",amplifier:10,duration:40,show_particles:0b},{id:"minecraft:invisibility",amplifier:0,duration:-1,show_particles:0b}]}] 1

### Remove leftover Tags
tag @a[tag=bd_rightHandSwapC,distance=..5.5] remove bd_rightHandSwapC
tag @a[tag=bd_leftHandSwapC,distance=..5.5] remove bd_leftHandSwapC

tag @s add bd_stopCheck

### Kill self just in case
kill @s
