# Spawn Bluegill
summon cod ~ ~ ~ {DeathLootTable:"blue_depths:entities/river/bluegill",PersistenceRequired:1b,Health:3f,Tags:["bd_scanned","bd_bluegill","bd_bucketableBase","bd_mob","bd_bucketable"],Passengers:[{id:"minecraft:armor_stand",Silent:1b,Invulnerable:1b,Small:1b,Marker:1b,Invisible:1b,Tags:["bd_mob","bd_scanned","bd_bluegill","bd_bucketableBase","bd_bucketable"],equipment:{mainhand:{id:"minecraft:flint",count:1,components:{"minecraft:item_model":"bluedepths:mobs/bluegill"}}}}],active_effects:[{id:"minecraft:invisibility",amplifier:0,duration:-1,show_particles:0b}],attributes:[{id:"minecraft:max_health",base:3}]}

#Give player bucket
give @p minecraft:bucket 1

#Set water
setblock ~ ~ ~ water replace

#Play sound effect
playsound minecraft:item.bucket.empty_fish master @a[distance=..6]

#Kill mob
tp @s ~ ~-500 ~
kill @s