# Spawn mature Great White Shark (passive)
summon salmon ~ ~ ~ {Silent:1b,DeathLootTable:"blue_depths:entities/gw_shark",PersistenceRequired:1b,NoAI:0b,Health:60f,Tags:["bd_gw_shark","bd_scanned","bd_mob","bd_scanned_gw_shark","bd_bucketableBase","bd_neutralMob","bd_shark"],Passengers:[{id:"minecraft:armor_stand",Silent:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["bd_gw_shark","bd_mob","bd_bucketableBase","bd_pet","bd_shark"],equipment:{mainhand:{id:"minecraft:flint",count:1,components:{"minecraft:item_model":"bluedepths:blue_depths/mobs/atk_gw_shark"}}}}],active_effects:[{id:"minecraft:invisibility",amplifier:0,duration:-1,show_particles:0b}],attributes:[{id:"minecraft:max_health",base:60},{id:"minecraft:movement_speed",base:0.5},{id:"minecraft:scale",base:3}]}

# Message
execute unless entity @s[type=armor_stand] run tellraw @a[sort=nearest,limit=1] "Congratulations! Your Great White Shark has matured!"

# Particle effect
execute unless entity @s[type=armor_stand] run particle minecraft:snowflake ~ ~ ~ 0.5 0.5 0.5 0.3 20 force

# Play sound effect
execute unless entity @s[type=armor_stand] run playsound minecraft:entity.player.levelup master @a[distance=..8]

### If self is an armor stand
# Remove the bucket of salmon and replace with water bucket
execute if entity @s[type=minecraft:armor_stand] run function blue_depths:cleanup/bucket_sawp/big_salmon_swap

### Kill Pup
tp @s ~ ~-500 ~
kill @s