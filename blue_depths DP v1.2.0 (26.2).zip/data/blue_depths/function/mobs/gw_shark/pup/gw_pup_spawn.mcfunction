# Spawn baby
summon salmon ~ ~ ~ {Silent:1b,CustomNameVisible:0b,DeathLootTable:"blue_depths:entities/nothing",PersistenceRequired:1b,Health:20f,Tags:["bd_greatWhitePup","bd_mob","bd_atk_gw_shark","bd_mobGrowth","bd_scanned","bd_bucketableBase"],Passengers:[{id:"minecraft:armor_stand",Silent:1b,Invulnerable:1b,Small:1b,Marker:1b,Invisible:1b,Tags:["bd_greatWhitePup","bd_mob","bd_bucketableBase"],equipment:{offhand:{id:"minecraft:flint",count:1,components:{"minecraft:item_model":"bluedepths:blue_depths/mobs/gw_shark"}}}}],active_effects:[{id:"minecraft:invisibility",amplifier:0,duration:-1,show_particles:0b}],attributes:[{id:"minecraft:attack_damage",base:5},{id:"minecraft:follow_range",base:20},{id:"minecraft:max_health",base:20},{id:"minecraft:movement_speed",base:1.3}]}

#Add to growth scoreboard
scoreboard players add @n[tag=bd_greatWhitePup,type=drowned] marineGrowth 0

#Set water
execute unless entity @s[type=minecraft:armor_stand] run setblock ~ ~ ~ water replace

#Sound Effect
execute unless entity @s[type=minecraft:armor_stand] run playsound minecraft:entity.player.splash.high_speed master @a[distance=..10]

### If self is an armor stand
# Remove the bucket of salmon and replace with water bucket
execute if entity @s[type=minecraft:armor_stand] run function blue_depths:cleanup/bucket_sawp/big_salmon_swap


#Kill mob
tp @s ~ ~-500 ~
kill @s