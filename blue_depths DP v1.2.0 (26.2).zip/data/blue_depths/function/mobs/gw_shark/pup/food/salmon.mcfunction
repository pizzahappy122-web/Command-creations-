#Speed up growth by 2
scoreboard players add @s marineGrowth 3

#Eating sound effect
playsound minecraft:entity.generic.eat master @a[distance=..8]

#Kill food
execute as @e[type=item,nbt={Item:{id:"minecraft:salmon",count:1}},sort=nearest,limit=1] at @s run kill @s