#Speed up growth by 2
scoreboard players add @s marineGrowth 7

#Eating sound effect
playsound minecraft:entity.generic.eat master @a[distance=..8] ~ ~ ~ 100 0.6

#Kill food
execute as @e[type=item,nbt={Item:{id:"minecraft:flint",count:1,components:{"minecraft:item_model":"bluedepths:blue_depths/items/tuna_fillet"}}},sort=nearest,limit=1] at @s run kill @s
