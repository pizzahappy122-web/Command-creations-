####### Great White Shark Pup loop #######

## Note: Shark doesn't grow on it's own, you must feed it! ##

## Feed
execute if entity @e[type=item,nbt={Item:{id:"minecraft:flint",count:1,components:{"minecraft:item_model":"bluedepths:blue_depths/items/tuna_fillet"}}},distance=..3] run function blue_depths:mobs/gw_shark/pup/food/tuna
execute if entity @e[type=item,nbt={Item:{id:"minecraft:cod",count:1}},distance=..3] run function blue_depths:mobs/gw_shark/pup/food/cod
execute if entity @e[type=item,nbt={Item:{id:"minecraft:salmon",count:1}},distance=..3] run function blue_depths:mobs/gw_shark/pup/food/salmon

## Once given enough food, shark will grow
execute as @s[scores={marineGrowth=100..}] at @s run function blue_depths:mobs/gw_shark/pup/gw_pup_grow