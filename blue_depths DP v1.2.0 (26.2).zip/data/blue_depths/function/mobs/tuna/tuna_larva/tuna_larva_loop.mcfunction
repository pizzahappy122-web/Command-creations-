#Increase counter
scoreboard players add @s marineGrowth 1

#Feed and speed up growth
execute if entity @e[type=item,nbt={Item:{id:"minecraft:wheat_seeds",count:1}},distance=..3] run function blue_depths:mobs/tuna/tuna_larva/tuna_larva_speedgrowth

# Feed and stunt growth
execute if entity @e[type=item,nbt={Item:{id:"minecraft:beetroot",count:1}},distance=..3] run function blue_depths:mobs/tuna/tuna_larva/tuna_larva_stunt

#Trigger growth once age is reached
execute as @s[scores={marineGrowth=800..}] at @s run function blue_depths:mobs/tuna/tuna_juvenile/tuna_juvenile_spawn