# Spawn the tuna larva
summon tropical_fish ~ ~ ~ {DeathLootTable:"blue_depths:entities/nothing",PersistenceRequired:1b,Tags:["larvaTuna","bd_scanned","bd_mobGrowth"],Variant:184549888}

#Add to growth scoreboard
scoreboard players add @e[tag=larvaTuna,type=tropical_fish,sort=nearest,limit=1] marineGrowth 0

#Playsound
playsound minecraft:entity.tropical_fish.flop master @a[distance=..6]

#Water particles
particle minecraft:falling_water ~ ~ ~ 0.5 0.5 0.5 7 20 normal

#Kill mob
tp @s ~ ~-500 ~
kill @s