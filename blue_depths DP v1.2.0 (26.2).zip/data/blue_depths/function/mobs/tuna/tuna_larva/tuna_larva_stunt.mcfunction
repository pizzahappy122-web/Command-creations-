#Spawn persistent tuna larva
summon tropical_fish ~ ~ ~ {DeathLootTable:"blue_depths:entities/nothing",PersistenceRequired:1b,Tags:["larvaTunaStunted","bd_scanned"],Variant:184549888}

# Message
tellraw @a[sort=nearest,limit=1] "Tuna larva growth stunted"

# Particle effect
particle minecraft:sneeze ~ ~ ~ 0.5 0.5 0.5 0.3 20 force

# Play sound
playsound minecraft:block.beehive.enter master @a[distance=..6]

# Kill beetroot item
execute as @e[type=item,nbt={Item:{id:"minecraft:beetroot",count:1}},sort=nearest,limit=1] at @s run kill @s

#Kill mob
tp @s ~ ~-500 ~
kill @s