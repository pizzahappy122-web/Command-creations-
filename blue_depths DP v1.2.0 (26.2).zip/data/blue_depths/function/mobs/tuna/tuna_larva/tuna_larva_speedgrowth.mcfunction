#Speed up growth by some seconds (80 seconds out of 800 seconds, so 10 seeds to grow)
scoreboard players add @s marineGrowth 80

#Eating sound effect
playsound minecraft:entity.generic.eat master @a[distance=..5]

#Kill seeds
execute as @e[type=item,nbt={Item:{id:"minecraft:wheat_seeds",count:1}},sort=nearest,limit=1] at @s run kill @s