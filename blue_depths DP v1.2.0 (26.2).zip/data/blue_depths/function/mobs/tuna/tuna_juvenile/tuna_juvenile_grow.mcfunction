# Spawn mature tuna
summon salmon ~ ~ ~ {Silent:1b,DeathLootTable:"blue_depths:entities/tuna",PersistenceRequired:1b,Health:12f,Tags:["bd_tuna","bd_scanned","bd_mob","bd_bucketableBase","bd_pet"],Passengers:[{id:"minecraft:armor_stand",Silent:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["bd_tuna","bd_mob","bd_bucketableBase","bd_pet"],equipment:{mainhand:{id:"minecraft:flint",count:1,components:{"minecraft:item_model":"bluedepths:blue_depths/mobs/tuna"}}}}],active_effects:[{id:"minecraft:invisibility",amplifier:0,duration:-1,show_particles:0b,show_icon:0b}],attributes:[{id:"minecraft:max_health",base:12}]}

### If self is an armor stand
# Remove the bucket of salmon and replace with water bucket
execute if entity @s[type=minecraft:armor_stand] run function blue_depths:cleanup/bucket_sawp/big_salmon_swap

# Kill juvenile
tp @s ~ ~-500 ~
kill @s