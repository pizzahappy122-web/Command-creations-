# Spawn stunted tuna
summon cod ~ ~ ~ {DeathLootTable:"blue_depths:entities/tuna_young",PersistenceRequired:1b,Tags:["bd_tuna_young","bd_scanned","bd_mob","bd_bucketableBase"],Passengers:[{id:"minecraft:armor_stand",Silent:1b,Invulnerable:1b,Small:1b,Marker:1b,Invisible:1b,Tags:["bd_tuna_young","bd_mob","bd_bucketableBase"],equipment:{offhand:{id:"minecraft:flint",count:1,components:{"minecraft:item_model":"bluedepths:blue_depths/mobs/tuna"}}}}],active_effects:[{id:"minecraft:invisibility",amplifier:0,duration:-1,show_particles:0b}]}

# Message
execute unless entity @s[type=minecraft:armor_stand] run tellraw @a[sort=nearest,limit=1] "Juvenile tuna growth stunted"

# Particle effect
execute unless entity @s[type=minecraft:armor_stand] run particle minecraft:sneeze ~ ~ ~ 0.5 0.5 0.5 0.3 20 force

# Play sound
execute unless entity @s[type=minecraft:armor_stand] run playsound minecraft:block.beehive.enter master @a[distance=..6]

# Kill beetroot item
execute unless entity @s[type=minecraft:armor_stand] run execute as @e[type=item,nbt={Item:{id:"minecraft:beetroot",count:1}},sort=nearest,limit=1] at @s run kill @s

### If self is an armor stand
# Remove the bucket of salmon and replace with water bucket
execute if entity @s[type=minecraft:armor_stand] run function blue_depths:cleanup/bucket_sawp/big_cod_swap


#Kill mob
tp @s ~ ~-500 ~
kill @s