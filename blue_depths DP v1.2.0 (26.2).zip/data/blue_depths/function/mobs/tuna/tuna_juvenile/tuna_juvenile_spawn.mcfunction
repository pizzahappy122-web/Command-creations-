# Spawn juvenile tuna
summon cod ~ ~ ~ {DeathLootTable:"blue_depths:entities/tuna_young",PersistenceRequired:1b,Tags:["bd_tuna_young","bd_scanned","bd_mob","bd_mobGrowth","bd_bucketableBase"],Passengers:[{id:"minecraft:armor_stand",Silent:1b,Invulnerable:1b,Small:1b,Marker:1b,Invisible:1b,Tags:["bd_tuna_young","bd_mob","bd_bucketableBase","bd_mobGrowth"],equipment:{offhand:{id:"minecraft:flint",count:1,components:{"minecraft:item_model":"bluedepths:blue_depths/mobs/tuna"}}}}],active_effects:[{id:"minecraft:invisibility",amplifier:0,duration:-1,show_particles:0b}]}

#Add to juvenile tuna growth scoreboard
scoreboard players add @e[tag=youngTuna,type=cod,sort=nearest,limit=1] marineGrowth 0

### If self is an armor stand
# Remove the bucket of salmon and replace with water bucket
execute if entity @s[type=minecraft:armor_stand] run function blue_depths:cleanup/bucket_sawp/big_cod_swap


#Kill larva
tp @s ~ ~-500 ~
kill @s