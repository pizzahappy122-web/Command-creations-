#Counter
scoreboard players add @s marineGrowth 1

#Feed and speed up growth
execute if entity @e[type=item,nbt={Item:{id:"minecraft:tropical_fish",count:1}},distance=..3] run function blue_depths:mobs/tuna/tuna_juvenile/tuna_juvenile_speedgrowth

# Feed and stunt growth
execute if entity @e[type=item,nbt={Item:{id:"minecraft:beetroot",count:1}},distance=..3] run function blue_depths:mobs/tuna/tuna_juvenile/tuna_juvenile_stunt

#Trigger growth once age is reached
execute as @s[scores={marineGrowth=800..}] at @s run function blue_depths:mobs/tuna/tuna_juvenile/tuna_juvenile_grow