#Speed up growth by some seconds
scoreboard players add @s marineGrowth 80

#Eating sound effect
playsound minecraft:entity.generic.eat master @a[distance=..5]

#Kill seeds
execute as @e[type=item,nbt={Item:{id:"minecraft:tropical_fish",count:1}},sort=nearest,limit=1] at @s run kill @s