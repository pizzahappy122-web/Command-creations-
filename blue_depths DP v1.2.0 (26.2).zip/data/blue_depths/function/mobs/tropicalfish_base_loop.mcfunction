# Tuna Larva loop
execute as @s[tag=larvaTuna] at @s run function blue_depths:mobs/tuna/tuna_larva/tuna_larva_loop