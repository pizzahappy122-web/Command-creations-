######## Box Jellyfish #######

### White Box Jelly Polyp ###
# Trigger switch and spawn polyp
execute as @s[tag=white_box_jelly_polyp,tag=!triggered] at @s run function blue_depths:mobs/box_jelly/white_polyp/spawn

# White box jelly polyp loop
execute as @s[tag=white_box_jelly_polyp,tag=triggered] at @s run function blue_depths:mobs/box_jelly/white_polyp/white_loop

### Blue Box Jelly ###
# Trigger switch and spawn polyp
execute as @s[tag=blue_box_jelly_polyp,tag=!triggered] at @s run function blue_depths:mobs/box_jelly/blue_polyp/spawn

# Blue box jelly polyp loop
execute as @s[tag=blue_box_jelly_polyp,tag=triggered] at @s run function blue_depths:mobs/box_jelly/blue_polyp/blue_polyp_loop

### Brown Box Jelly ###
# Trigger switch and spawn polyp
execute as @s[tag=brown_box_jelly_polyp,tag=!triggered] at @s run function blue_depths:mobs/box_jelly/brown_polyp/spawn

# Brown box jelly polyp loop
execute as @s[tag=brown_box_jelly_polyp,tag=triggered] at @s run function blue_depths:mobs/box_jelly/brown_polyp/brown_polyp_loop

### Ghost Box Jelly ###
# Trigger switch and spawn polyp
execute as @s[tag=ghost_box_jelly_polyp,tag=!triggered] at @s run function blue_depths:mobs/box_jelly/ghost_polyp/spawn

# Ghost box jelly polyp loop
execute as @s[tag=ghost_box_jelly_polyp,tag=triggered] at @s run function blue_depths:mobs/box_jelly/ghost_polyp/ghost_polyp_loop

### Yellow Box Jelly ###
# Trigger switch and spawn polyp
execute as @s[tag=yellow_box_jelly_polyp,tag=!triggered] at @s run function blue_depths:mobs/box_jelly/yellow_polyp/spawn

# Yellow box jelly polyp loop
execute as @s[tag=yellow_box_jelly_polyp,tag=triggered] at @s run function blue_depths:mobs/box_jelly/yellow_polyp/yellow_polyp_loop

### Pink Box Jelly ###
# Trigger switch and spawn polyp
execute as @s[tag=pink_box_jelly_polyp,tag=!triggered] at @s run function blue_depths:mobs/box_jelly/pink_polyp/spawn

# Pink box jelly polyp loop
execute as @s[tag=pink_box_jelly_polyp,tag=triggered] at @s run function blue_depths:mobs/box_jelly/pink_polyp/pink_polyp_loop