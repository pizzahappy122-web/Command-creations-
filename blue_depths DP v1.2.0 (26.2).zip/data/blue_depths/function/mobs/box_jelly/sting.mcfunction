effect give @a[sort=nearest,limit=1,gamemode=!creative,gamemode=!spectator] slowness 3 2
effect give @a[sort=nearest,limit=1,gamemode=!creative,gamemode=!spectator] weakness 6 1
effect give @a[sort=nearest,limit=1,gamemode=!creative,gamemode=!spectator] mining_fatigue 6
damage @a[sort=nearest,limit=1,gamemode=!creative,gamemode=!spectator] 3 minecraft:sting