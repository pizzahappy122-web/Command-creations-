# Replace
summon cod ~ ~ ~ {Silent:1b,DeathLootTable:"blue_depths:entities/nothing",PersistenceRequired:1b,NoAI:1b,Tags:["bd_mob","bd_stunted","brown_box_polyp_stunted","box_jelly_stunted","bd_bucketableBase"],Passengers:[{id:"minecraft:armor_stand",Silent:1b,Small:1b,Invisible:1b,Tags:["bd_mob","brown_box_polyp_stunted","bd_bucketableBase"],equipment:{mainhand:{id:"minecraft:flint",count:1,components:{"minecraft:item_model":"bluedepths:blue_depths/mobs/box_jellies/polyps/brown_box_jelly_polyp"}}}}],active_effects:[{id:"minecraft:invisibility",amplifier:0,duration:-1,show_particles:0b}]}

# Message
tellraw @a[sort=nearest,limit=1] " Brown Box Jelly Polyp growth stunted"

# Particle effect
particle minecraft:sneeze ~ ~ ~ 0.5 0.5 0.5 0.3 20 force

# Play sound
playsound minecraft:block.beehive.enter master @a[distance=..6]

# Kill coal item
execute as @e[type=item,nbt={Item:{id:"minecraft:coal",count:1}},sort=nearest,limit=1] at @s run kill @s

#Kill mob
kill @s