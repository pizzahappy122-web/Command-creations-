#Increase counter
scoreboard players add @s marineGrowth 1

#Kill if not in water
execute unless block ~ ~ ~ water run kill @s

# Feed and stunt growth
execute if entity @e[type=item,nbt={Item:{id:"minecraft:coal",count:1}},distance=..3] run function blue_depths:mobs/box_jelly/brown_polyp/brown_polyp_stunt

#Trigger growth once age is reached
execute as @s[scores={marineGrowth=400..}] at @s run function blue_depths:mobs/box_jelly/brown_young/brown_spawn