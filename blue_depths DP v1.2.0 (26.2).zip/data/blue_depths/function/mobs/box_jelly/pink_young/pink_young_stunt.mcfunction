# Stunt growth
summon cod ~ ~ ~ {Silent:1b,DeathLootTable:"blue_depths:entities/nothing",PersistenceRequired:1b,Health:5f,Tags:["bd_scanned","bd_mob","bd_pinkBoxJellyYoung","bd_boxJelly","bd_bucketableBase"],Passengers:[{id:"minecraft:armor_stand",Silent:1b,Invulnerable:1b,Small:1b,Marker:1b,Invisible:1b,Tags:["bd_scanned","bd_mob","bd_pinkBoxJellyYoung","bd_boxJelly","bd_bucketableBase"],equipment:{mainhand:{id:"minecraft:flint",count:1,components:{"minecraft:item_model":"bluedepths:blue_depths/mobs/box_jellies/pink_box_jellyfish"}}}}],active_effects:[{id:"minecraft:invisibility",amplifier:0,duration:-1,show_particles:0b}],attributes:[{id:"minecraft:max_health",base:5},{id:"minecraft:movement_speed",base:0.4},{id:"minecraft:scale",base:1.5}]}

# Message
execute unless entity @s[type=minecraft:armor_stand] run tellraw @a[sort=nearest,limit=1] "Pink Juvenile Box Jelly growth stunted"

# Particle effect
execute unless entity @s[type=minecraft:armor_stand] run particle minecraft:sneeze ~ ~ ~ 0.5 0.5 0.5 0.3 20 force

# Play sound
execute unless entity @s[type=minecraft:armor_stand] run playsound minecraft:block.beehive.enter master @a[distance=..6]

# Kill beetroot item
execute unless entity @s[type=minecraft:armor_stand] run execute as @e[type=item,nbt={Item:{id:"minecraft:beetroot",count:1}},sort=nearest,limit=1] at @s run kill @s

### If self is an armor stand
# Remove the bucket of salmon and replace with water bucket
execute if entity @s[type=minecraft:armor_stand] run function blue_depths:cleanup/bucket_sawp/big_cod_swap

#Kill mob
tp @s ~ ~-500 ~
kill @s