#Counter
scoreboard players add @s marineGrowth 1

# Feed and stunt growth
execute if entity @e[type=item,nbt={Item:{id:"minecraft:beetroot",count:1}},distance=..3] run function blue_depths:mobs/box_jelly/pink_young/pink_young_stunt

#Trigger growth once age is reached
execute as @s[scores={marineGrowth=800..}] at @s run function blue_depths:mobs/box_jelly/pink_young/pink_young_grow