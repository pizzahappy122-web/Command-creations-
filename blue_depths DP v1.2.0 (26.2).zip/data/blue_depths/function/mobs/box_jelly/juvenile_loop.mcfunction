# Juvenile white box jelly
execute as @s[tag=bd_whiteBoxJellyYoung] at @s run function blue_depths:mobs/box_jelly/white_young/white_young_loop

# Juvenile blue box jelly
execute as @s[tag=bd_blueBoxJellyYoung] at @s run function blue_depths:mobs/box_jelly/blue_young/blue_young_loop

# Juvenile brown box jelly
execute as @s[tag=bd_brownBoxJellyYoung] at @s run function blue_depths:mobs/box_jelly/brown_young/brown_young_loop

# Juvenile ghost box jelly
execute as @s[tag=bd_ghostBoxJellyYoung] at @s run function blue_depths:mobs/box_jelly/ghost_young/ghost_young_loop

# Juvenile yellow box jelly
execute as @s[tag=bd_yellowBoxJellyYoung] at @s run function blue_depths:mobs/box_jelly/yellow_young/yellow_young_loop

# Juvenile pink box jelly
execute as @s[tag=bd_pinkBoxJellyYoung] at @s run function blue_depths:mobs/box_jelly/pink_young/pink_young_loop