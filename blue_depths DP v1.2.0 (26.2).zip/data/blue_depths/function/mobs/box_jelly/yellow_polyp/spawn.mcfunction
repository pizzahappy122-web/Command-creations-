## summon polyp
summon armor_stand ~ ~ ~ {Silent:1b,Small:1b,Invisible:1b,Tags:["box_jelly_polyp","yellow_box_jelly_polyp","triggered","bd_mobGrowth"],equipment:{mainhand:{id:"minecraft:flint",count:1,components:{"minecraft:item_model":"bluedepths:blue_depths/mobs/box_jellies/polyps/yellow_box_jelly_polyp"}}}}

# Add to polyp to growth scoreboard
scoreboard players add @e[tag=yellow_box_jelly_polyp,tag=triggered,type=armor_stand,sort=nearest,limit=1] marineGrowth 0

#Playsound
playsound minecraft:entity.chicken.egg master @a[distance=..6]

# Kill old armor stand
kill @s