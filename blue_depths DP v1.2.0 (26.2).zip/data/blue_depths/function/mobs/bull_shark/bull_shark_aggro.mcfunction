### Bull Shark Aggro Spawn
summon drowned ~ ~ ~ {Silent:1b,CustomNameVisible:0b,DeathLootTable:"blue_depths:entities/river/bull_shark",PersistenceRequired:0b,CanPickUpLoot:0b,Health:32f,IsBaby:1b,CanBreakDoors:0b,Tags:["bd_bullShark","bd_scanned","bd_mob","bd_nonBucketableBase","bd_shark","bd_atk_fish","bd_aggroBullShark"],Passengers:[{id:"minecraft:armor_stand",Silent:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["bd_bullShark","bd_scanned","bd_mob","bd_nonBucketableBase","bd_shark","bd_aggroBullShark"],equipment:{offhand:{id:"minecraft:flint",count:1,components:{"minecraft:item_model":"bluedepths:mobs/bull_shark"}}}}],CustomName:"Bull Shark",active_effects:[{id:"minecraft:invisibility",amplifier:0,duration:-1,show_particles:0b}],attributes:[{id:"minecraft:attack_damage",base:7},{id:"minecraft:follow_range",base:25},{id:"minecraft:max_health",base:32},{id:"minecraft:movement_speed",base:1.4}]}

# Play aggro sound
playsound minecraft:entity.ravager.attack master @a[distance=..6] ~ ~ ~

# Add shark to followRangeFlag scoreboard and set it to true (1)
scoreboard players set @n[type=drowned,tag=bd_aggroBullShark] followRangeFlag 1

#Remove the neutral Bull Shark
tp @s ~ ~-500 ~
kill @s