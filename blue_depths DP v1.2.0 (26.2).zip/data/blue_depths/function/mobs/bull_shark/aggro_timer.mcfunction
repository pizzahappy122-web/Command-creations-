####### Stats
# Total time till become aggro: 30s
# Radius for aggro increment: 10
# Waring: 22s

### Tag as aggro passed so warning doesn't appear again if the player gets out of the radius of anger zone
execute if score @s bd_atkCool matches 12 run tag @s add bd_aggroPassed

### Update Timer score
# If player is close by in water, increment timer
execute if entity @a[distance=..10,predicate=blue_depths:is_in_water,gamemode=!creative,gamemode=!spectator] run scoreboard players add @s bd_atkCool 1
# If no eligibile player is close by, prevent timer from going below 0
execute unless entity @a[distance=..10,gamemode=!creative,gamemode=!spectator] if score @s bd_atkCool matches 1.. run scoreboard players remove @s bd_atkCool 1

### Give warning at 22s (score = 11)
execute unless entity @s[tag=bd_aggroPassed] if score @s bd_atkCool matches 11 run particle bubble ^ ^0.5 ^0.5 0.4 0.4 0.4 0.3 50 force
execute unless entity @s[tag=bd_aggroPassed] if score @s bd_atkCool matches 11 run playsound minecraft:entity.squid.squirt master @a[distance=..15] ~ ~ ~

### Become aggressive at 30s (score = 15)
execute if score @s bd_atkCool matches 15 run particle minecraft:angry_villager ^ ^0.5 ^0.5 0.4 0.4 0.4 0 10 force
execute if score @s bd_atkCool matches 15 run playsound minecraft:entity.ravager.attack master @a[distance=..15] ~ ~ ~
execute if score @s bd_atkCool matches 15 run function blue_depths:mobs/bull_shark/bull_shark_aggro
execute if score @s bd_atkCool matches 15 run scoreboard players reset @s bd_atkCool

### Remove the aggroPassed tag
execute if entity @s[tag=bd_aggroPassed] run tag @s remove bd_aggroPassed