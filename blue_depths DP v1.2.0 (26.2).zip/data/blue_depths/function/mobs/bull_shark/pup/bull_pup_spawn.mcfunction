### Spawn Bull Shark Pup
summon drowned ~ ~ ~ {Silent:1b,CustomNameVisible:0b,DeathLootTable:"blue_depths:entities/nothing",PersistenceRequired:1b,Health:8f,IsBaby:1b,CanBreakDoors:0b,Tags:["bd_bullSharkPup","bd_mob","bd_mobGrowth","bd_atk_fish","bd_nonBucketableBase"],Passengers:[{id:"minecraft:armor_stand",Silent:1b,Invulnerable:1b,Small:1b,Marker:1b,Invisible:1b,Tags:["bd_bullSharkPup","bd_mob","bd_nonBucketableBase"],equipment:{head:{id:"minecraft:flint",count:1,components:{"minecraft:item_model":"bluedepths:mobs/bull_shark"}}}}],CustomName:"Bull Shark Pup",active_effects:[{id:"minecraft:invisibility",amplifier:0,duration:-1,show_particles:0b}],attributes:[{id:"minecraft:attack_damage",base:3},{id:"minecraft:follow_range",base:15},{id:"minecraft:max_health",base:8},{id:"minecraft:movement_speed",base:1.3},{id:"minecraft:scale",base:0.6}]}

#Add to growth scoreboard
scoreboard players add @n[tag=bd_bullSharkPup,type=drowned] marineGrowth 0

# Add shark to followRangeFlag scoreboard and set it to true (1)
scoreboard players set @n[type=drowned,tag=bd_bullSharkPup] followRangeFlag 1

#Set water
setblock ~ ~ ~ water replace

#Play sound effect
playsound minecraft:item.bucket.empty_fish master @a[distance=..6]

#Kill mob
tp @s ~ ~-500 ~
kill @s