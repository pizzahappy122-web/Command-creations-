####### Bull Shark Pup loop #######

## Note: Shark doesn't grow on it's own, you must feed it! ##

## Feed
execute if entity @e[type=item,nbt={Item:{id:"minecraft:flint",count:1,components:{"minecraft:item_model":"bluedepths:items/raw_lm_bass"}}},distance=..3] run function blue_depths:mobs/bull_shark/pup/food/bass
execute if entity @e[type=item,nbt={Item:{id:"minecraft:tropical_fish",count:1}},distance=..3] run function blue_depths:mobs/bull_shark/pup/food/tropical_fish
execute if entity @e[type=item,nbt={Item:{id:"minecraft:salmon",count:1}},distance=..3] run function blue_depths:mobs/bull_shark/pup/food/salmon

## Once given enough food, shark will grow
execute as @s[scores={marineGrowth=50..}] at @s run function blue_depths:mobs/bull_shark/pup/bull_pup_grow