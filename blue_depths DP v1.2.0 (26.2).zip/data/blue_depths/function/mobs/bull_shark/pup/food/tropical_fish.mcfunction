#Speed up growth by 2
scoreboard players add @s marineGrowth 3

#Eating sound effect
playsound minecraft:entity.generic.eat master @a[distance=..5]

#Kill food
execute as @n[type=item,nbt={Item:{id:"minecraft:tropical_fish",count:1}}] at @s run kill @s
