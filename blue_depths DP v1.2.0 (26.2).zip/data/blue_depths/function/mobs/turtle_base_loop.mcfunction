# Crocodile Hatchling
execute at @s if entity @s[tag=bd_crocHatchling] run function blue_depths:mobs/crocodile/croc_juvenile/croc_juvenile_loop