###### Animating the crocodile
#### ANIMATION KEY: 
####      0 = idle
####      1 = walking
####      2 = swimming

### Get motion
execute store result score @s bd_mobMotionX run data get entity @s Motion[0] 100
execute store result score @s bd_mobMotionZ run data get entity @s Motion[2] 100

### Update Movement Flag
# Set initial (0 is false, 1 is true)
scoreboard players set @s bd_isMoving 0

execute unless score @s bd_mobMotionX matches 0 run scoreboard players set @s bd_isMoving 1
execute unless score @s bd_mobMotionZ matches 0 run scoreboard players set @s bd_isMoving 1

### Update state
# Update to idle
execute unless score @s bd_animate matches 0 if score @s bd_isMoving matches 0 run function blue_depths:mobs/crocodile/animate/idle
# Update to walking (must not be in water)
execute if score @s bd_isMoving matches 1 unless entity @s[predicate=blue_depths:is_in_water] unless score @s bd_animate matches 1 run function blue_depths:mobs/crocodile/animate/walk
# Update to swimming if in water
execute if score @s bd_isMoving matches 1 if entity @s[predicate=blue_depths:is_in_water] unless score @s bd_animate matches 2 run function blue_depths:mobs/crocodile/animate/swim


### If motionless transform to idle stance
#execute if entity @s[nbt={Motion:[0.0d,0.0d,0.0d]}] run item replace entity @n[type=armor_stand,tag=bd_crocodile,distance=..1.3] weapon.mainhand with minecraft:flint[minecraft:item_model="bluedepths:mobs/croc/idle"]

### If in motion, change to either swimmming or walking animation
# If crocodile is in water, change to swimming animation
#execute unless entity @s[nbt={Motion:[0.0d,0.0d,0.0d]}] if entity @s[predicate=blue_depths:is_in_water] run item replace entity @n[type=armor_stand,tag=bd_crocodile,distance=..1.3] weapon.mainhand with minecraft:flint[minecraft:item_model="bluedepths:mobs/croc/swimming"]
# If crocodile on land, change to walking animation
#execute unless entity @s[nbt={Motion:[0.0d,0.0d,0.0d]}] if entity @s[predicate=!blue_depths:is_in_water] run item replace entity @n[type=armor_stand,tag=bd_crocodile,distance=..1.3] weapon.mainhand with minecraft:flint[minecraft:item_model="bluedepths:mobs/croc/walking"]
