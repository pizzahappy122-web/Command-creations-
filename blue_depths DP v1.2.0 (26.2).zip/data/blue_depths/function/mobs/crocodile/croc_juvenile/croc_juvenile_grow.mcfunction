### Spawn pet crocodile
summon drowned ~ ~ ~ {Silent:1b,CustomNameVisible:0b,DeathLootTable:"blue_depths:entities/river/crocodile",PersistenceRequired:1b,Health:20f,IsBaby:1b,Tags:["bd_mob","bd_crocodile","bd_scanned","bd_nonBucketableBase","bd_semiAquatic","bd_cooldown","bd_neutralMob","bd_pet"],Passengers:[{id:"minecraft:armor_stand",Silent:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["bd_mob","bd_crocodile","bd_scanned","bd_nonBucketableBase","bd_semiAquatic"],equipment:{mainhand:{id:"minecraft:flint",count:1,components:{item_model:"bluedepths:mobs/croc/idle"}}}}],CustomName:"Crocodile",active_effects:[{id:"minecraft:invisibility",amplifier:0,duration:-1,show_particles:0b}],attributes:[{id:"minecraft:attack_damage",base:9},{id:"minecraft:burning_time",base:0},{id:"minecraft:follow_range",base:0},{id:"minecraft:max_health",base:20}]}

# Attack cooldown
scoreboard players set @n[type=drowned,tag=bd_crocodile,tag=bd_pet,distance=..1] bd_atkCool 0


#Animation stuff
scoreboard players set @n[type=drowned,tag=bd_crocodile,distance=..1] bd_animate 0
scoreboard players set @n[type=drowned,tag=bd_crocodile,distance=..1] bd_mobMotionX 0
scoreboard players set @n[type=drowned,tag=bd_crocodile,distance=..1] bd_mobMotionZ 0

#Kill Mob
tp @s ~ ~-500 ~
kill @s