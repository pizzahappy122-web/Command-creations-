###### Animating the crocodile
#### ANIMATION KEY: 
####      0 = idle
####      1 = walking
####      2 = swimming

### Get motion
execute store result score @s bd_mobMotionX run data get entity @s Motion[0] 100
execute store result score @s bd_mobMotionZ run data get entity @s Motion[2] 100

### Update Movement Flag
# Set initial (0 is false, 1 is true)
scoreboard players set @s bd_isMoving 0

execute unless score @s bd_mobMotionX matches 0 run scoreboard players set @s bd_isMoving 1
execute unless score @s bd_mobMotionZ matches 0 run scoreboard players set @s bd_isMoving 1

### Update state
# Update to idle
execute unless score @s bd_animate matches 0 if score @s bd_isMoving matches 0 run function blue_depths:mobs/crocodile/croc_juvenile/animate/idle
# Update to walking (must not be in water)
execute if score @s bd_isMoving matches 1 unless entity @s[predicate=blue_depths:is_in_water] unless score @s bd_animate matches 1 run function blue_depths:mobs/crocodile/croc_juvenile/animate/walking
# Update to swimming if in water
execute if score @s bd_isMoving matches 1 if entity @s[predicate=blue_depths:is_in_water] unless score @s bd_animate matches 2 run function blue_depths:mobs/crocodile/croc_juvenile/animate/swimming
