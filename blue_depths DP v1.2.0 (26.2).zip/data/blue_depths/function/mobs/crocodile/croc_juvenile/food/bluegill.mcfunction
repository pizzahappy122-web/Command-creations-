#Speed up growth by 2
scoreboard players add @s marineGrowth 65

#Eating sound effect
playsound minecraft:entity.generic.eat master @a[distance=..5]

#Kill food
execute as @n[type=item,nbt={Item:{id:"minecraft:flint",count:1,components:{"minecraft:item_model":"bluedepths:items/raw_bluegill"}}}] at @s run kill @s
