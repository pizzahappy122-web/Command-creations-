# Change animation model
item replace entity @n[type=armor_stand,tag=bd_crocHatchling,distance=..1.3] weapon.offhand with minecraft:flint[minecraft:item_model="bluedepths:mobs/croc/idle"]

# Change score
scoreboard players set @s bd_animate 0