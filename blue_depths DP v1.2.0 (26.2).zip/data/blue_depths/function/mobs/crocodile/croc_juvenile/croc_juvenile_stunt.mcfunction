### Spawn Crocodile Hatchling
summon turtle ~ ~ ~ {Silent:1b,DeathLootTable:"blue_depths:entities/nothing",PersistenceRequired:1b,Health:7f,InLove:0,has_egg:0b,Tags:["bd_mob","bd_nonBucketableBase","bd_semiAquatic","bd_scanned","bd_crocHatchling"],Passengers:[{id:"minecraft:armor_stand",Invulnerable:1b,Small:1b,Marker:1b,Invisible:1b,Tags:["bd_mob","bd_nonBucketableBase","bd_semiAquatic","bd_crocHatchling"],equipment:{offhand:{id:"minecraft:flint",count:1,components:{"minecraft:item_model":"bluedepths:mobs/croc/idle"}}}}],active_effects:[{id:"minecraft:invisibility",amplifier:0,duration:-1,show_particles:0b}],attributes:[{id:"minecraft:max_health",base:7},{id:"minecraft:movement_speed",base:1.2},{id:"minecraft:scale",base:0.7}]}

# Notify of stunting
tellraw @p "Crocodile Hatchling growth stunted"

### FX
particle minecraft:sneeze ~ ~ ~ 0.5 0.5 0.5 0.3 20 force
playsound minecraft:block.beehive.enter master @a[distance=..6]

## Kill beetroot item
execute as @n[type=item,nbt={Item:{id:"minecraft:beetroot",count:1}}] at @s run kill @s

# Kill mob
tp @s ~ ~-500 ~
kill @s