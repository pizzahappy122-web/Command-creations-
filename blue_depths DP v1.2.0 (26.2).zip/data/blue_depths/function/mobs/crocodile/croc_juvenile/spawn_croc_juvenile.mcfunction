### Spawn Crocodile Hatchling
summon turtle ~ ~ ~ {Silent:1b,DeathLootTable:"blue_depths:entities/nothing",PersistenceRequired:1b,Health:7f,InLove:0,has_egg:0b,Tags:["bd_mob","bd_nonBucketableBase","bd_semiAquatic","bd_scanned","bd_crocHatchling","bd_mobGrowth"],Passengers:[{id:"minecraft:armor_stand",Invulnerable:1b,Small:1b,Marker:1b,Invisible:1b,Tags:["bd_mob","bd_nonBucketableBase","bd_semiAquatic","bd_crocHatchling"],equipment:{offhand:{id:"minecraft:flint",count:1,components:{"minecraft:item_model":"bluedepths:mobs/croc/idle"}}}}],active_effects:[{id:"minecraft:invisibility",amplifier:0,duration:-1,show_particles:0b}],attributes:[{id:"minecraft:max_health",base:7},{id:"minecraft:movement_speed",base:1.2},{id:"minecraft:scale",base:0.7}]}

#Add to juvenile growth scoreboard
scoreboard players add @n[tag=bd_crocHatchling,type=minecraft:turtle,distance=..1] marineGrowth 0

#Animation stuff
scoreboard players set @n[type=minecraft:turtle,tag=bd_crocHatchling,distance=..1] bd_animate 0
scoreboard players set @n[type=minecraft:turtle,tag=bd_crocHatchling,distance=..1] bd_mobMotionX 0
scoreboard players set @n[type=minecraft:turtle,tag=bd_crocHatchling,distance=..1] bd_mobMotionZ 0

#Kill larva
tp @s ~ ~-500 ~
kill @s