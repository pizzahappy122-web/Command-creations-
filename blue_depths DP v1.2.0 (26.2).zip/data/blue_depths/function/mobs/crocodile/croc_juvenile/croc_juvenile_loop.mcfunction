#Counter
scoreboard players add @s marineGrowth 1

# Feed and speed up growth (Largemouth Bass)
execute if entity @e[type=item,nbt={Item:{id:"minecraft:flint",count:1,components:{"minecraft:item_model":"bluedepths:items/raw_lm_bass"}}},distance=..3] run function blue_depths:mobs/crocodile/croc_juvenile/food/lm_bass

# Feed and speed up growth (Largemouth Bass)
execute if entity @e[type=item,nbt={Item:{id:"minecraft:flint",count:1,components:{"minecraft:item_model":"bluedepths:items/raw_bluegill"}}},distance=..3] run function blue_depths:mobs/crocodile/croc_juvenile/food/bluegill

# Feed and speed up growth (Salmon)
execute if entity @e[type=item,nbt={Item:{id:"minecraft:salmon",count:1}},distance=..3] run function blue_depths:mobs/crocodile/croc_juvenile/food/salmon

# Feed and stunt growth
execute if entity @e[type=item,nbt={Item:{id:"minecraft:beetroot",count:1}},distance=..3] run function blue_depths:mobs/crocodile/croc_juvenile/croc_juvenile_stunt

#Trigger growth once age is reached
execute as @s[scores={marineGrowth=1000..}] at @s run function blue_depths:mobs/crocodile/croc_juvenile/croc_juvenile_grow