### Damage player
execute as @a[distance=..1.2,gamemode=!spectator,gamemode=!creative] run damage @s 18 mob_attack

# Turn AI On
data modify entity @s NoAI set value 0b

#### Reset scoreboards
scoreboard players set @s bd_atkCool 0
scoreboard players reset @s bd_raycast
scoreboard players set @s bd_animate 0

### Update model
# If on land
execute unless block ~ ~ ~ water run item replace entity @n[type=armor_stand,tag=bd_crocodile,distance=..1.3] weapon.mainhand with minecraft:flint[minecraft:item_model="bluedepths:mobs/croc/idle"]
# If in water
execute if block ~ ~ ~ water run item replace entity @n[type=armor_stand,tag=bd_crocodile,distance=..1.3] weapon.mainhand with minecraft:flint[minecraft:item_model="bluedepths:mobs/croc/swimming"]


### Remove tags and end process
tag @s remove bd_crocLunge
tag @s remove bd_projectile