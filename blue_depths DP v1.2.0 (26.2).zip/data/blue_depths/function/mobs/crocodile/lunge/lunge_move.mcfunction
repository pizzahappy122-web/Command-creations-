# Move forward according to step size
# If crocodile is in water, move faster
execute if block ~ ~ ~ water run tp @s ^ ^ ^0.5
# If crocodile is on land or in the air move slower
execute unless block ~ ~ ~ water run tp @s ^ ^ ^0.35

## particle trail
# If in water, give a bubble trail
execute if block ~ ~ ~ water run particle minecraft:bubble ^0 ^0 ^0 0.1 0.15 0.1 0 20 force
# Small gust for extra power
particle minecraft:small_gust ^0 ^0 ^0 0.2 0.2 0.2 0 30 force

### Case: If colliding with a player
execute as @s at @s if entity @a[gamemode=!spectator,gamemode=!creative,distance=..1.2] run function blue_depths:mobs/crocodile/lunge/lunge_hit

### Base case: If lunge reaches end of lifetime, trigger hit
execute as @s[scores={bd_raycast=..0}] at @s run function blue_depths:mobs/crocodile/lunge/lunge_hit

### Base case: If collides with a solid block, trigger hit
execute unless block ^ ^ ^1 #blue_depths:ray_permeable run function blue_depths:mobs/crocodile/lunge/lunge_hit

## Decrease number of steps left
scoreboard players remove @s bd_raycast 1
