#### Tag self as a "projectile"
tag @s add bd_crocLunge
tag @s add bd_projectile


### Make crocodile face the player to lunge at
# If crocodile has a target
execute on target if entity @s[type=player,gamemode=!spectator,gamemode=!creative,distance=..8] run tp @n[type=drowned,tag=bd_crocLunge] ~ ~ ~ facing entity @s feet
# If crocodile has no target (if during the day on land case)
execute unless predicate blue_depths:has_target run tp @s ~ ~ ~ facing entity @p[distance=..8,gamemode=!creative,gamemode=!spectator] feet

# Turn AI Off
data modify entity @s NoAI set value 1b

### Change model to lunge model
item replace entity @n[type=armor_stand,tag=bd_crocodile,distance=..1.3] weapon.mainhand with minecraft:flint[minecraft:item_model="bluedepths:mobs/croc/lunge"]

### Play sound effect
playsound bluedepths:croc_roar master @a[distance=..10] ~ ~ ~ 0.5

### Initialize steps of the "raycast"
scoreboard players set @s bd_raycast 20