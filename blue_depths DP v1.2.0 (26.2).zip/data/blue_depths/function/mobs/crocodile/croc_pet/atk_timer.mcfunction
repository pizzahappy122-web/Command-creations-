####### Stats
# Total time till become aggro: 6 seconds
# Radius for aggro increment: 2

### Increment timer
execute if entity @a[distance=..2,gamemode=!creative,gamemode=!spectator] run scoreboard players add @s bd_atkCool 1

### Decrement timer
execute unless entity @a[distance=..2,gamemode=!creative,gamemode=!spectator] unless score @s bd_atkCool matches ..0 run scoreboard players remove @s bd_atkCool 1

### If timer reaches certain point roll for chance of croc to become aggressive

##Agression
execute at @s if score @s bd_atkCool matches 3.. if predicate blue_depths:35_percent_chance run function blue_depths:mobs/crocodile/croc_pet/croc_aggro

# Not aggressive reset counter
execute if score @s bd_atkCool matches 3.. unless predicate blue_depths:35_percent_chance run scoreboard players set @s bd_atkCool 0