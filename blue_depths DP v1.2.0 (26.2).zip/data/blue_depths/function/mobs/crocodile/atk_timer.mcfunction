####### Lunge timer

### increment timer
scoreboard players add @s bd_atkCool 1

### Start lunge attack if predicate chance triggers
execute if score @s bd_atkCool matches 4 if entity @a[distance=..8,gamemode=!creative,gamemode=!spectator] run function blue_depths:mobs/crocodile/lunge/lunge_start

### If no eligible player, reset the attack timer
execute if score @s bd_atkCool matches 4 unless entity @a[distance=..8,gamemode=!creative,gamemode=!spectator] run scoreboard players set @s bd_atkCool 0

### If no eligible player and atk timer goes over, reset
execute if score @s bd_atkCool matches 5.. run scoreboard players set @s bd_atkCool 0