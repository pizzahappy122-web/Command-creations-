### Spawn Egg
summon drowned ~ ~ ~ {Silent:1b,DeathLootTable:"blue_depths:entities/nothing",PersistenceRequired:1b,NoAI:1b,Health:0.9f,IsBaby:1b,Tags:["bd_scanned","bd_mobGrowth","bd_crocEgg","bd_mob"],CustomName:"Crocodile Egg",equipment:{head:{id:"minecraft:flint",count:1,components:{"minecraft:item_model":"bluedepths:mobs/crocodile_egg"}}},drop_chances:{head:0.000},active_effects:[{id:"minecraft:invisibility",amplifier:0,duration:-1,show_particles:0b}],attributes:[{id:"minecraft:burning_time",base:0},{id:"minecraft:max_health",base:0.9}]}

# Add Egg to growth scoreboard
scoreboard players add @n[type=minecraft:drowned,tag=bd_crocEgg] marineGrowth 0

#Playsound
playsound minecraft:entity.chicken.egg master @a[distance=..6]

# Kill tropical fish
kill @s