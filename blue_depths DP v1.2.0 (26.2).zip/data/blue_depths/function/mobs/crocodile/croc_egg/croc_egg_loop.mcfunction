#Increase counter
scoreboard players add @s marineGrowth 1

# Feed and stunt growth
execute if entity @e[type=item,nbt={Item:{id:"minecraft:coal",count:1}},distance=..3] run function blue_depths:mobs/crocodile/croc_egg/croc_egg_stunt

#Trigger growth once age is reached
execute as @s[scores={marineGrowth=800..}] at @s run function blue_depths:mobs/crocodile/croc_juvenile/spawn_croc_juvenile
