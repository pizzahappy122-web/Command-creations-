### Spawn Egg
summon drowned ~ ~ ~ {Silent:1b,DeathLootTable:"blue_depths:entities/nothing",PersistenceRequired:1b,NoAI:1b,Health:0.9f,IsBaby:1b,Tags:["bd_scanned","bd_crocEgg","bd_stunted","bd_mob"],CustomName:"Crocodile Egg",equipment:{head:{id:"minecraft:flint",count:1,components:{"minecraft:item_model":"bluedepths:mobs/crocodile_egg"}}},drop_chances:{head:0.000},active_effects:[{id:"minecraft:invisibility",amplifier:0,duration:-1,show_particles:0b}],attributes:[{id:"minecraft:burning_time",base:0},{id:"minecraft:max_health",base:0.9}]}

# Notify of stunting
tellraw @p "Crocodile egg growth stunted"

### FX
particle minecraft:sneeze ~ ~ ~ 0.5 0.5 0.5 0.3 20 force
playsound minecraft:block.beehive.enter master @a[distance=..6]

## Kill coal item
execute as @e[type=item,nbt={Item:{id:"minecraft:coal",count:1}},sort=nearest,limit=1] at @s run kill @s

# Kill mob
tp @s ~ ~-500 ~
kill @s