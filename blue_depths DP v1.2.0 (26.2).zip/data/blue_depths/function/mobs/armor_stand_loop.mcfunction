######## Box Jellyfish #######

### Polyp loop ###
execute as @s[tag=box_jelly_polyp] at @s run function blue_depths:mobs/box_jelly/polyp_loop

######## Other mobs #######

# Spawn Crocodile Egg
execute at @s if entity @s[tag=bd_crocEggSpawn] run function blue_depths:mobs/crocodile/croc_egg/spawn_croc_egg