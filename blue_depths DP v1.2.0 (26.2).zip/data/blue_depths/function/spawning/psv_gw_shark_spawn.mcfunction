### Spawn Great White Shark
summon salmon ~ ~ ~ {Silent:1b,DeathLootTable:"blue_depths:entities/gw_shark",PersistenceRequired:0b,NoAI:0b,Health:60f,Tags:["bd_gw_shark","bd_scanned","bd_mob","bd_bucketableBase","bd_neutralMob","bd_shark"],Passengers:[{id:"minecraft:armor_stand",Silent:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["bd_gw_shark","bd_mob","bd_bucketableBase","bd_shark"],equipment:{mainhand:{id:"minecraft:flint",count:1,components:{"minecraft:item_model":"bluedepths:blue_depths/mobs/gw_shark"}}}}],active_effects:[{id:"minecraft:invisibility",amplifier:0,duration:-1,show_particles:0b}],attributes:[{id:"minecraft:max_health",base:60},{id:"minecraft:movement_speed",base:0.5},{id:"minecraft:scale",base:3}]}

### If self is an armor stand
# Remove the bucket of salmon and replace with water bucket
#execute if entity @s[type=minecraft:armor_stand] as @a[distance=..5.5] if items entity @s weapon.mainhand minecraft:salmon_bucket run item replace entity @s weapon.mainhand with minecraft:water_bucket
#execute if entity @s[type=minecraft:armor_stand] as @a[distance=..5.5] if items entity @s weapon.offhand minecraft:salmon_bucket run item replace entity @s weapon.offhand with minecraft:water_bucket
#execute if entity @s[type=armor_stand] run kill @s

### If self is an armor stand
# Remove the bucket of salmon and replace with water bucket
execute if entity @s[type=minecraft:armor_stand] run function blue_depths:cleanup/bucket_sawp/big_salmon_swap

# Kill mob
tp @s ~ ~-500 ~
kill @s