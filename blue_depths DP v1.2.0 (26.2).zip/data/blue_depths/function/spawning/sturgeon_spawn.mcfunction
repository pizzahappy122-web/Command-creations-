# Spawn Sturgeon
summon salmon ~ ~ ~ {Silent:1b,DeathLootTable:"blue_depths:entities/sturgeon",PersistenceRequired:0b,Health:10f,Tags:["bd_sturgeon","bd_mob","bd_scanned","bd_bucketableBase"],Passengers:[{id:"minecraft:armor_stand",Silent:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["bd_sturgeon","bd_mob","bd_scanned","bd_bucketableBase"],equipment:{mainhand:{id:"minecraft:flint",count:1,components:{"minecraft:item_model":"bluedepths:blue_depths/mobs/sturgeon"}}}}],active_effects:[{id:"minecraft:resistance",amplifier:2,duration:-1,show_particles:0b},{id:"minecraft:invisibility",amplifier:0,duration:-1,show_particles:0b}],attributes:[{id:"minecraft:max_health",base:10},{id:"minecraft:scale",base:1.6}]}

### If self is an armor stand
# Remove the bucket of salmon and replace with water bucket
execute if entity @s[type=minecraft:armor_stand] run function blue_depths:cleanup/bucket_sawp/big_salmon_swap

#Kill Mob
tp @s ~ ~-500 ~
kill @s