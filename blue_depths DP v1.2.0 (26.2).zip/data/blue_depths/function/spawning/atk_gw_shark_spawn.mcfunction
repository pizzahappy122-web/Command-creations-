###### Spawn Attacking Great White Shark #######
# Note that the unique tag for this filthy animal is bd_cur_gw_shark
summon drowned ~ ~ ~ {Silent:1b,CustomNameVisible:0b,DeathLootTable:"blue_depths:entities/gw_shark",PersistenceRequired:0b,CanPickUpLoot:0b,Health:60f,IsBaby:0b,CanBreakDoors:0b,Tags:["bd_cur_gw_shark","bd_atk_gw_shark","bd_mob","bd_atk_fish","bd_nonBucketableBase","bd_neutralMob","bd_shark"],Passengers:[{id:"minecraft:armor_stand",Silent:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["bd_cur_gw_shark","bd_atk_gw_shark","bd_mob","bd_nonBucketableBase","bd_shark"],equipment:{mainhand:{id:"minecraft:flint",count:1,components:{"minecraft:item_model":"bluedepths:blue_depths/mobs/atk_gw_shark"}}}}],CustomName:"Great White Shark",active_effects:[{id:"minecraft:invisibility",amplifier:0,duration:-1,show_particles:0b}],attributes:[{id:"minecraft:attack_damage",base:5.5},{id:"minecraft:follow_range",base:20},{id:"minecraft:max_health",base:60},{id:"minecraft:movement_speed",base:0.6}]}

# Add shark to followRangeFlag scoreboard and set it to true (1)
scoreboard players set @n[type=drowned,tag=bd_atk_gw_shark] followRangeFlag 1

#Kill Mob
tp @s ~ ~-500 ~
kill @s