### Set score of salmon to a random value for spawning certain mob
execute store result score @s bdSpawner run random value 1..100

# Spawn Bull Shark (40% chance of occurring)
execute at @s if score @s bdSpawner matches 1..30 run function blue_depths:spawning/river/bull_shark/bull_shark_master

# Spawn Crocodile (60% chance of occurring)
execute at @s if score @s bdSpawner matches 31..100 run function blue_depths:spawning/river/crocodile_spawn

# Reset score just in case
scoreboard players reset @s bdSpawner