### Set score of salmon to a random value for spawning certain mob
execute store result score @s bdSpawner run random value 1..100

# Spawn Bull Shark (40% chance of occurring)
execute at @s if score @s bdSpawner matches 1..50 run function blue_depths:spawning/river/lm_bass_spawn

# Spawn Crocodile (60% chance of occurring)
execute at @s if score @s bdSpawner matches 51..100 run function blue_depths:spawning/river/bluegill_spawn

# Reset score just in case
scoreboard players reset @s bdSpawner