### Set score of salmon to a random value for spawning certain variant
execute store result score @s bdSpawner run random value 1..100

# Spawn Easter Egg Catfish: Pop Eyes (1% chance for every catfish that spawns)
execute at @s if score @s bdSpawner matches 1 run function blue_depths:spawning/river/catfish/pop_eyes
# Spawn Normal Catfish (99% chance)
execute at @s if score @s bdSpawner matches 2.. run function blue_depths:spawning/catfish_spawn


# Reset score just in case
scoreboard players reset @s bdSpawner