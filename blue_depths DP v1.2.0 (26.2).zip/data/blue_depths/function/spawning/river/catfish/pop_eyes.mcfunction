### Spawn Pop Eyes easter egg fish
summon drowned ~ ~ ~ {Silent:1b,DeathLootTable:"blue_depths:entities/catfish",PersistenceRequired:0b,CanPickUpLoot:0b,Health:5f,IsBaby:1b,CanBreakDoors:0b,Tags:["bd_catfish","bd_bucketUser","bd_scanned","bd_mob","bd_atk_fish","bd_bottomDweller","bd_passiveDrownedBase","bd_popEyes"],equipment:{head:{id:"minecraft:flint",count:1,components:{"minecraft:item_model":"bluedepths:mobs/pop_eyes"}}},drop_chances:{head:0.000},active_effects:[{id:"minecraft:invisibility",amplifier:0,duration:-1,show_particles:0b}],attributes:[{id:"minecraft:attack_damage",base:0},{id:"minecraft:follow_range",base:0},{id:"minecraft:max_health",base:5}]}

#Kill Mob
tp @s ~ ~-500 ~
kill @s