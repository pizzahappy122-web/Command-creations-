### Spawn the archerfish
summon cod ~ ~ ~ {DeathLootTable:"blue_depths:entities/river/archerfish",PersistenceRequired:0b,Health:3f,Tags:["bd_scanned","bd_archerfish","bd_bucketableBase","bd_mob","bd_bucketable","bd_cooldown"],Passengers:[{id:"minecraft:armor_stand",Silent:1b,Invulnerable:1b,Small:1b,Marker:1b,Invisible:1b,Tags:["bd_mob","bd_scanned","bd_archerfish","bd_bucketableBase","bd_bucketable","bd_cooldown"],equipment:{mainhand:{id:"minecraft:flint",count:1,components:{"minecraft:item_model":"bluedepths:mobs/archerfish"}}}}],active_effects:[{id:"minecraft:invisibility",amplifier:0,duration:-1,show_particles:0b}],attributes:[{id:"minecraft:max_health",base:3}]}

# Add archerfish the atk cool down scoreboard
scoreboard players set @n[type=cod,tag=bd_archerfish,distance=..1] bd_atkCool 0

#Kill Mob
tp @s ~ ~-500 ~
kill @s