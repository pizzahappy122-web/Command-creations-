### Spawn aggressive bull shark (35% chance)
execute if predicate blue_depths:35_percent_chance run function blue_depths:spawning/river/bull_shark/aggro_bull_shark_spawn
### Spawn neutral bull shark (65% chance)
execute unless predicate blue_depths:35_percent_chance run function blue_depths:spawning/river/bull_shark/n_bull_shark_spawn
