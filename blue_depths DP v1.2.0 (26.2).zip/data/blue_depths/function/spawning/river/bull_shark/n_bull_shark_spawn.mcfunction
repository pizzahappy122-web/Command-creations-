### Spawn Neutral Bull Shark (60% chance)
summon salmon ~ ~ ~ {Silent:1b,DeathLootTable:"blue_depths:entities/river/bull_shark",PersistenceRequired:0b,Health:32f,Tags:["bd_bullShark","bd_scanned","bd_mob","bd_bucketableBase","bd_neutralMob","bd_shark","bd_cooldown"],Passengers:[{id:"minecraft:armor_stand",Silent:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["bd_bullShark","bd_scanned","bd_mob","bd_bucketableBase","bd_shark"],equipment:{mainhand:{id:"minecraft:flint",count:1,components:{"minecraft:item_model":"bluedepths:mobs/bull_shark"}}}}],active_effects:[{id:"minecraft:invisibility",amplifier:0,duration:-1,show_particles:0b}],attributes:[{id:"minecraft:max_health",base:32},{id:"minecraft:movement_speed",base:0.5},{id:"minecraft:scale",base:1.6}]}

### If self is an armor stand
# Remove the bucket of salmon and replace with water bucket
execute if entity @s[type=minecraft:armor_stand] run function blue_depths:cleanup/bucket_sawp/big_salmon_swap

# Add bull shark to the atk cool down scoreboard
scoreboard players set @n[type=salmon,tag=bd_bullShark,distance=..1] bd_atkCool 0

# Kill mob
tp @s ~ ~-500 ~
kill @s