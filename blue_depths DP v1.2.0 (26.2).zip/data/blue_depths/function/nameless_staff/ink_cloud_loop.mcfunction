# If bd_atkCool reaches 0 for the ink cloud, kill it
execute if score @s bd_atkCool matches ..0 run kill @s

# If ink cloud cooldown timer reaches zero, remove tag, make player eligible to get harmed by ink cloud
execute as @a[tag=bd_namelessSpellCaster] at @s if score @s bd_inkCloudCooldown matches ..0 run tag @s remove bd_namelessSpellCaster

### Effects for non players
effect give @e[type=!player,type=!#blue_depths:staff_ignore,distance=..4] blindness 4 0 true
effect give @e[type=!player,type=!#blue_depths:staff_ignore,distance=..4] wither 6 0 true
effect give @e[type=!player,type=!#blue_depths:staff_ignore,distance=..4] weakness 4 0 true

### Effects for players
effect give @a[tag=!bd_namelessSpellCaster,gamemode=!creative,gamemode=!spectator,distance=..4] blindness 4 0 true
effect give @a[tag=!bd_namelessSpellCaster,gamemode=!creative,gamemode=!spectator,distance=..4] wither 6 0 true
effect give @a[tag=!bd_namelessSpellCaster,gamemode=!creative,gamemode=!spectator,distance=..4] weakness 4 0 true

## Cosmetic effects
particle minecraft:squid_ink ~ ~1.5 ~ 1 1 1 0.1 100

# Decrement scores
scoreboard players remove @s bd_atkCool 1
scoreboard players remove @a[tag=bd_namelessSpellCaster,scores={bd_inkCloudCooldown=1..}] bd_inkCloudCooldown 1