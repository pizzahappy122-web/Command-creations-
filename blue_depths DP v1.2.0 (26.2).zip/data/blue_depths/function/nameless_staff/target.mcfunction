# Reset the AI just in case
execute as @e[type=drowned,tag=bd_freshlySpawnedBD,sort=nearest,limit=1] at @s run function blue_depths:behavior/aggression/update_target

# Damage the binded as the target to force retarget
damage @e[type=drowned,tag=bd_freshlySpawnedBD,sort=nearest,limit=1] 0 minecraft:mob_attack by @e[tag=bd_bindedTarget,sort=nearest,limit=1]

#execute as @e[type=drowned,tag=bd_bindedDepths] at @s run data modify entity @s last_hurt_by_mob set from entity @n[tag=bd_bindedTarget] UUID

say hi

## Remove tags
#### Remove Temporary tag for target
tag @e[tag=bd_bindedTarget] remove bd_bindedTarget
#### Remove Temporary tag for squid
tag @e[type=drowned,tag=bd_freshlySpawnedBD] remove bd_freshlySpawnedBD