# If player is already tagged as a caster, terminate the function
execute if entity @s[tag=bd_staffCasting] run return 0
# Tag self to prevent multiple rays in the same tick
tag @s add bd_staffCasting

### Initialize the attack cooldown scoreboard to 0 if not on scoreboard
scoreboard players add @s bd_staffCooldown 0

## If player's cooldown has passed, trigger summoning
execute as @s at @s if score @s bd_staffCooldown matches 0 run function blue_depths:nameless_staff/ray/spell_cast

## If player's cooldown hasn't passed, tell player their cooldown time left
execute as @s at @s if score @s bd_staffCooldown matches 1..160 run function blue_depths:nameless_staff/display_cooldown

advancement revoke @s only blue_depths:use_nameless_staff

# Remove the tag
tag @s remove bd_staffCasting