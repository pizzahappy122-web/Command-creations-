## Set cooldown
scoreboard players set @s bd_staffCooldown 100

say hi