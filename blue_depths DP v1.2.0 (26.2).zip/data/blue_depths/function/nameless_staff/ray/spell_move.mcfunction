# Move forward according to step size
tp @s ^ ^ ^0.5

## particle trail
particle minecraft:bubble_column_up ^0 ^0.5 ^-0.5 0 0 0 0 1 force
particle minecraft:dust{color:[1,0,0],scale:3} ^0 ^0.5 ^-0.5 0 0 0 0 1 force

### Case: If colliding with a mob or player
execute as @s at @s if entity @e[type=!#blue_depths:staff_ignore,tag=!bd_namelessSpellCaster,tag=!bd_namelessBulletHit,distance=..2] run function blue_depths:nameless_staff/ray/spell_hit

### Case: When bullet reaches far enough away from caster, remove caster's safety tag
execute if score @s bd_raycast matches 110 run tag @n[tag=bd_namelessSpellCaster] remove bd_namelessSpellCaster

### Base case: If bullet reaches end of lifetime
execute as @s[scores={bd_raycast=..0}] at @s run function blue_depths:nameless_staff/ray/spell_final_hit

### Base case: If bullet collides with a solid block
execute unless block ~ ~ ~ #blue_depths:ray_permeable run function blue_depths:nameless_staff/ray/spell_final_hit

## Decrease number of steps left
scoreboard players remove @s bd_raycast 1