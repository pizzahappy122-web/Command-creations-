### Effects
# Damage & effects for non-player entities
execute as @e[type=!player,type=!#blue_depths:staff_ignore,tag=!bd_namelessBulletHit,distance=..2] run damage @s 15 minecraft:mob_attack

execute as @e[type=!player,type=!#blue_depths:staff_ignore,tag=!bd_namelessBulletHit,distance=..2] run effect give @s blindness 3 0 false

execute as @e[type=!player,type=!#blue_depths:staff_ignore,tag=!bd_namelessBulletHit,distance=..2] run effect give @s slowness 4 1 false

# Damage & effects for players
execute as @a[tag=!bd_namelessSpellCaster,tag=!bd_namelessBulletHit,gamemode=!creative,gamemode=!spectator,distance=..2] run damage @s 4 out_of_world
execute as @a[tag=!bd_namelessSpellCaster,tag=!bd_namelessBulletHit,gamemode=!creative,gamemode=!spectator,distance=..2] run effect give @s blindness 3 0 false
execute as @a[tag=!bd_namelessSpellCaster,tag=!bd_namelessBulletHit,gamemode=!creative,gamemode=!spectator,distance=..2] run effect give @s slowness 4 1 false

# Mark entities as already hit
tag @e[type=!player,type=!#blue_depths:staff_ignore,tag=!bd_namelessSpellCaster,tag=!bd_namelessBulletHit,distance=..2] add bd_namelessBulletHit
tag @a[tag=!bd_namelessSpellCaster,tag=!bd_namelessBulletHit,gamemode=!creative,gamemode=!spectator,distance=..2] add bd_namelessBulletHit


### Schedule the removal bd_namelessBulletHit 5 ticks later to avoid multiple unnecessary hits
schedule function blue_depths:nameless_staff/ray/spell_hit_cleanup 5t replace
