### Initialize steps
scoreboard players set @s bd_raycast 64

# Move the ray
execute as @s run function blue_depths:nameless_staff/ray/spell_move

## Destroy the ray, very important
kill @s