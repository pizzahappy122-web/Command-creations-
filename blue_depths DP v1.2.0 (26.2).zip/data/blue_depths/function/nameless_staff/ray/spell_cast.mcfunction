### Start cooldown
scoreboard players set @s bd_staffCooldown 200

### Summon ray
summon armor_stand ~ ~ ~ {Silent:1b,Invulnerable:1b,Small:1b,Marker:1b,Invisible:1b,Tags:["bd_namelessBullet"],equipment:{head:{id:"minecraft:flint",count:1,components:{"minecraft:item_model":"bluedepths:blue_depths/mobs/the_nameless_depth"}}}}

# Position ray at the caster's eyes and copy their facing
execute anchored eyes rotated as @s run tp @e[tag=bd_namelessBullet,limit=1,sort=nearest] ^ ^-0.5 ^ ~ ~

# Tag caster to not accidentally get hit by ray
tag @s add bd_namelessSpellCaster

# Initialize steps of the ray
scoreboard players set @n[type=armor_stand,tag=bd_namelessBullet] bd_raycast 128

### Sound effect
playsound entity.wither.shoot master @a[distance=..30] ~ ~ ~
