#### Summon cloud
summon marker ~ ~ ~ {Silent:1b,Tags:["bd_spellInkCloud"]}

#### Clean up any tagged players hit by bullet if failed to do so in it's lifetime
execute as @e[type=marker,tag=bd_spellInkCloud] at @s run tag @a[tag=bd_namelessBulletHit] remove bd_namelessBulletHit

#### If the spell caster is still within close range of cloud (aka if spell caster uses staff on ground) have them keep tag temporarily (decrements 1 per second)
execute as @a[tag=bd_namelessSpellCaster,distance=..5] run scoreboard players set @s bd_inkCloudCooldown 3

#### Add cloud to lifetime scoreboard (decrements 1 per second)
execute as @n[type=marker,tag=bd_spellInkCloud] run scoreboard players set @s bd_atkCool 8

### Cosmetic effects
particle explosion ~ ~ ~ 0.5 0.5 0.5 0 5
playsound entity.dragon_fireball.explode master @a[distance=..30] ~ ~ ~

### Very important, kill the bullet
kill @s