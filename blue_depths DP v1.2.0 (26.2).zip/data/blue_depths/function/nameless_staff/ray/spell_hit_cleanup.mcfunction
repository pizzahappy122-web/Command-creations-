execute as @e[type=armor_stand,tag=bd_namelessBullet] at @s run tag @e[tag=bd_namelessBulletHit] remove bd_namelessBulletHit
