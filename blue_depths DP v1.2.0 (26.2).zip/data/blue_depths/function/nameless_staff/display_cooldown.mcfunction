### Copy ticks into display scoreboard
scoreboard players operation @s bd_scoreDisplay = @s bd_staffCooldown

### Convert to seconds
scoreboard players operation @s bd_scoreDisplay /= #20 bd_constant

## display message of cooldown
tellraw @s [{"text":"The staff is dormant for ","color":"gray"},{"score":{"name":"@s","objective":"bd_scoreDisplay"},"color":"aqua"},{"text":" seconds.","color":"gray"}]
