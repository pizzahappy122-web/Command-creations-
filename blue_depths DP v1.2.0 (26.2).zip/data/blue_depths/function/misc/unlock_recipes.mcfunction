### Unlock recipes
recipe give @s blue_depths:bd_guide
recipe give @s blue_depths:marine_workbench
recipe give @s blue_depths:seagrill
recipe give @s blue_depths:nameless_block

tag @s add bd_unlockRecipes