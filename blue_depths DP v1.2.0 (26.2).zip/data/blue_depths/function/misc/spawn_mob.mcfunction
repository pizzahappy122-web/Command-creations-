# Spawn sturgeon eggs
execute as @s[tag=bdSturgeonSpawn] at @s run function blue_depths:mobs/sturgeon/sturgeon_eggs/sturgeon_egg_spawn

# Spawn Tuna Larva
execute as @s[tag=tunaLarvaSpawn] at @s run function blue_depths:mobs/tuna/tuna_larva/tuna_larva_spawn

# Spawn Great White Shark pup
execute as @s[tag=bd_gwPupSpawn] at @s run function blue_depths:mobs/gw_shark/pup/gw_pup_spawn

# Spawn Bull Shark Pup
execute at @s if entity @s[tag=bd_bullPupSpawn] run function blue_depths:mobs/bull_shark/pup/bull_pup_spawn