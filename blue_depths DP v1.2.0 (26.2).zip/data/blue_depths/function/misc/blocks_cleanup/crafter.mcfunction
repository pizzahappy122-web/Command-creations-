### Summon items
summon item ~ ~0.5 ~ {Item:{id:"minecraft:crafting_table",count:1}}
summon item ~ ~0.5 ~ {Item:{id:"minecraft:salmon",count:1}}
summon item ~ ~0.5 ~ {Item:{id:"minecraft:iron_ingot",count:1}}

### Replace base block with air
setblock ~ ~ ~ minecraft:air

### Kill self
kill @s