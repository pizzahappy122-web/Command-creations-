### Summon items
summon item ~ ~0.5 ~ {Item:{id:"minecraft:lightning_rod",count:2}}
summon item ~ ~0.5 ~ {Item:{id:"minecraft:cobbled_deepslate",count:1}}
summon item ~ ~0.5 ~ {Item:{id:"minecraft:iron_ingot",count:4}}
summon item ~ ~0.5 ~ {Item:{id:"minecraft:redstone_torch",count:1}}

### Replace base block with air
setblock ~ ~ ~ minecraft:air

### Kill self
kill @s