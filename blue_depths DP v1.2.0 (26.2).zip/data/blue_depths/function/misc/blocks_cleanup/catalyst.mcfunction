### Summon items
summon item ~ ~0.5 ~ {Item:{id:"minecraft:soul_sand",count:2}}
summon item ~ ~0.5 ~ {Item:{id:"minecraft:crying_obsidian",count:4}}
summon item ~ ~0.5 ~ {Item:{id:"minecraft:ender_eye",count:1}}
summon item ~ ~0.5 ~ {Item:{id:"minecraft:ink_sac",count:2}}

### Replace base block with air
setblock ~ ~ ~ minecraft:air

### Kill self
kill @s
