### Summon items
summon item ~ ~0.5 ~ {Item:{id:"minecraft:copper_ingot",count:3}}
summon item ~ ~0.5 ~ {Item:{id:"minecraft:blue_dye",count:1}}
summon item ~ ~0.5 ~ {Item:{id:"minecraft:smoker",count:1}}

### Replace base block with air
setblock ~ ~ ~ minecraft:air

### Kill self
kill @s
