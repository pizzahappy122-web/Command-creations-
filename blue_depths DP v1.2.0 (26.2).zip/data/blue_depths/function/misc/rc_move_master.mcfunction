### Archerfish spit attack move
execute if entity @s[tag=bd_archerfishSpit] run function blue_depths:mobs/archerfish/spit/spit_move

### Crocodile lunge
execute if entity @s[tag=bd_crocLunge] run function blue_depths:mobs/crocodile/lunge/lunge_move