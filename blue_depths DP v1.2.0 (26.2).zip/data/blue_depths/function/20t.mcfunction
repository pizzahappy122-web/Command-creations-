##### Check armor stands #####
execute as @e[type=minecraft:armor_stand,tag=bd_mob,tag=bd_nonBucketableBase,tag=!bd_bucketable,tag=!bd_killModel] at @s unless entity @e[type=#blue_depths:nonbucketable_bases,distance=..2.1,tag=bd_mob] run kill @s

### Kill models with no base
execute as @e[type=minecraft:armor_stand,tag=bd_killModel] run kill @s

### Prevent Aggresive fish from following player on land in nighttime
# Execute as any aggressive/attack fish so this way it can apply multiple fish attacking
# For every attack fish
execute as @e[type=drowned,tag=bd_atk_fish,tag=!bd_passiveDrownedBase] at @s run function blue_depths:behavior/aggression/check_target


##### Mob Spawn Scans For Spawning #####
# Cod spawn scan
execute as @e[type=cod,tag=!bd_scanned] at @s run function blue_depths:mob_scans/cod_scan
# Salmon spawn scan
execute as @e[type=salmon,tag=!bd_scanned] at @s run function blue_depths:mob_scans/salmon_scan
# Tropical Fish spawn scan
execute as @e[type=minecraft:tropical_fish,tag=!bd_scanned] at @s run function blue_depths:mob_scans/tropical_fish_scan
# GW Shark scan
execute as @e[type=salmon,tag=bd_gw_shark,tag=!bd_scanned_gw_shark] at @s run function blue_depths:mob_scans/gw_shark_scan

###### Grill and Workbench commands ######
#Enabling the grill to function once in existence if a player is within 8 blocks of the grill
execute as @e[type=minecraft:glow_item_frame,tag=bd_seagrill] at @s if entity @a[distance=..8] run function blue_depths:blocks/seagrill/cooking
# Enable the crafter to function once in existence if a player is within 8 blocks of the crafter
execute as @e[type=minecraft:glow_item_frame,tag=bd_seacrafter] at @s if entity @a[distance=..8] at @s run function blue_depths:blocks/sea_crafter/craft

###### Mob loops ######

### Cod base for mob baby loops and other such things
execute as @e[tag=bd_mobGrowth,type=cod] run function blue_depths:mobs/cod_base_loop
### Salmon base for mob baby loops and other such things
execute as @e[tag=bd_mobGrowth,type=salmon] run function blue_depths:mobs/salmon_base_loop
### Tropical Fish base for mob baby loops and other such things
execute as @e[tag=bd_mobGrowth,type=tropical_fish] run function blue_depths:mobs/tropicalfish_base_loop
### Drowned base for mob baby loops and other such things
execute as @e[tag=bd_mobGrowth,type=drowned] run function blue_depths:mobs/drowned_base_loop
### Trutle base for mob baby loops and other such things
execute as @e[tag=bd_mobGrowth,type=turtle] run function blue_depths:mobs/turtle_base_loop
### Armor stand base for mob baby loops and other such thing
execute as @e[tag=bd_mobGrowth,type=armor_stand] run function blue_depths:mobs/armor_stand_loop

### Box Jellyfish Sting ###
execute as @e[type=minecraft:cod,tag=bd_boxJelly] at @s if entity @a[distance=..3,gamemode=!creative,gamemode=!spectator] run function blue_depths:mobs/box_jelly/sting

##### Ink cloud effects and lifetime stuff
execute as @e[type=marker,tag=bd_spellInkCloud] at @s run function blue_depths:nameless_staff/ink_cloud_loop

## Reschedule
schedule function blue_depths:20t 20t