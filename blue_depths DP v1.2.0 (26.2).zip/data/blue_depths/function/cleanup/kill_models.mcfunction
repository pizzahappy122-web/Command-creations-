######### Kill the models ######### 

# For medium size mobs like adult tuna (salmon base)
execute as @s[tag=bd_mob] at @s unless entity @e[type=salmon,tag=bd_mob,distance=0..1] run kill @s

# For small mobs like the young tuna (cod base)
execute as @s[tag=bd_mob] at @s unless entity @e[type=cod,tag=bd_mob,distance=0..1] run kill @s

# For large mobs like Orca (dolphin base)
execute as @s[tag=bd_mob] at @s unless entity @e[type=dolphin,tag=bd_mob,distance=0..1] run kill @s

# For large mobs like GW Shark (salmon base)
execute as @s[tag=bd_mob] at @s unless entity @e[type=salmon,tag=bd_mob,distance=0..1.3] run kill @s

# For large aggressive mobs like aggro GW shark (drowned base)
execute as @s[tag=bd_mob] at @s unless entity @e[type=drowned,tag=bd_mob,distance=0..2.1] run kill @s

# For semi-aquatic mobs (turtle base)
execute as @s[tag=bd_mob] at @s unless entity @e[type=minecraft:turtle,tag=bd_mob,distance=..1] run kill @s