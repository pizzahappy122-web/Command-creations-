######## Perform the appropriate switch #########

### Swap bucket with bucket of Largemouth bass
execute as @s if entity @s[tag=bd_lmBass] run function blue_depths:mobs/lm_bass/give_lmbass_bucket

### Swap bucket with bucket of Archerfish
execute as @s if entity @s[tag=bd_archerfish] run function blue_depths:mobs/archerfish/bucket/give_archerfish_bucket

### Swap bucket with bucket of Bluegill
execute as @s if entity @s[tag=bd_bluegill] run function blue_depths:mobs/bluegill/give_bluegill_bucket