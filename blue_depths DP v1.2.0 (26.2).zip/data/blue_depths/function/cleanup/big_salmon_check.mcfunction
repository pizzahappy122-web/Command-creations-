########## Perform the appropriate switch ##########

##### Sharks

### Great White Shark
# Wild variant
execute at @s if entity @s[tag=bd_gw_shark,tag=!bd_pet] run function blue_depths:spawning/psv_gw_shark_spawn
# Pet variant
execute at @s if entity @s[tag=bd_gw_shark,tag=bd_pet] run function blue_depths:mobs/gw_shark/pup/gw_pup_grow
# Pup variant
execute at @s if entity @s[tag=bd_greatWhitePup] run function blue_depths:mobs/gw_shark/pup/gw_pup_spawn

### Bull Shark
# Wild Variant
execute at @s if entity @s[tag=bd_bullShark,tag=!bd_pet] run function blue_depths:spawning/river/bull_shark/n_bull_shark_spawn
# Pet variant
execute at @s if entity @s[tag=bd_bullShark,tag=bd_pet] run function blue_depths:mobs/bull_shark/pup/bull_pup_grow


#### Others

### Sturgeon
# Wild variant
execute at @s if entity @s[tag=bd_sturgeon,tag=!bd_pet] run function blue_depths:spawning/sturgeon_spawn
# Pet variant
execute at @s if entity @s[tag=bd_sturgeon,tag=bd_pet] run function blue_depths:mobs/sturgeon/sturgeon_juvenile/sturgeon_juvenile_grow

### Tuna
# Wild variant
execute at @s if entity @s[tag=bd_tuna,tag=!bd_pet] run function blue_depths:mobs/tuna/tuna_replace
# Pet variant
execute at @s if entity @s[tag=bd_tuna,tag=bd_pet] run function blue_depths:mobs/tuna/tuna_juvenile/tuna_juvenile_grow
