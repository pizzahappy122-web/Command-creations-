# Scan player if bucket and determine which hand holds the bucket, and tag the player to remove bucket
execute as @a[distance=..5.5] if items entity @s weapon.mainhand minecraft:salmon_bucket run tag @s add bd_rightHandSwapS
execute as @a[distance=..5.5,tag=!bd_rightHandSwapS] if items entity @s weapon.offhand minecraft:salmon_bucket run tag @s add bd_leftHandSwapS

### Perform swap
# If player has bucket in right hand, swap
execute as @a[tag=bd_rightHandSwapS,distance=..5.5] run item replace entity @s weapon.mainhand with minecraft:water_bucket
# If player has bucket in left hand, swap
execute as @a[tag=bd_leftHandSwapS,distance=..5.5] run item replace entity @s weapon.offhand with minecraft:water_bucket

### Remove leftover Tags
tag @a[tag=bd_rightHandSwapS,distance=..5.5] remove bd_rightHandSwapS
tag @a[tag=bd_leftHandSwapS,distance=..5.5] remove bd_leftHandSwapS

tag @s add bd_stopCheck

### Kill self just in case
kill @s