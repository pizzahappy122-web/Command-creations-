# Scan player if bucket and determine which hand holds the bucket, and tag the player to remove bucket
execute as @a[distance=..5.5] if items entity @s weapon.mainhand minecraft:cod_bucket run tag @s add bd_rightHandSwapC
execute as @a[distance=..5.5,tag=!bd_rightHandSwapC] if items entity @s weapon.offhand minecraft:cod_bucket run tag @s add bd_leftHandSwapC

### Perform swap
# If player has bucket in right hand, swap
execute as @a[tag=bd_rightHandSwapC,distance=..5.5] run item replace entity @s weapon.mainhand with minecraft:water_bucket
# If player has bucket in left hand, swap
execute as @a[tag=bd_leftHandSwapC,distance=..5.5] run item replace entity @s weapon.offhand with minecraft:water_bucket

### Remove leftover Tags
tag @a[tag=bd_rightHandSwapC,distance=..5.5] remove bd_rightHandSwapC
tag @a[tag=bd_leftHandSwapC,distance=..5.5] remove bd_leftHandSwapC

tag @s add bd_stopCheck

### Kill self just in case
kill @s