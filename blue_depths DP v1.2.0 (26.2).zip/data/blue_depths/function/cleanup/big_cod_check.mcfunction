######## Perform the appropriate switch #########


#### Tuna (juvenile) ####
# Growing tuna
execute at @s if entity @s[tag=bd_tuna_young,tag=bd_mobGrowth] run function blue_depths:mobs/tuna/tuna_juvenile/tuna_juvenile_spawn
# Stunted Tuna
execute at @s if entity @s[tag=bd_tuna_young,tag=!bd_mobGrowth] run function blue_depths:mobs/tuna/tuna_juvenile/tuna_juvenile_stunt


#### Sturgeon ####

### Sturgeon Eggs
# Growing eggs
execute at @s if entity @s[tag=bd_sturgeon_eggs] run function blue_depths:mobs/sturgeon/sturgeon_eggs/sturgeon_egg_spawn
# Stunted eggs
execute at @s if entity @s[tag=bd_sturgeon_eggs_stunt] run function blue_depths:mobs/sturgeon/sturgeon_eggs/sturgeon_egg_stunt

### Sturgeon juvenile
# Growing sturgeon
execute at @s if entity @s[tag=bd_juv_sturgeon] run function blue_depths:mobs/sturgeon/sturgeon_juvenile/sturgeon_juvenile_spawn
# Stunted sturgeon
execute at @s if entity @s[tag=bd_juv_sturgeon_stunt] run function blue_depths:mobs/sturgeon/sturgeon_juvenile/sturgeon_juvenile_stunt


#### Box Jellyfish ####
execute at @s if entity @s[tag=bd_boxJelly] run function blue_depths:cleanup/box_jelly/box_jelly_check