####### Bucket checks
### Salmon check
# Check main hand
execute if items entity @a[distance=..5.5] weapon.mainhand minecraft:salmon_bucket run function blue_depths:cleanup/big_salmon_check
# Check off hand
execute unless entity @s[tag=bd_stopCheck] unless items entity @a[distance=..5.5] weapon.mainhand minecraft:salmon_bucket if items entity @a[distance=..5.5] weapon.offhand minecraft:salmon_bucket run function blue_depths:cleanup/big_salmon_check

### Cod check
# Check main hand
execute unless entity @s[tag=bd_stopCheck] if items entity @a[distance=..5.5] weapon.mainhand minecraft:cod_bucket run function blue_depths:cleanup/big_cod_check
# Check off hand
execute unless entity @s[tag=bd_stopCheck] unless items entity @a[distance=..5.5] weapon.mainhand minecraft:cod_bucket if items entity @a[distance=..5.5] weapon.offhand minecraft:cod_bucket run function blue_depths:cleanup/big_cod_check


### Tag model to kill later if no player with bucket is found to prevent rescanning
#execute unless entity @n[type=minecraft:player,distance=..5.5,nbt={SelectedItem:{id:"minecraft:salmon_bucket"}}] run tag @s add bd_killModel
tag @s add bd_killModel