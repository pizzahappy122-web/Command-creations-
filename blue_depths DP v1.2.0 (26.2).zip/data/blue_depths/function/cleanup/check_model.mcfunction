### Bucket checks
### Salmon check
# Check main hand
execute if items entity @a[distance=..4] weapon.mainhand minecraft:salmon_bucket run function blue_depths:cleanup/salmon_check
# Check off hand
execute unless entity @s[tag=bd_stopCheck] unless items entity @a[distance=..4] weapon.mainhand minecraft:salmon_bucket if items entity @a[distance=..5.5] weapon.offhand minecraft:salmon_bucket run function blue_depths:cleanup/salmon_check

### Cod check
# Check main hand
execute unless entity @s[tag=bd_stopCheck] if items entity @a[distance=..4] weapon.mainhand minecraft:cod_bucket run function blue_depths:cleanup/cod_check
# Check off hand
execute unless entity @s[tag=bd_stopCheck] unless items entity @a[distance=..4] weapon.mainhand minecraft:cod_bucket if items entity @a[distance=..5.5] weapon.offhand minecraft:cod_bucket run function blue_depths:cleanup/cod_check

### Kill model if no player with bucket is found
tag @s add bd_killModel