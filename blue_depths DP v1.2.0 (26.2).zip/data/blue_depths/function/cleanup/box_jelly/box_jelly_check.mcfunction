#### Juvenile Jellies ####

### Growing Jellies
# Blue
execute if entity @s[tag=bd_blueBoxJellyYoung,tag=bd_mobGrowth] run function blue_depths:mobs/box_jelly/blue_young/blue_spawn
# Yellow
execute if entity @s[tag=bd_yellowBoxJellyYoung,tag=bd_mobGrowth] run function blue_depths:mobs/box_jelly/yellow_young/yellow_spawn
# Brown
execute if entity @s[tag=bd_brownBoxJellyYoung,tag=bd_mobGrowth] run function blue_depths:mobs/box_jelly/brown_young/brown_spawn
# Ghost
execute if entity @s[tag=bd_ghostBoxJellyYoung,tag=bd_mobGrowth] run function blue_depths:mobs/box_jelly/ghost_young/ghost_spawn
# White
execute if entity @s[tag=bd_whiteBoxJellyYoung,tag=bd_mobGrowth] run function blue_depths:mobs/box_jelly/white_young/white_spawn
# Pink
execute if entity @s[tag=bd_pinkBoxJellyYoung,tag=bd_mobGrowth] run function blue_depths:mobs/box_jelly/pink_young/pink_spawn

### Stunted Jellies
# Blue
execute if entity @s[tag=bd_blueBoxJellyYoung,tag=!bd_mobGrowth] run function blue_depths:mobs/box_jelly/blue_young/blue_young_stunt
# Yellow
execute if entity @s[tag=bd_yellowBoxJellyYoung,tag=!bd_mobGrowth] run function blue_depths:mobs/box_jelly/yellow_young/yellow_young_stunt
# Brown
execute if entity @s[tag=bd_brownBoxJellyYoung,tag=!bd_mobGrowth] run function blue_depths:mobs/box_jelly/brown_young/brown_young_stunt
# Ghost
execute if entity @s[tag=bd_ghostBoxJellyYoung,tag=!bd_mobGrowth] run function blue_depths:mobs/box_jelly/ghost_young/ghost_young_stunt
# White
execute if entity @s[tag=bd_whiteBoxJellyYoung,tag=!bd_mobGrowth] run function blue_depths:mobs/box_jelly/white_young/white_young_stunt
# Pink
execute if entity @s[tag=bd_pinkBoxJellyYoung,tag=!bd_mobGrowth] run function blue_depths:mobs/box_jelly/pink_young/pink_young_stunt



#### Adult Jellies ####

### Pet Jellies
# Blue
execute if entity @s[tag=bd_blueBoxJelly,tag=bd_pet] run function blue_depths:mobs/box_jelly/blue_young/blue_young_grow
# Yellow
execute if entity @s[tag=bd_yellowBoxJelly,tag=bd_pet] run function blue_depths:mobs/box_jelly/yellow_young/yellow_young_grow
# Brown
execute if entity @s[tag=bd_brownBoxJelly,tag=bd_pet] run function blue_depths:mobs/box_jelly/brown_young/brown_young_grow
# Ghost
execute if entity @s[tag=bd_ghostBoxJelly,tag=bd_pet] run function blue_depths:mobs/box_jelly/ghost_young/ghost_young_grow
# White
execute if entity @s[tag=bd_whiteBoxJelly,tag=bd_pet] run function blue_depths:mobs/box_jelly/white_young/white_young_grow
# Pink
execute if entity @s[tag=bd_pinkBoxJelly,tag=bd_pet] run function blue_depths:mobs/box_jelly/pink_young/pink_young_grow


### Wild Jellies
# Blue
execute if entity @s[tag=bd_blueBoxJelly,tag=!bd_pet] run function blue_depths:cleanup/box_jelly/blue
# Yellow
execute if entity @s[tag=bd_yellowBoxJelly,tag=!bd_pet] run function blue_depths:cleanup/box_jelly/yellow
# Brown
execute if entity @s[tag=bd_brownBoxJelly,tag=!bd_pet] run function blue_depths:cleanup/box_jelly/brown
# Ghost
execute if entity @s[tag=bd_ghostBoxJelly,tag=!bd_pet] run function blue_depths:cleanup/box_jelly/ghost
# White
execute if entity @s[tag=bd_whiteBoxJelly,tag=!bd_pet] run function blue_depths:cleanup/box_jelly/white
# Pink
execute if entity @s[tag=bd_pinkBoxJelly,tag=!bd_pet] run function blue_depths:cleanup/box_jelly/pink
