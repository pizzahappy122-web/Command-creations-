# Spawn mature white jelly
summon cod ~ ~ ~ {Silent:1b,DeathLootTable:"blue_depths:entities/box_jellies/brown_box_jelly",PersistenceRequired:0b,Health:10f,Tags:["bd_scanned","bd_mob","bd_brownBoxJelly","bd_boxJelly","bd_bucketableBase"],Passengers:[{id:"minecraft:armor_stand",Silent:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["bd_mob","bd_brownBoxJelly","bd_boxJelly","bd_bucketableBase"],equipment:{mainhand:{id:"minecraft:flint",count:1,components:{"minecraft:item_model":"bluedepths:blue_depths/mobs/box_jellies/brown_box_jellyfish"}}}}],active_effects:[{id:"minecraft:invisibility",amplifier:0,duration:-1,show_particles:0b}],attributes:[{id:"minecraft:max_health",base:10},{id:"minecraft:movement_speed",base:0.4},{id:"minecraft:scale",base:1.5}]}

### If self is an armor stand
# Remove the bucket of salmon and replace with water bucket
execute if entity @s[type=minecraft:armor_stand] run function blue_depths:cleanup/bucket_sawp/big_cod_swap

# Kill juvenile
tp @s ~ ~-500 ~
kill @s