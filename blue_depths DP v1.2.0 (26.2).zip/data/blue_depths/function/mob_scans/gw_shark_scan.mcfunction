####Execute as at eligible GW Shark

##Curious Great White Spawn
execute if predicate blue_depths:atk_gw_shark_chance run function blue_depths:spawning/atk_gw_shark_spawn

## Add tag
tag @s add bd_scanned_gw_shark