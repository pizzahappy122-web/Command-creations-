####Execute as and at eligible salmon

## Tuna Spawn
execute if predicate blue_depths:20_percent_chance if biome ~ ~ ~ minecraft:mangrove_swamp unless entity @a[distance=..6] unless block ~ ~ ~1 minecraft:dispenser unless block ~ ~ ~-1 minecraft:dispenser unless block ~ ~1 ~ minecraft:dispenser unless block ~ ~-1 ~ minecraft:dispenser unless block ~1 ~ ~ minecraft:dispenser unless block ~-1 ~ ~ minecraft:dispenser run function blue_depths:spawning/river/catfish/catfish_master

###### Tag the salmon to prevent rescan ######
## Add tag
tag @s add bd_scanned