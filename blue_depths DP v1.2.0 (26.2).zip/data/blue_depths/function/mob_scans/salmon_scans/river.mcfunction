##### Spawn river creatures

## Common Fish Spawn Spawn
execute if predicate blue_depths:20_percent_chance unless entity @a[distance=..6] unless block ~ ~ ~1 minecraft:dispenser unless block ~ ~ ~-1 minecraft:dispenser unless block ~ ~1 ~ minecraft:dispenser unless block ~ ~-1 ~ minecraft:dispenser unless block ~1 ~ ~ minecraft:dispenser unless block ~-1 ~ ~ minecraft:dispenser run function blue_depths:spawning/river/common_spawn

## Catfish Spawn
execute if predicate blue_depths:15_percent_chance unless entity @a[distance=..6] unless block ~ ~ ~1 minecraft:dispenser unless block ~ ~ ~-1 minecraft:dispenser unless block ~ ~1 ~ minecraft:dispenser unless block ~ ~-1 ~ minecraft:dispenser unless block ~1 ~ ~ minecraft:dispenser unless block ~-1 ~ ~ minecraft:dispenser run function blue_depths:spawning/river/catfish/catfish_master

## Spawn a predator
execute if predicate blue_depths:8_percent_chance unless entity @a[distance=..6] unless block ~ ~ ~1 minecraft:dispenser unless block ~ ~ ~-1 minecraft:dispenser unless block ~ ~1 ~ minecraft:dispenser unless block ~ ~-1 ~ minecraft:dispenser unless block ~1 ~ ~ minecraft:dispenser unless block ~-1 ~ ~ minecraft:dispenser run function blue_depths:spawning/river/predator_master

## Spawn Electric Eel
execute if predicate blue_depths:5_percent_chance unless entity @a[distance=..6] unless block ~ ~ ~1 minecraft:dispenser unless block ~ ~ ~-1 minecraft:dispenser unless block ~ ~1 ~ minecraft:dispenser unless block ~ ~-1 ~ minecraft:dispenser unless block ~1 ~ ~ minecraft:dispenser unless block ~-1 ~ ~ minecraft:dispenser run function blue_depths:spawning/river/electric_eel_spawn

## Archerfish Spawn
execute if predicate blue_depths:4_1_percent_chance unless entity @a[distance=..6] unless block ~ ~ ~1 minecraft:dispenser unless block ~ ~ ~-1 minecraft:dispenser unless block ~ ~1 ~ minecraft:dispenser unless block ~ ~-1 ~ minecraft:dispenser unless block ~1 ~ ~ minecraft:dispenser unless block ~-1 ~ ~ minecraft:dispenser run function blue_depths:spawning/river/archerfish_spawn

## Sturgeon Spawn
execute if predicate blue_depths:4_percent_chance unless entity @a[distance=..6] unless block ~ ~ ~1 minecraft:dispenser unless block ~ ~ ~-1 minecraft:dispenser unless block ~ ~1 ~ minecraft:dispenser unless block ~ ~-1 ~ minecraft:dispenser unless block ~1 ~ ~ minecraft:dispenser unless block ~-1 ~ ~ minecraft:dispenser run function blue_depths:spawning/sturgeon_spawn
