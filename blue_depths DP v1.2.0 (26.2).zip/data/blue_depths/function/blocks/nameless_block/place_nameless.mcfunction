setblock ~ ~ ~ minecraft:dropper{CustomName:"The Nameless Catalyst"} replace
playsound minecraft:block.stone.place master @a[distance=..6] ~ ~ ~ 4 1

tag @s add bd_placedBlock