# Summon drops
summon item ~ ~0.5 ~ {Item:{id:"minecraft:glow_item_frame",count:1,components:{"minecraft:custom_name":{"color":"red","italic":false,"text":"The Nameless Catalyst"},"minecraft:item_model":"bluedepths:blue_depths/blocks/nameless_block","minecraft:entity_data":{id:"minecraft:glow_item_frame",Item:{id:"minecraft:glow_item_frame",count:1,components:{"minecraft:item_model":"bluedepths:blue_depths/blocks/nameless_block"}},Fixed:1b,Invisible:1b,Silent:1b,Invulnerable:1b,Tags:["bd_namelessBlock","bd_block"]}}}}

#kill obsidian drop
kill @e[type=item,nbt={Item:{id:"minecraft:dropper"}},distance=0..2,sort=nearest,limit=1]

# Kill item frame
kill @s