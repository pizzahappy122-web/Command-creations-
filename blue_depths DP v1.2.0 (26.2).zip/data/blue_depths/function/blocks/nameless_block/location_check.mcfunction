# Give error message to the player that catalyst should be in an ocean
execute unless predicate blue_depths:is_ocean run function blue_depths:blocks/nameless_block/warn_ocean
# Give error message saying that the player must be at y=45 or below
execute unless predicate blue_depths:is_below run function blue_depths:blocks/nameless_block/warn_immersion
# Give error for block not submerged in water
execute unless predicate blue_depths:water_above run function blue_depths:blocks/nameless_block/warn_water
# Start the ritual
execute if predicate blue_depths:water_above if predicate blue_depths:is_below if predicate blue_depths:is_ocean run function blue_depths:boss/the_nameless_depth/boss_start/ritual_start