# Message
tellraw @a[distance=..70] {"color":"dark_aqua","italic":false,"text":"The Catalyst seeks deeper immersion..."}
# Sound
playsound entity.squid.squirt master @a[distance=..70] ~ ~ ~
# Particles
particle minecraft:smoke ~ ~1.5 ~ .125 .125 .125 0 25