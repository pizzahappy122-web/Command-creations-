# Message
tellraw @a[distance=..70] {"color":"blue","italic":false,"text":"The Catalyst seeks the ocean..."}
# Sound
playsound entity.squid.squirt master @a[distance=..70] ~ ~ ~
# Particles
particle minecraft:smoke ~ ~1.5 ~ .125 .125 .125 0 25