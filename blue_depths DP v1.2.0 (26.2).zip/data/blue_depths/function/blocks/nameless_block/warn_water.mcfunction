# Message
tellraw @a[distance=..70] {"color":"red","italic":false,"text":"The Catalyst requires moisture..."}
# Sound
playsound entity.squid.squirt master @a[distance=..70] ~ ~ ~
# Particles
particle minecraft:smoke ~ ~1.5 ~ .125 .125 .125 0 25