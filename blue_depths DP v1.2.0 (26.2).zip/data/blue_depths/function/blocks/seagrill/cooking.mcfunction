##### Recipes #####
# Catfish
execute if data block ~ ~ ~ {Items:[{Slot:0b,id:"minecraft:flint",components:{"minecraft:item_model":"bluedepths:blue_depths/items/raw_catfish"}}]} unless data block ~ ~ ~ Items[{Slot:2b}] run function blue_depths:blocks/seagrill/cook/check_contents/check_food
# Tuna fillet
execute if data block ~ ~ ~ {Items:[{Slot:0b,id:"minecraft:flint",components:{"minecraft:item_model":"bluedepths:blue_depths/items/tuna_fillet"}}]} unless data block ~ ~ ~ Items[{Slot:2b}] run function blue_depths:blocks/seagrill/cook/check_contents/check_food
# Sturgeon Scute
execute if data block ~ ~ ~ {Items:[{Slot:0b,id:"minecraft:flint",components:{"minecraft:item_model":"bluedepths:blue_depths/items/sturgeon_scute"}}]} if items block ~ ~ ~ container.1 minecraft:blaze_rod unless data block ~ ~ ~ Items[{Slot:2b}] run function blue_depths:blocks/seagrill/cook/check_contents/check_sturgeon_scute
# Jellyfish Nematocyst Gel
execute if data block ~ ~ ~ {Items:[{Slot:0b,id:"minecraft:flint",components:{"minecraft:item_model":"bluedepths:blue_depths/items/nematocyst_gel"}}]} unless data block ~ ~ ~ Items[{Slot:2b}] run function blue_depths:blocks/seagrill/cook/check_contents/check_nematocyst
# Largemouth Bass
execute if data block ~ ~ ~ {Items:[{Slot:0b,id:"minecraft:flint",components:{"minecraft:item_model":"bluedepths:items/raw_lm_bass"}}]} unless data block ~ ~ ~ Items[{Slot:2b}] run function blue_depths:blocks/seagrill/cook/check_contents/check_food
# Bluegill
execute if data block ~ ~ ~ {Items:[{Slot:0b,id:"minecraft:flint",components:{"minecraft:item_model":"bluedepths:items/raw_bluegill"}}]} unless data block ~ ~ ~ Items[{Slot:2b}] run function blue_depths:blocks/seagrill/cook/check_contents/check_food
