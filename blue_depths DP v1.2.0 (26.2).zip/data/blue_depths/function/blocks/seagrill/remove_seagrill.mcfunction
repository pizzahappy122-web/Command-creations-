# Summon drops
summon item ~ ~0.5 ~ {Item:{id:"minecraft:glow_item_frame",count:1,components:{"minecraft:custom_name":{"color":"blue","italic":false,"text":"Deep Blue Grill"},"minecraft:item_model":"bluedepths:blue_depths/blocks/seagrill","minecraft:entity_data":{id:"minecraft:glow_item_frame",Item:{id:"minecraft:glow_item_frame",count:1,components:{"minecraft:item_model":"bluedepths:blue_depths/blocks/seagrill"}},Fixed:1b,Invisible:1b,Silent:1b,Invulnerable:1b,Tags:["bd_seagrill","bd_block"]}}}}

#kill Smoker drop
kill @e[type=item,nbt={Item:{id:"minecraft:smoker"}},distance=0..2,sort=nearest,limit=1]

# Kill item frame
kill @s