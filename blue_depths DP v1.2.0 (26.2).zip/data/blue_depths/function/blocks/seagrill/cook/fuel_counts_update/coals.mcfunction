######## Dynamically change the input and output counts based on score values

### Update counts
# Add one to the output count
scoreboard players add @s bd_containerOutputCount 1
# Subtract one from the new input
scoreboard players remove @s bd_containerNewInputCount 1
# Subtract one from the Fuel Multi
scoreboard players remove @s bd_containerFuelMulti 1
## Update Fuel remainder
# Copy FuelMulti to FuelRemainder
scoreboard players operation @s bd_fuelRemainder = @s bd_containerFuelMulti
#Get the remainder using modulo
scoreboard players operation @s bd_fuelRemainder %= #bd_8 bd_constant

# Quit condition case
execute if score @s bd_containerNewInputCount matches ..7 if score @s bd_fuelRemainder matches 0 run tag @s add bd_quitCooking
#execute if score @s bd_containerFuelMulti matches 8 if score @s bd_containerNewInputCount matches ..7 run tag @s add bd_quitCooking


### Recurse, IF Fuel Multi and Input are not zero
execute unless entity @s[tag=bd_quitCooking] if score @s bd_containerFuelMulti matches 1.. if score @s bd_containerNewInputCount matches 1.. run function blue_depths:blocks/seagrill/cook/fuel_counts_update/coals
