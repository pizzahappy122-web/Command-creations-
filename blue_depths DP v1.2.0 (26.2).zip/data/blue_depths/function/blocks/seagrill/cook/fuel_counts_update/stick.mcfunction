######## Dynamically change the input and output counts based on score values


### Update counts
# Add one to the output count
scoreboard players add @s bd_containerOutputCount 1
# Subtract one from the new input
scoreboard players remove @s bd_containerNewInputCount 1
# Subtract one from the Fuel Multi
scoreboard players remove @s bd_containerFuelMulti 1


### Recurse, IF Fuel Multi and Input are not zero
execute unless entity @s[tag=bd_quitCooking] if score @s bd_containerFuelMulti matches 1.. if score @s bd_containerNewInputCount matches 1.. run function blue_depths:blocks/seagrill/cook/fuel_counts_update/stick
