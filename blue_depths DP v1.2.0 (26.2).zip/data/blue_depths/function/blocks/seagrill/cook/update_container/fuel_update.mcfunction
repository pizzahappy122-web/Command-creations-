### Update fuel slot
# Coal
$execute if data block ~ ~ ~ Items[{Slot:1b,id:"minecraft:coal"}] run item replace block ~ ~ ~ container.1 with minecraft:coal $(fuelVal)
# Charcoal
$execute if data block ~ ~ ~ Items[{Slot:1b,id:"minecraft:charcoal"}] run item replace block ~ ~ ~ container.1 with minecraft:charcoal $(fuelVal)
# Stick
$execute if data block ~ ~ ~ Items[{Slot:1b,id:"minecraft:stick"}] run item replace block ~ ~ ~ container.1 with minecraft:stick $(fuelVal)
