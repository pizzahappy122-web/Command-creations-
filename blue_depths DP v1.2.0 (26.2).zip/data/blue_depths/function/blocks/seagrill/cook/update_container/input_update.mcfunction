### Update container slot
# Tuna Fillet
$execute if items block ~ ~ ~ container.0 flint[item_model="bluedepths:blue_depths/items/tuna_fillet"] run item replace block ~ ~ ~ container.0 with minecraft:flint[item_model="bluedepths:blue_depths/items/tuna_fillet",custom_name={"italic":false,"text":"Tuna Fillet"},consumable={animation:"eat",sound:"entity.generic.eat"},food={nutrition:3,saturation:2}] $(inputVal)
# Catfish
$execute if items block ~ ~ ~ container.0 flint[item_model="bluedepths:blue_depths/items/raw_catfish"] run item replace block ~ ~ ~ container.0 with minecraft:flint[item_model="bluedepths:blue_depths/items/raw_catfish",custom_name={"italic":false,"text":"Raw Catfish"},consumable={animation:"eat",sound:"entity.generic.eat"},food={nutrition:2,saturation:0.4}] $(inputVal)
# Nematocyst Gel
$execute if items block ~ ~ ~ container.0 flint[item_model="bluedepths:blue_depths/items/nematocyst_gel"] run item replace block ~ ~ ~ container.0 with minecraft:flint[item_model="bluedepths:blue_depths/items/nematocyst_gel",custom_name={"italic":false,"text":"Nematocyst Gel"}] $(inputVal)
# Bluegill
$execute if items block ~ ~ ~ container.0 flint[item_model="bluedepths:items/raw_bluegill"] run item replace block ~ ~ ~ container.0 with minecraft:flint[item_model="bluedepths:items/raw_bluegill",custom_name={"italic":false,"text":"Raw Bluegill"},consumable={animation:"eat",sound:"entity.generic.eat"},food={nutrition:2,saturation:0.4}] $(inputVal)
# Largemouth Bass
$execute if items block ~ ~ ~ container.0 flint[item_model="bluedepths:items/raw_lm_bass"] run item replace block ~ ~ ~ container.0 with minecraft:flint[item_model="bluedepths:items/raw_lm_bass",custom_name={"italic":false,"text":"Raw Largemouth Bass"},consumable={animation:"eat",sound:"entity.generic.eat"},food={nutrition:2,saturation:0.4}] $(inputVal)
