### Update container slot
# Tuna Steak
$execute if items block ~ ~ ~ container.0 flint[item_model="bluedepths:blue_depths/items/tuna_fillet"] run item replace block ~ ~ ~ container.2 with minecraft:flint[item_model="bluedepths:blue_depths/items/tuna_steak",custom_name={"italic":false,"text":"Tuna Steak"},consumable={animation:"eat",sound:"entity.generic.eat"},food={nutrition:8,saturation:13}] $(outputVal)
# Catfish
$execute if items block ~ ~ ~ container.0 flint[item_model="bluedepths:blue_depths/items/raw_catfish"] run item replace block ~ ~ ~ container.2 with minecraft:flint[item_model="bluedepths:blue_depths/items/cooked_catfish",custom_name={"italic":false,"text":"Cooked Catfish"},consumable={animation:"eat",sound:"entity.generic.eat"},food={nutrition:6,saturation:8}] $(outputVal)
# Nematocyst Gel
$execute if items block ~ ~ ~ container.0 flint[item_model="bluedepths:blue_depths/items/nematocyst_gel"] run item replace block ~ ~ ~ container.2 with minecraft:slime_ball $(outputVal)
# Armorbite
$execute if items block ~ ~ ~ container.0 flint[item_model="bluedepths:blue_depths/items/sturgeon_scute"] run item replace block ~ ~ ~ container.2 with flint[custom_name={"color":"gold","italic":false,"text":"Armorbite"},consumable={animation:"eat",on_consume_effects:[{type:"minecraft:apply_effects",effects:[{id:"minecraft:resistance",amplifier:0,duration:3600}]}]},item_model="bluedepths:blue_depths/items/armorbite",lore=[{"color":"blue","italic":false,"text":"Resistance (3:00)"}]] $(outputVal)
# Bluegill
$execute if items block ~ ~ ~ container.0 flint[item_model="bluedepths:items/raw_bluegill"] run item replace block ~ ~ ~ container.2 with minecraft:flint[item_model="bluedepths:items/cooked_bluegill",custom_name={"italic":false,"text":"Cooked Bluegill"},consumable={animation:"eat",sound:"entity.generic.eat"},food={nutrition:5,saturation:7}] $(outputVal)
# Largemouth Bass
$execute if items block ~ ~ ~ container.0 flint[item_model="bluedepths:items/raw_lm_bass"] run item replace block ~ ~ ~ container.2 with minecraft:flint[item_model="bluedepths:items/cooked_lm_bass",custom_name={"italic":false,"text":"Cooked Largemouth Bass"},consumable={animation:"eat",sound:"entity.generic.eat"},food={nutrition:7,saturation:10}] $(outputVal)


### Effects
playsound minecraft:block.fire.extinguish master @a[distance=..6] ~ ~ ~ 4 1
particle minecraft:flame ~ ~1.5 ~ .125 .125 .125 0 25