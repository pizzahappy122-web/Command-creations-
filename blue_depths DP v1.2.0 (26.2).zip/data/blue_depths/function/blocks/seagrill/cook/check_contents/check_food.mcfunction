###### Cook Food, perform mathematical operations to correctly change grill's contents

#### Store Container contents
# Input Count (Raw Food Source)
execute store result score @s bd_containerInputCount run execute if items block ~ ~ ~ container.0 *
# Fuel Count (Coal, charcoal, etc)
execute store result score @s bd_containerFuelCount run execute if items block ~ ~ ~ container.1 *


#### Perform mathematical operations
### Fuel source conversion
# Store fuel source count in FuelMulti to not modify the original fuel count (since it will be used later)
scoreboard players operation @s bd_containerFuelMulti = @s bd_containerFuelCount
#scoreboard players operation @s bd_isOdd = @s bd_containerFuelCount
## Fuel sources
# Multiply fuel source by 8 to be used in subtraction with input (Coal/Charcoal)
execute if items block ~ ~ ~ container.1 #minecraft:coals run scoreboard players operation @s bd_containerFuelMulti *= #bd_8 bd_constant

### Get NEW INPUT COUNT and OUTPUT COUNT
# Store original Input count into new input count
scoreboard players operation @s bd_containerNewInputCount = @s bd_containerInputCount
# If fuel source is sticks, double the newInputCount (Multiply by two)
execute if items block ~ ~ ~ container.1 minecraft:stick run scoreboard players operation @s bd_containerNewInputCount *= #bd_2 bd_constant
# Initialize the score for the output count
scoreboard players set @s bd_containerOutputCount 0
# Use a recursive function to update the new input count, fuel multi, and output count (Coal/Charcoal)
execute if items block ~ ~ ~ container.1 #minecraft:coals if score @s bd_containerFuelMulti matches 1.. if score @s bd_containerInputCount matches 8.. run function blue_depths:blocks/seagrill/cook/fuel_counts_update/coals
# Use a recursive function to update the new input count, fuel multi, and output count (Sticks)
execute if items block ~ ~ ~ container.1 minecraft:stick if score @s bd_containerFuelMulti matches 2.. run function blue_depths:blocks/seagrill/cook/fuel_counts_update/stick


### Get new remaining FUEL Source value
# Initialize New Fuel source to 0
scoreboard players set @s bd_containerNewFuelCount 0
# Update to same value as Fuel Multi, IF Fuel Multi is not 0
scoreboard players operation @s bd_containerNewFuelCount = @s bd_containerFuelMulti
# Divide by 8 (Coal/Charcoal)
execute if items block ~ ~ ~ container.1 #minecraft:coals if score @s bd_containerFuelMulti matches 1.. run scoreboard players operation @s bd_containerNewFuelCount /= #bd_8 bd_constant

### Specific conversions
# Convert Input count back from double if fuel source is sticks and not cooking nematocyst gel
execute if items block ~ ~ ~ container.1 minecraft:stick if score @s bd_containerNewInputCount matches 1.. run scoreboard players operation @s bd_containerNewInputCount /= #bd_2 bd_constant
# Convert output count back from double to singles if fuel source is sticks
execute if items block ~ ~ ~ container.1 minecraft:stick if score @s bd_containerOutputCount matches 1.. run scoreboard players operation @s bd_containerOutputCount /= #bd_2 bd_constant



#### Change items in container

### Copy new values into storage
execute store result storage bluedepths:cookingstorage inputVal int 1 run scoreboard players get @s bd_containerNewInputCount
execute store result storage bluedepths:cookingstorage fuelVal int 1 run scoreboard players get @s bd_containerNewFuelCount
execute store result storage bluedepths:cookingstorage outputVal int 1 run scoreboard players get @s bd_containerOutputCount



### Update items in the container

## Output update
#If there is fuel left
execute if score @s bd_containerOutputCount matches 1.. run function blue_depths:blocks/seagrill/cook/update_container/output_update with storage bluedepths:cookingstorage
# If none is left
execute if score @s bd_containerOutputCount matches ..0 run item replace block ~ ~ ~ container.2 with air

## Input Update
# If there is input left
execute if score @s bd_containerNewInputCount matches 1.. run function blue_depths:blocks/seagrill/cook/update_container/input_update with storage bluedepths:cookingstorage
# If none is left
execute if score @s bd_containerNewInputCount matches ..0 run item replace block ~ ~ ~ container.0 with air

## Fuel update
#If there is fuel left
execute if score @s bd_containerNewFuelCount matches 1.. run function blue_depths:blocks/seagrill/cook/update_container/fuel_update with storage bluedepths:cookingstorage
# If none is left
execute if score @s bd_containerNewFuelCount matches ..0 run item replace block ~ ~ ~ container.1 with air


tag @s remove bd_quitCooking

###### TO DO: Perform math operations correctly count what should each container slot have after cooking is complete
######        then, dynamically change each slot using separate macro functions. Make sure to save each value correctly,
######        also, make sure to distinguish which fuel source is being used to correctly replace the number. Also make
######        sure to take into account the remainder fuel source

#tellraw @a ["New Input: ",{"score":{"name":"@s","objective":"bd_containerNewInputCount"}}]
#tellraw @a ["Fuel: ",{"score":{"name":"@s","objective":"bd_containerFuelMulti"}}]
#tellraw @a ["Output: ",{"score":{"name":"@s","objective":"bd_containerOutputCount"}}]
#tellraw @a ["------------------------------"]
