###### Cook Nematocyst Gel, perform mathematical operations to correctly change grill's contents

#### Store Container contents
# Input Count (Raw Food Source)
execute store result score @s bd_containerInputCount run execute if items block ~ ~ ~ container.0 *
# Fuel Count (Coal, charcoal, etc)
execute store result score @s bd_containerFuelCount run execute if items block ~ ~ ~ container.1 *


#### Perform mathematical operations
### Fuel source conversion
# Store fuel source count in FuelMulti to not modify the original fuel count (since it will be used later)
scoreboard players operation @s bd_containerFuelMulti = @s bd_containerFuelCount

### Get NEW INPUT COUNT and OUTPUT COUNT
# Store original Input count into new input count
scoreboard players operation @s bd_containerNewInputCount = @s bd_containerInputCount
# Initialize the score for the output count
scoreboard players set @s bd_containerOutputCount 0
# If only one gel is inside the container, terminate the function
execute if score @s bd_containerNewInputCount matches 1 run return 0
# If only one stick is inside the container, terminate the function
execute if score @s bd_containerFuelMulti matches 1 run return 0
# Use a recursive function to update the new input count, fuel multi, and output count (Sticks)
execute if score @s bd_containerNewInputCount matches 2.. if score @s bd_containerFuelMulti matches 2.. if items block ~ ~ ~ container.0 minecraft:flint[item_model="bluedepths:blue_depths/items/nematocyst_gel"] if items block ~ ~ ~ container.1 minecraft:stick run function blue_depths:blocks/seagrill/cook/fuel_counts_update/stick

### Get new remaining FUEL Source value
# Initialize New Fuel source to 0
scoreboard players set @s bd_containerNewFuelCount 0
# Update to same value as Fuel Multi, IF Fuel Multi is not 0
scoreboard players operation @s bd_containerNewFuelCount = @s bd_containerFuelMulti

### Specific conversions
# Convert output count back from double to singles if fuel source is sticks
execute if items block ~ ~ ~ container.1 minecraft:stick if score @s bd_containerOutputCount matches 1.. run scoreboard players operation @s bd_containerOutputCount /= #bd_2 bd_constant


#### Change items in container

### Copy new values into storage
execute store result storage bluedepths:cookingstorage inputVal int 1 run scoreboard players get @s bd_containerNewInputCount
execute store result storage bluedepths:cookingstorage fuelVal int 1 run scoreboard players get @s bd_containerNewFuelCount
execute store result storage bluedepths:cookingstorage outputVal int 1 run scoreboard players get @s bd_containerOutputCount



### Update items in the container

## Output update
#If there is fuel left
execute if score @s bd_containerOutputCount matches 1.. run function blue_depths:blocks/seagrill/cook/update_container/output_update with storage bluedepths:cookingstorage
# If none is left
execute if score @s bd_containerOutputCount matches ..0 run item replace block ~ ~ ~ container.2 with air

## Input Update
# If there is input left
execute if score @s bd_containerNewInputCount matches 1.. run function blue_depths:blocks/seagrill/cook/update_container/input_update with storage bluedepths:cookingstorage
# If none is left
execute if score @s bd_containerNewInputCount matches ..0 run item replace block ~ ~ ~ container.0 with air

## Fuel update
#If there is fuel left
execute if score @s bd_containerNewFuelCount matches 1.. run function blue_depths:blocks/seagrill/cook/update_container/fuel_update with storage bluedepths:cookingstorage
# If none is left
execute if score @s bd_containerNewFuelCount matches ..0 run item replace block ~ ~ ~ container.1 with air


tag @s remove bd_quitCooking