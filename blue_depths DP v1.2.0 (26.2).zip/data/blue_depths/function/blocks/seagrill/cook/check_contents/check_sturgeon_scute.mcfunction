###### Process Scute into Armorbite, perform mathematical operations to correctly change grill's contents
say hi
#### Store Container contents
# Input Count (Sturgeon Scute)
execute store result score @s bd_containerOutputCount run execute if items block ~ ~ ~ container.0 *

### Store value
execute store result storage bluedepths:cookingstorage outputVal int 1 run scoreboard players get @s bd_containerOutputCount

### Update Container Contents
# Fill output
function blue_depths:blocks/seagrill/cook/update_container/output_update with storage bluedepths:cookingstorage
# Empty input slot
item replace block ~ ~ ~ container.0 with air

tag @s remove bd_quitCooking