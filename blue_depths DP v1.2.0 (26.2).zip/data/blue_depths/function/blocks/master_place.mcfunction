# Sea Grill
execute as @s[tag=bd_seagrill] at @s run function blue_depths:blocks/seagrill/place_seagrill

# Nameless Block
execute as @s[tag=bd_namelessBlock] at @s run function blue_depths:blocks/nameless_block/place_nameless

# Electrode
execute as @s[tag=bd_electrodeUnlit] at @s run function blue_depths:blocks/electrode/place_electrode

# Marine Workbench
execute as @s[tag=bd_seacrafter] at @s run function blue_depths:blocks/sea_crafter/place_crafter

# Meat Block easter egg
execute as @s[tag=bd_meatblock] at @s run function blue_depths:blocks/meatblock/meatblock_place