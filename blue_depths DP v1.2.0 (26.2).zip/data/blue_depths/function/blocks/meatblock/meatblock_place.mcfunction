# Set base block and play sound effect
setblock ~ ~ ~ minecraft:honey_block replace
playsound minecraft:block.honey_block.place master @a[distance=..6] ~ ~ ~ 12 1

### Tag block
tag @s add bd_placedBlock