## Spawn drop
summon item ~ ~ ~ {Item:{id:"minecraft:glow_item_frame",count:1,components:{"minecraft:custom_name":{"color":"white","italic":false,"text":"Meat"},"minecraft:item_model":"bluedepths:blue_depths/blocks/meatblock","minecraft:entity_data":{id:"minecraft:glow_item_frame",Item:{id:"minecraft:glow_item_frame",count:1,components:{"minecraft:item_model":"bluedepths:blue_depths/blocks/meatblock"}},Fixed:1b,Invisible:1b,Silent:1b,Invulnerable:1b,Tags:["bd_meatblock","bd_block"]}}}}

#kill honey block drop
kill @e[type=item,nbt={Item:{id:"minecraft:honey_block"}},distance=0..2,sort=nearest,limit=1]
#kill item frame
kill @s