# Create item
data merge block ~ ~ ~ {Items:[{Slot:4b,id:"minecraft:glow_item_frame",count:1,components:{"minecraft:item_model":"bluedepths:blocks/electrode","minecraft:entity_data":{id:"minecraft:glow_item_frame",Item:{id:"minecraft:glow_item_frame",count:1,components:{item_model:"bluedepths:blocks/electrode"}},Fixed:1b,Invisible:1b,Silent:1b,Invulnerable:1b,Tags:["bd_block","bd_electrodeUnlit","bd_electrode","bd_blocksEvent"]},"minecraft:custom_name":{"italic":false,"text":"Electrode"}}}]}

### Play sound effect
playsound minecraft:block.smithing_table.use master @a[distance=..5] ~ ~ ~
