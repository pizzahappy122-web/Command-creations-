### Craft Bluegill Bucket
data merge block ~ ~ ~ {Items:[{Slot:4b,id:"minecraft:cod_spawn_egg",count:1,components:{"minecraft:custom_name":{"color":"yellow","italic":false,"text":"Bucket of Bluegill (Evil) (Possessed)"},"minecraft:item_model":"bluedepths:items/bluegill_bucket","minecraft:entity_data":{id:"minecraft:cod",Tags:["bd_bluegillEvilBucket","bd_fishReplace"],active_effects:[{id:"minecraft:resistance",amplifier:10,duration:40,show_particles:0b},{id:"minecraft:invisibility",amplifier:0,duration:-1,show_particles:0b}]}}}]}

## Effects
playsound minecraft:entity.goat.screaming.milk master @a[distance=..6] ~ ~ ~