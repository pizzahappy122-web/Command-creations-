### Craft Meatblock
data merge block ~ ~ ~ {Items:[{Slot:4b,id:"minecraft:glow_item_frame",count:1,components:{"minecraft:custom_name":{"color":"white","italic":false,"text":"Meat"},"minecraft:item_model":"bluedepths:blue_depths/blocks/meatblock","minecraft:entity_data":{id:"minecraft:glow_item_frame",Item:{id:"minecraft:glow_item_frame",count:1,components:{item_model:"bluedepths:blue_depths/blocks/meatblock"}},Fixed:1b,Invisible:1b,Silent:1b,Invulnerable:1b,Tags:["bd_meatblock","bd_block"]}}}]}

### effects
playsound minecraft:entity.ghast.hurt master @a[distance=..6] ~ ~ ~ 12 1
particle minecraft:soul ~ ~1.5 ~ .28 .28 .28 0 25