# Make armor
data merge block ~ ~ ~ {Items:[{Slot:4b,id:"minecraft:iron_helmet",count:1,components:{"minecraft:max_damage":350,"minecraft:equippable":{slot:"head",asset_id:"bluedepths:croc_armor"},"minecraft:item_model":"bluedepths:items/armor/croc_armor/helmet","minecraft:custom_name":{"italic":false,"text":"Crocodile Helmet"},"minecraft:attribute_modifiers":[{id:"blue_depths:croc_helmet_armor",type:"armor",amount:2,operation:"add_value",slot:"head"}],"minecraft:enchantments":{"thorns":2},"minecraft:enchantment_glint_override":false}}]}

### Play sound effect
playsound minecraft:block.smithing_table.use master @a[distance=..5] ~ ~ ~