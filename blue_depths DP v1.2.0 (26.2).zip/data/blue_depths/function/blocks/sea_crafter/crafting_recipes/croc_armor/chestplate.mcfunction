# Make armor
data merge block ~ ~ ~ {Items:[{Slot:4b,id:"minecraft:iron_chestplate",count:1,components:{"minecraft:max_damage":420,"minecraft:equippable":{slot:"chest",asset_id:"bluedepths:croc_armor"},"minecraft:item_model":"bluedepths:items/armor/croc_armor/chestplate","minecraft:custom_name":{"italic":false,"text":"Crocodile Chestplate"},"minecraft:attribute_modifiers":[{id:"blue_depths:croc_chestplate_armor",type:"armor",amount:5,operation:"add_value",slot:"chest"}],"minecraft:enchantments":{"thorns":2},"minecraft:enchantment_glint_override":false}}]} 

### Play sound effect
playsound minecraft:block.smithing_table.use master @a[distance=..5] ~ ~ ~