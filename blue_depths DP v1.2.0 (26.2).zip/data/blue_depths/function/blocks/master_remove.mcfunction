## Sea grill
execute as @s[tag=bd_seagrill] at @s run function blue_depths:blocks/seagrill/remove_seagrill

## Nameless Block
execute as @s[tag=bd_namelessBlock] at @s run function blue_depths:blocks/nameless_block/remove_nameless

## Electrode
execute as @s[tag=bd_electrode] at @s run function blue_depths:blocks/electrode/remove_electrode

## Marine Workbench
execute as @s[tag=bd_seacrafter] at @s run function blue_depths:blocks/sea_crafter/remove_crafter

# Meat Block easter egg
execute as @s[tag=bd_meatblock] at @s run function blue_depths:blocks/meatblock/meatblock_remove