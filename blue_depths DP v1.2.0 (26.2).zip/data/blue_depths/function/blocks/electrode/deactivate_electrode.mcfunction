##Replace with redstone block
setblock ~ ~ ~ minecraft:coal_block replace

### Change block display
item replace entity @s container.0 with minecraft:glow_item_frame[minecraft:item_model="bluedepths:blocks/electrode"] 1

### Change tags
tag @s remove bd_electrodeLit
tag @s add bd_electrodeUnlit