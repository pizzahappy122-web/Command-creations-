##Replace with redstone block
setblock ~ ~ ~ minecraft:redstone_block replace

### Change block display
item replace entity @s container.0 with minecraft:glow_item_frame[minecraft:item_model="bluedepths:blocks/electrode_active"] 1

### Change tags
tag @s remove bd_electrodeUnlit
tag @s add bd_electrodeLit