### If Electric Eel is close, change to active electrode
execute as @s[tag=bd_electrodeUnlit] at @s if entity @e[type=drowned,tag=bd_electricEel,distance=..5] run function blue_depths:blocks/electrode/activate_electrode

### If no Electric Eel is close, change to inactive electrode
execute as @s[tag=bd_electrodeLit] at @s unless entity @e[type=drowned,tag=bd_electricEel,distance=..5] run function blue_depths:blocks/electrode/deactivate_electrode
