# Summon drops
summon item ~ ~0.5 ~ {Item:{id:"minecraft:glow_item_frame",count:1,components:{"minecraft:item_model":"bluedepths:blocks/electrode","minecraft:entity_data":{id:"minecraft:glow_item_frame",Item:{id:"minecraft:glow_item_frame",count:1,components:{"minecraft:item_model":"bluedepths:blocks/electrode"}},Fixed:1b,Invisible:1b,Silent:1b,Invulnerable:1b,Tags:["bd_block","bd_electrodeUnlit","bd_electrode","bd_blocksEvent"]},"minecraft:custom_name":{"italic":false,"text":"Electrode"}}}}

#kill obsidian drop
kill @e[type=item,nbt={Item:{id:"minecraft:coal_block"}},distance=0..2,sort=nearest,limit=1]
kill @e[type=item,nbt={Item:{id:"minecraft:redstone_block"}},distance=0..2,sort=nearest,limit=1]

# Kill item frame
kill @s