### Electrode
execute if entity @s[tag=bd_electrode] run function blue_depths:blocks/electrode/check_electrode